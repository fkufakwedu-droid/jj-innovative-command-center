import { mulberry32 } from '../lib/rng'

/*
 * Mock data for a 260-door multifamily portfolio (5 properties).
 * Everything is generated from a fixed seed so the numbers are stable.
 * Swap this module for API calls: the rest of the app only reads the shape
 * exported by `buildPortfolio()`.
 */

/* Per-client settings come from window.CLIENT (set by each client's config.js). */
export const CLIENT = (typeof window !== 'undefined' && window.CLIENT) || {}
const rnd = mulberry32(CLIENT.seed || 260)
const between = (a, b) => a + rnd() * (b - a)
const int = (a, b) => Math.round(between(a, b))
const pick = (arr) => arr[Math.floor(rnd() * arr.length)]
const DAY = 86400000

export const NOW = (() => {
  const d = new Date()
  d.setHours(12, 0, 0, 0)
  return d
})()
const addDays = (d, n) => new Date(d.getTime() + n * DAY)

const FIRST = ['Maria', 'James', 'Priya', 'Daniel', 'Aisha', 'Carlos', 'Emily', 'Marcus', 'Sofia', 'Tyrone', 'Hannah', 'Luis', 'Grace', 'Omar', 'Chloe', 'Victor', 'Naomi', 'Ethan', 'Lena', 'Andre']
const LAST = ['Alvarez', 'Brooks', 'Chen', 'Dawson', 'Ellis', 'Foster', 'Garcia', 'Hughes', 'Ibrahim', 'Jensen', 'Khan', 'Lopez', 'Mitchell', 'Nguyen', 'Ortiz', 'Patel', 'Quinn', 'Reyes', 'Singh', 'Turner']
const tenantName = () => `${pick(FIRST)} ${pick(LAST)}`

const DEFAULT_SPEC = [
  { id: 'harbor', name: 'Harbor View', units: 72, occupied: 68, avgRent: 1985, concessions: 4200, collectRate: 0.974, opexRatio: 0.4, dscr: 1.42, lender: 'Fannie Mae DUS', rate: 4.85, cashDays: 52, turnMean: 9.5, color: '#38bdf8' },
  { id: 'maple', name: 'Maple Court', units: 64, occupied: 59, avgRent: 1725, concessions: 3100, collectRate: 0.951, opexRatio: 0.43, dscr: 1.31, lender: 'Freddie Mac SBL', rate: 5.1, cashDays: 44, turnMean: 11.5, color: '#a78bfa' },
  { id: 'cedar', name: 'Cedar Ridge', units: 48, occupied: 44, avgRent: 1640, concessions: 2300, collectRate: 0.938, opexRatio: 0.45, dscr: 1.21, lender: 'First Citizens Bank', rate: 6.2, cashDays: 39, turnMean: 13, color: '#34d399' },
  { id: 'oakline', name: 'Oakline Flats', units: 40, occupied: 38, avgRent: 1820, concessions: 1900, collectRate: 0.981, opexRatio: 0.47, dscr: 1.12, lender: 'Ares Bridge Loan', rate: 7.4, cashDays: 31, turnMean: 14.5, color: '#fbbf24' },
  { id: 'birch', name: 'Birchwood Terrace', units: 36, occupied: 33, avgRent: 1560, concessions: 1700, collectRate: 0.921, opexRatio: 0.5, dscr: 1.08, lender: 'Regional Bank Term Loan', rate: 6.85, cashDays: 33, turnMean: 15.5, color: '#fb7185' },
]

const PALETTE = ['#38bdf8', '#a78bfa', '#34d399', '#fbbf24', '#fb7185', '#f97316', '#22d3ee', '#c084fc']
const slug = (t) => String(t).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
/* Client properties override name/units; financial profile cycles through the defaults. */
const SPEC = CLIENT.properties?.length
  ? CLIENT.properties.map((c, i) => {
      const base = DEFAULT_SPEC[i % DEFAULT_SPEC.length]
      const units = c.units
      return { ...base, id: c.id || slug(c.name) || `p${i}`, name: c.name, units, occupied: c.occupied ?? Math.round(units * (base.occupied / base.units)), color: c.color || PALETTE[i % PALETTE.length], ...(c.profile || {}) }
    })
  : DEFAULT_SPEC

const MONTH_LABELS = (() => {
  const out = []
  for (let i = 11; i >= 0; i--) {
    const d = new Date(NOW.getFullYear(), NOW.getMonth() - i, 1)
    out.push({ label: d.toLocaleDateString('en-US', { month: 'short' }), month: d.getMonth(), year: d.getFullYear() })
  }
  return out
})()

function buildFinancials(s) {
  const gpr = s.units * s.avgRent
  const billed = s.occupied * s.avgRent
  const netBilled = billed - s.concessions
  const collected = netBilled * s.collectRate
  const months = MONTH_LABELS.map((m, i) => {
    const trend = 0.955 + 0.045 * (i / 11)
    const revenue = collected * trend * (1 + (rnd() - 0.5) * 0.02)
    const winter = [11, 0, 1].includes(m.month) ? 0.06 : 0
    const summer = [6, 7].includes(m.month) ? 0.03 : 0
    const opex = revenue * s.opexRatio * (1 + winter + summer + (rnd() - 0.5) * 0.05)
    return { label: m.label, revenue, opex, noi: revenue - opex }
  })
  const last3 = months.slice(-3).reduce((a, m) => a + m.noi, 0)
  const noiAnnualizedT3 = last3 * 4
  const annualDS = noiAnnualizedT3 / s.dscr
  return { gpr, billed, netBilled, collected, months, annualDS, balance: annualDS / 0.066 }
}

function buildCashSeries(totalNow, days = 365) {
  const arr = new Array(days)
  let noise = 0
  for (let i = days - 1; i >= 0; i--) {
    const fromEnd = days - 1 - i
    noise = noise * 0.92 + (rnd() - 0.5) * 0.012
    const dayOfMonth = new Date(NOW.getTime() - fromEnd * DAY).getDate()
    const cycle = Math.sin(((dayOfMonth - 1) / 30) * Math.PI * 2 - 0.6) * 0.035
    const trend = 0.9 + 0.1 * (i / (days - 1))
    arr[i] = totalNow * trend * (1 + cycle + noise)
  }
  arr[days - 1] = totalNow
  return arr
}

function buildOccupancyHistory(phys, econ, weeks = 52) {
  const out = []
  let n1 = 0
  let n2 = 0
  for (let w = weeks - 1; w >= 0; w--) {
    n1 = n1 * 0.85 + (rnd() - 0.5) * 0.9
    n2 = n2 * 0.85 + (rnd() - 0.5) * 1.1
    const drift = (w / (weeks - 1)) * 2.4
    out[weeks - 1 - w] = {
      physical: Math.min(99, phys - drift * 0.6 + n1),
      economic: Math.min(97, econ - drift + n2),
    }
  }
  out[weeks - 1] = { physical: phys, economic: econ }
  return out
}

const CATEGORIES = ['Plumbing', 'HVAC', 'Electrical', 'Appliance', 'Locks & doors', 'Pest control', 'Flooring', 'Roof / leak', 'Common area']
const TITLES = {
  Plumbing: ['Kitchen sink leaking', 'Toilet running constantly', 'No hot water', 'Slow tub drain'],
  HVAC: ['AC not cooling', 'Furnace not igniting', 'Thermostat unresponsive', 'Loud air handler'],
  Electrical: ['Outlets dead in bedroom', 'Breaker keeps tripping', 'Hallway light out'],
  Appliance: ['Dishwasher not draining', 'Fridge warm', 'Oven element out'],
  'Locks & doors': ['Deadbolt sticking', 'Patio door off track', 'Fob not working'],
  'Pest control': ['Ants in kitchen', 'Roach sighting', 'Rodent activity'],
  Flooring: ['Lifting vinyl plank', 'Carpet seam open'],
  'Roof / leak': ['Ceiling stain after rain', 'Active ceiling drip'],
  'Common area': ['Laundry room machine down', 'Elevator slow', 'Stairwell light out', 'Gate stuck open'],
}
const TECHS = ['R. Alvarez', 'M. Okafor', 'T. Brennan', 'D. Silva', 'Vendor: ProFlow', 'Vendor: CoolAir']
const NEEDS_INSPECTION = new Set(['Plumbing', 'HVAC', 'Electrical', 'Roof / leak', 'Flooring'])
const DETAIL = {
  Plumbing: ['Water is pooling under the fixture.', 'Tenant says it got worse over the last few days.', 'Needs a plumber to check the shut-off and seals.'],
  HVAC: ['Unit is running but not holding temperature.', 'Tenant reports a burning smell on start-up.', 'Filter changed already, issue remains.'],
  Electrical: ['Tenant reports flickering and a warm cover plate.', 'Breaker resets but trips again within minutes.', 'Tenant has stopped using the circuit.'],
  Appliance: ['Appliance stopped working after a power flicker.', 'Tenant reports an error code on the display.', 'Under the landlord-supplied appliance list.'],
  'Locks & doors': ['Door does not latch without lifting the handle.', 'Tenant reports it is hard to lock at night.', 'Hardware is original to the unit.'],
  'Pest control': ['Tenant reports sightings over the last week.', 'Neighbouring units have not reported any.', 'Needs a treatment visit and a follow-up check.'],
  Flooring: ['Planks are lifting near the entry.', 'Tenant reports a trip hazard.', 'May need subfloor check before repair.'],
  'Roof / leak': ['Water staining visible after the last rain.', 'Tenant placed a bucket under the drip.', 'Needs source of the leak confirmed before repair.'],
  'Common area': ['Reported by a resident at the building.', 'Affects more than one household.', 'Needs a fix before the weekend.'],
}
const SQFT = [520, 690, 940, 1180]
const FACTOR = [0.78, 0.92, 1.1, 1.32]
const DELINQ_STATUS = ['Payment plan', 'Notice served', 'Contacted', 'No response', 'Eviction filed']
const LEASE_STATUS = ['Renewed', 'Offer sent', 'No response', 'Notice to vacate']

export function buildPortfolio() {
  const properties = SPEC.map((s) => {
    const fin = buildFinancials(s)
    const monthlyOutflow = fin.months[11].opex + fin.annualDS / 12
    const liquid = (s.cashDays / 30) * monthlyOutflow
    const operating = liquid * between(0.46, 0.5)
    const reserve = liquid * between(0.32, 0.36)
    const escrow = liquid - operating - reserve
    return {
      ...s,
      ...fin,
      cash: { operating, reserve, escrow, total: liquid },
      monthlyOutflow,
      cashSeries: buildCashSeries(liquid),
      occHistory: buildOccupancyHistory((s.occupied / s.units) * 100, (fin.collected / fin.gpr) * 100),
    }
  })

  // ---------- Unit master list (every unit in the portfolio is a real record) ----------
  const units = []
  const unitsByProp = {}
  properties.forEach((p) => {
    const perFloor = Math.ceil(p.units / 4)
    const list = []
    for (let i = 0; i < p.units; i++) {
      const floor = 1 + Math.floor(i / perFloor)
      const number = `${floor}${String((i % perFloor) + 1).padStart(2, '0')}`
      const r = rnd()
      const beds = r < 0.1 ? 0 : r < 0.5 ? 1 : r < 0.88 ? 2 : 3
      list.push({
        id: `${p.id}-${number}`,
        propertyId: p.id,
        property: p.name,
        number,
        floor,
        beds,
        baths: beds >= 3 ? 2 : beds === 2 ? (rnd() < 0.5 ? 2 : 1) : 1,
        sqft: Math.round(SQFT[beds] * between(0.94, 1.06)),
        base: FACTOR[beds] * between(0.97, 1.03),
        vacant: false,
      })
    }
    const vac = new Set()
    while (vac.size < p.units - p.occupied) vac.add(int(0, p.units - 1))
    vac.forEach((i) => (list[i].vacant = true))
    const scale = p.billed / list.filter((u) => !u.vacant).reduce((a, u) => a + u.base, 0)
    list.forEach((u) => {
      u.rent = Math.round(u.base * scale)
      delete u.base
      if (!u.vacant) {
        const leaseEnd = addDays(NOW, int(1, 365))
        u.tenant = tenantName()
        u.email = `${u.tenant.toLowerCase().replace(' ', '.')}@example.com`
        u.phone = `555-0${int(100, 199)}`
        u.leaseEnd = leaseEnd
        u.leaseStart = addDays(leaseEnd, -365)
        u.moveIn = addDays(u.leaseStart, -365 * int(0, 4))
      }
    })
    unitsByProp[p.id] = list
    units.push(...list)
  })
  const unitIndex = Object.fromEntries(units.map((u) => [u.id, u]))
  const ref = (u) => ({ unitId: u.id, unit: u.number, propertyId: u.propertyId, property: u.property })

  // ---------- Delinquent tenants ----------
  const delinquents = []
  properties.forEach((p) => {
    const pool = unitsByProp[p.id].filter((u) => !u.vacant)
    const count = Math.min(pool.length, Math.round(p.units * (0.075 + (1 - p.collectRate) * 1.4)))
    for (let i = 0; i < count; i++) {
      const u = pool.splice(Math.floor(rnd() * pool.length), 1)[0]
      const r = rnd()
      const days = r < 0.45 ? int(3, 30) : r < 0.75 ? int(31, 60) : r < 0.92 ? int(61, 90) : int(91, 150)
      u.onTime = int(52, 84)
      const balance = Math.round(u.rent * (days / 30) * between(0.85, 1.1) + (days > 30 ? 75 : 0))
      delinquents.push({
        id: `${u.id}-d`,
        ...ref(u),
        tenant: u.tenant,
        days,
        balance,
        status: days > 90 ? pick(['Eviction filed', 'Notice served']) : days > 45 ? pick(DELINQ_STATUS) : pick(['Contacted', 'Payment plan', 'No response']),
      })
    }
  })

  // ---------- Debt ----------
  const loans = properties.map((p) => ({
    id: `loan-${p.id}`,
    propertyId: p.id,
    property: p.name,
    lender: p.lender,
    rate: p.rate,
    balance: p.balance,
    annualDS: p.annualDS,
  }))

  // ---------- Unit turns ----------
  const completedTurns = []
  properties.forEach((p) => {
    const count = Math.round(p.units * 0.5)
    for (let i = 0; i < count; i++) {
      const u = pick(unitsByProp[p.id])
      const days = Math.max(3, Math.round(p.turnMean * 0.55 + -Math.log(1 - rnd()) * p.turnMean * 0.5))
      const moveOutAgo = int(days + 1, 364)
      completedTurns.push({ ...ref(u), moveOut: addDays(NOW, -moveOutAgo), days })
    }
  })
  const vacantDays = [3, 5, 6, 9, 12, 14, 16, 17, 18, 19, 21, 22, 24, 26, 29, 31, 35, 41]
  const vacantNow = []
  let vi = 0
  units.filter((u) => u.vacant).forEach((u) => {
    const days = vacantDays[(vi * 7) % vacantDays.length]
    vi++
    const status = days < 8 ? 'Make-ready' : days < 20 ? pick(['Listed', 'Make-ready', 'Pre-leased']) : pick(['Listed', 'Listed', 'Awaiting repairs'])
    vacantNow.push({ ...ref(u), days, status, askRent: Math.round(u.rent * between(1.0, 1.05)) })
    u.vacantDays = days
    u.vacantStatus = status
    u.askRent = vacantNow[vacantNow.length - 1].askRent
  })

  // ---------- Work orders: ONE table that every screen reads (open + closed history) ----------
  const OPEN_STATUSES = ['New', 'Scheduled', 'In progress', 'Waiting on parts', 'Awaiting inspection']
  const demoPhoto = (kind, wid) => ({ id: `${wid}-${kind}-demo`, demo: true, kind })
  const baseWO = (u, priority, cat, openedAt) => {
    const title = pick(TITLES[cat])
    const occupied = !u.vacant
    const inspectionRequired = priority === 'Emergency' || NEEDS_INSPECTION.has(cat)
    return {
      ...ref(u),
      tenantId: occupied ? u.id : null,
      tenant: occupied ? u.tenant : 'Vacant unit (internal)',
      category: cat,
      title,
      description: `${title}. ${pick(DETAIL[cat])}`,
      priority,
      openedAt,
      assignee: pick(TECHS),
      inspectionRequired,
      estimate: Math.round(priority === 'Emergency' ? between(350, 1400) : priority === 'Urgent' ? between(120, 650) : between(45, 260)),
      photos: { before: [], after: [] },
      log: [],
    }
  }
  const workOrders = []

  // closed history (last 12 months)
  const closedList = []
  properties.forEach((p) => {
    const n = Math.round(p.units * 0.6)
    for (let i = 0; i < n; i++) {
      const u = pick(unitsByProp[p.id])
      const r = rnd()
      const priority = r < 0.08 ? 'Emergency' : r < 0.35 ? 'Urgent' : 'Routine'
      const hours = Math.round((priority === 'Emergency' ? between(2, 10) : priority === 'Urgent' ? between(10, 60) : between(30, 200)) * 10) / 10
      const closedAt = addDays(NOW, -int(1, 364))
      const openedAt = new Date(closedAt.getTime() - hours * 3600000)
      closedList.push({ ...baseWO(u, priority, pick(CATEGORIES), openedAt), status: 'Closed', closedAt, hours })
    }
  })
  closedList.sort((a, b) => a.closedAt - b.closedAt)
  closedList.forEach((w, i) => {
    w.id = `WO-${4000 + i}`
    w.age = Math.round((w.closedAt - w.openedAt) / DAY)
    w.actual = Math.round(w.estimate * between(0.85, 1.15))
    if (w.inspectionRequired) w.photos = { before: [demoPhoto('before', w.id)], after: [demoPhoto('after', w.id)] }
    w.log = [
      { at: w.openedAt, text: `Opened by ${w.tenantId ? w.tenant : 'staff'}` },
      { at: new Date(w.openedAt.getTime() + 3600000 * 2), text: `Assigned to ${w.assignee}` },
      { at: new Date(w.closedAt.getTime() - 3600000 * 3), text: w.inspectionRequired ? 'Inspected · before and after photos attached' : 'Work completed' },
      { at: w.closedAt, text: 'Closed' },
    ]
    workOrders.push(w)
  })

  // open work orders
  let woN = 4000 + closedList.length
  properties.forEach((p) => {
    const count = Math.round(p.units * 0.2)
    for (let i = 0; i < count; i++) {
      const u = pick(unitsByProp[p.id])
      const r = rnd()
      const priority = r < 0.08 ? 'Emergency' : r < 0.35 ? 'Urgent' : 'Routine'
      const age = priority === 'Emergency' ? int(0, 2) : priority === 'Urgent' ? Math.round(Math.pow(rnd(), 1.4) * 13) : Math.round(Math.pow(rnd(), 1.2) * 24)
      const w = baseWO(u, priority, pick(CATEGORIES), addDays(NOW, -age))
      w.id = `WO-${woN++}`
      w.age = age
      w.status = age > 7 ? pick(['Waiting on parts', 'Scheduled', 'In progress', 'In progress']) : pick(['In progress', 'Scheduled', 'New', 'New'])
      if (w.inspectionRequired && w.status === 'In progress' && rnd() < 0.35) w.status = 'Awaiting inspection'
      if (w.inspectionRequired && w.status !== 'New' && w.status !== 'Scheduled') {
        if (rnd() < 0.75) w.photos.before.push(demoPhoto('before', w.id))
        if (w.status === 'Awaiting inspection' && rnd() < 0.5) w.photos.after.push(demoPhoto('after', w.id))
      }
      w.log = [
        { at: w.openedAt, text: `Opened by ${w.tenantId ? w.tenant : 'staff'}` },
        { at: new Date(w.openedAt.getTime() + 3600000 * 3), text: `Assigned to ${w.assignee}` },
      ]
      if (w.status === 'In progress' || w.status === 'Awaiting inspection') w.log.push({ at: new Date(w.openedAt.getTime() + 86400000), text: 'Work started' })
      workOrders.push(w)
    }
  })
  const resolution = { Emergency: 5.8, Urgent: 29, Routine: 81 } // hours, fallback when no closed history

  // ---------- CapEx ----------
  const capex = [
    { id: 'cx1', propertyId: 'harbor', name: 'Roof replacement – Bldg A/B', category: 'Roof', budget: 640000, actual: 512000, complete: 78, forecast: 668000 },
    { id: 'cx2', propertyId: 'maple', name: 'HVAC overhaul – rooftop units', category: 'HVAC', budget: 420000, actual: 289000, complete: 70, forecast: 411000 },
    { id: 'cx3', propertyId: 'cedar', name: 'Exterior paint & siding repair', category: 'Exterior', budget: 180000, actual: 121000, complete: 68, forecast: 176000 },
    { id: 'cx4', propertyId: 'oakline', name: 'Parking lot resurfacing', category: 'Site', budget: 95000, actual: 101500, complete: 100, forecast: 101500 },
    { id: 'cx5', propertyId: 'birch', name: 'Interior unit upgrades (12 units)', category: 'Interiors', budget: 310000, actual: 142000, complete: 46, forecast: 322000 },
    { id: 'cx6', propertyId: 'harbor', name: 'Pool deck & fitness center', category: 'Amenity', budget: 150000, actual: 88000, complete: 60, forecast: 148000 },
  ]

  // ---------- Lease expirations (next 90 days), derived from the unit records ----------
  const leases = []
  units.filter((u) => !u.vacant).forEach((u) => {
    const dIn = Math.round((u.leaseEnd - NOW) / DAY)
    if (dIn > 90) return
    const late = dIn / 90
    const r = rnd()
    const status = r < 0.42 - late * 0.3 ? 'Renewed' : r < 0.7 - late * 0.12 ? 'Offer sent' : r < 0.88 ? 'No response' : 'Notice to vacate'
    const increase = Math.round(between(2.5, 6.5) * 10) / 10
    u.renewal = status
    u.increase = increase
    leases.push({ id: `${u.id}-l`, ...ref(u), tenant: u.tenant, expires: u.leaseEnd, daysOut: dIn, rent: u.rent, increase, status })
  })

  units.forEach((u) => { if (!u.vacant && u.onTime === undefined) u.onTime = int(90, 100) })

  // ---------- Leasing funnel (current week, portfolio level, split by property) ----------
  const weights = properties.map((p) => (p.units - p.occupied + 3) * (p.avgRent / 1800))
  const wSum = weights.reduce((a, b) => a + b, 0)
  const funnelWeek = properties.map((p, i) => {
    const inquiries = Math.round((148 * weights[i]) / wSum)
    const tours = Math.round(inquiries * between(0.46, 0.6))
    const applications = Math.round(tours * between(0.34, 0.44))
    const approved = Math.round(applications * between(0.66, 0.78))
    const leasesSigned = Math.round(approved * between(0.72, 0.85))
    return { propertyId: p.id, inquiries, tours, applications, approved, leasesSigned }
  })

  return {
    asOf: NOW,
    properties,
    delinquents,
    loans,
    completedTurns,
    vacantNow,
    workOrders,
    resolution,
    OPEN_STATUSES,
    capex,
    leases,
    units,
    unitIndex,
    tenants: units.filter((u) => !u.vacant).map((u) => ({ id: u.id, name: u.tenant, unitId: u.id, email: u.email, phone: u.phone })),
    funnelWeek,
    monthLabels: MONTH_LABELS,
  }
}

export const DATA = buildPortfolio()
