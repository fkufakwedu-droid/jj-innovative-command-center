import { NOW } from './portfolio'

export const RANGES = [
  { id: 'week', label: 'This Week' },
  { id: 'mtd', label: 'MTD' },
  { id: 'qtd', label: 'QTD' },
  { id: 't12', label: 'T12' },
]

export const DSCR_GREEN = 1.25
export const DSCR_YELLOW = 1.15
export const TURN_TARGET = 10
const DAY = 86400000

export const dscrStatus = (v) => (v >= DSCR_GREEN ? 'green' : v >= DSCR_YELLOW ? 'yellow' : 'red')

function rangeWindow(range) {
  const dom = NOW.getDate()
  const dim = new Date(NOW.getFullYear(), NOW.getMonth() + 1, 0).getDate()
  const qStart = new Date(NOW.getFullYear(), Math.floor(NOW.getMonth() / 3) * 3, 1)
  const qDays = Math.max(1, Math.round((NOW - qStart) / DAY) + 1)
  switch (range) {
    case 'week':
      return { days: 7, months: 7 / 30.4, weeks: 8, funnelScale: 1, cashPts: 7, collectOffset: -4.6, label: 'this week' }
    case 'mtd':
      return { days: dom, months: dom / dim, weeks: 12, funnelScale: dom / 7, cashPts: 30, collectOffset: 0, label: 'month to date' }
    case 'qtd':
      return { days: qDays, months: qDays / 30.4, weeks: 26, funnelScale: qDays / 7, cashPts: 90, collectOffset: 0.9, label: 'quarter to date' }
    default:
      return { days: 365, months: 12, weeks: 52, funnelScale: 52, cashPts: 365, collectOffset: 1.3, label: 'trailing 12 months' }
  }
}

// Sum the last `k` months of a series, supporting fractional k.
function sumLast(series, k, key) {
  const full = Math.floor(k)
  let total = 0
  for (let i = 0; i < full; i++) total += series[series.length - 1 - i][key]
  const frac = k - full
  if (frac > 0 && series.length - 1 - full >= 0) total += series[series.length - 1 - full][key] * frac
  return total
}

export function computeMetrics(data, ids, range) {
  const props = ids.length ? data.properties.filter((p) => ids.includes(p.id)) : data.properties
  const sel = new Set(props.map((p) => p.id))
  const w = rangeWindow(range)
  const inSel = (r) => sel.has(r.propertyId)

  // ---------- 1. Cash ----------
  const cash = props.reduce(
    (a, p) => ({
      operating: a.operating + p.cash.operating,
      reserve: a.reserve + p.cash.reserve,
      escrow: a.escrow + p.cash.escrow,
      total: a.total + p.cash.total,
      outflow: a.outflow + p.monthlyOutflow,
    }),
    { operating: 0, reserve: 0, escrow: 0, total: 0, outflow: 0 },
  )
  const runwayDays = cash.total / (cash.outflow / 30)
  const fullSeries = props[0].cashSeries.map((_, i) => props.reduce((a, p) => a + p.cashSeries[i], 0))
  const slice = fullSeries.slice(-w.cashPts)
  const step = Math.max(1, Math.floor(slice.length / 60))
  const cashSeries = slice
    .map((v, i) => ({ i, v, label: new Date(NOW.getTime() - (slice.length - 1 - i) * DAY).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) }))
    .filter((_, i, a) => i % step === 0 || i === a.length - 1)
  const cashDelta = slice[slice.length - 1] - slice[0]
  const cashByProperty = props.map((p) => ({
    id: p.id,
    name: p.name,
    ...p.cash,
    days: p.cash.total / (p.monthlyOutflow / 30),
    color: p.color,
  }))

  // ---------- 2. Occupancy ----------
  const units = props.reduce((a, p) => a + p.units, 0)
  const occupied = props.reduce((a, p) => a + p.occupied, 0)
  const gpr = props.reduce((a, p) => a + p.gpr, 0)
  const billed = props.reduce((a, p) => a + p.billed, 0)
  const netBilled = props.reduce((a, p) => a + p.netBilled, 0)
  const collected = props.reduce((a, p) => a + p.collected, 0)
  const concessions = billed - netBilled
  const uncollected = netBilled - collected
  const vacancyLoss = gpr - billed
  const occTrend = Array.from({ length: w.weeks }, (_, i) => {
    const idx = 52 - w.weeks + i
    let ph = 0
    let ec = 0
    props.forEach((p) => {
      ph += p.occHistory[idx].physical * p.units
      ec += p.occHistory[idx].economic * p.units
    })
    return { label: i === w.weeks - 1 ? 'Now' : `-${w.weeks - 1 - i}w`, physical: ph / units, economic: ec / units }
  })
  const occupancy = {
    units,
    occupied,
    vacant: units - occupied,
    physical: (occupied / units) * 100,
    economic: (collected / gpr) * 100,
    gpr,
    billed,
    collected,
    vacancyLoss,
    concessions,
    uncollected,
    trend: occTrend,
    byProperty: props.map((p) => ({ name: p.name, physical: (p.occupied / p.units) * 100, economic: (p.collected / p.gpr) * 100, color: p.color })),
  }

  // ---------- 3. Collections & delinquency ----------
  const delinq = data.delinquents.filter(inSel)
  const buckets = [
    { key: '30', label: '1–30 days', min: 0, max: 30, color: '#fbbf24' },
    { key: '60', label: '31–60 days', min: 31, max: 60, color: '#fb923c' },
    { key: '90', label: '61–90 days', min: 61, max: 90, color: '#f87171' },
    { key: '90+', label: '90+ days', min: 91, max: 9999, color: '#e11d48' },
  ].map((b) => {
    const rows = delinq.filter((d) => d.days >= b.min && d.days <= b.max)
    return { ...b, count: rows.length, amount: rows.reduce((a, d) => a + d.balance, 0) }
  })
  const collectionRate = Math.min(99.4, (collected / netBilled) * 100 + w.collectOffset)
  const collections = {
    rate: collectionRate,
    netBilled,
    collected,
    delinquentTotal: delinq.reduce((a, d) => a + d.balance, 0),
    delinquentCount: delinq.length,
    buckets,
    rows: [...delinq].sort((a, b) => b.balance - a.balance),
    over60: delinq.filter((d) => d.days > 60),
  }

  // ---------- 4. DSCR ----------
  const basisMonths = range === 't12' ? 12 : 3
  const loans = data.loans.filter(inSel).map((l) => {
    const p = data.properties.find((x) => x.id === l.propertyId)
    const noi = (sumLast(p.months, basisMonths, 'noi') / basisMonths) * 12
    const dscr = noi / l.annualDS
    return { ...l, noi, dscr, status: dscrStatus(dscr), monthlyDS: l.annualDS / 12, color: p.color }
  })
  const totalNoi = loans.reduce((a, l) => a + l.noi, 0)
  const totalDS = loans.reduce((a, l) => a + l.annualDS, 0)
  const portfolioDscr = totalNoi / totalDS
  const dscr = {
    value: portfolioDscr,
    status: dscrStatus(portfolioDscr),
    loans,
    alerts: loans.filter((l) => l.status !== 'green'),
    monthlyDS: totalDS / 12,
    balance: loans.reduce((a, l) => a + l.balance, 0),
    basis: range === 't12' ? 'T12 NOI' : 'T3 NOI annualized',
  }

  // ---------- 5. Days to turn ----------
  const winStart = NOW.getTime() - w.days * DAY
  const longWindow = data.completedTurns.filter(inSel).filter((t) => t.moveOut.getTime() >= NOW.getTime() - Math.max(w.days, 90) * DAY)
  const inRange = data.completedTurns.filter(inSel).filter((t) => t.moveOut.getTime() >= winStart)
  const turnBase = inRange.length >= 4 ? inRange : longWindow
  const avgTurn = turnBase.reduce((a, t) => a + t.days, 0) / (turnBase.length || 1)
  const turnTrend = Array.from({ length: 12 }, (_, i) => {
    const end = NOW.getTime() - (11 - i) * 7 * DAY
    const start = end - 28 * DAY
    const rows = data.completedTurns.filter(inSel).filter((t) => t.moveOut.getTime() >= start && t.moveOut.getTime() < end)
    const sourceRows = rows.length ? rows : turnBase
    return { label: `W${i + 1}`, avg: sourceRows.reduce((a, t) => a + t.days, 0) / sourceRows.length }
  })
  turnTrend[11].avg = avgTurn
  const vacantNow = data.vacantNow.filter(inSel).sort((a, b) => b.days - a.days)
  const turns = {
    avg: avgTurn,
    target: TURN_TARGET,
    completed: turnBase.length,
    vacantNow,
    over15: vacantNow.filter((v) => v.days > 15),
    trend: turnTrend,
    byProperty: props.map((p) => {
      const rows = turnBase.filter((t) => t.propertyId === p.id)
      return { name: p.name, avg: rows.length ? rows.reduce((a, t) => a + t.days, 0) / rows.length : p.turnMean, color: p.color }
    }),
  }

  // ---------- 6. T12 NOI ----------
  const months = data.monthLabels.map((m, i) => {
    const rev = props.reduce((a, p) => a + p.months[i].revenue, 0)
    const opex = props.reduce((a, p) => a + p.months[i].opex, 0)
    return { label: m.label, revenue: rev, opex, noi: rev - opex, ratio: (opex / rev) * 100 }
  })
  const win = (key) => props.reduce((a, p) => a + sumLast(p.months, w.months, key), 0)
  const wRev = win('revenue')
  const wOpex = win('opex')
  const noi = {
    months,
    windowNoi: wRev - wOpex,
    windowRev: wRev,
    windowOpex: wOpex,
    opexRatio: (wOpex / wRev) * 100,
    margin: ((wRev - wOpex) / wRev) * 100,
    t12Noi: months.reduce((a, m) => a + m.noi, 0),
    momChange: ((months[11].noi - months[10].noi) / months[10].noi) * 100,
    yoyHalf: ((months.slice(6).reduce((a, m) => a + m.noi, 0) / months.slice(0, 6).reduce((a, m) => a + m.noi, 0)) - 1) * 100,
  }

  // ---------- 7. Funnel ----------
  const f = data.funnelWeek.filter(inSel)
  const stages = [
    { key: 'inquiries', label: 'Inquiries' },
    { key: 'tours', label: 'Scheduled Tours' },
    { key: 'applications', label: 'Applications' },
    { key: 'approved', label: 'Approved' },
    { key: 'leasesSigned', label: 'Leases Signed' },
  ].map((s) => ({ ...s, value: Math.round(f.reduce((a, r) => a + r[s.key], 0) * w.funnelScale) }))
  stages.forEach((s, i) => {
    s.rate = i === 0 ? 100 : (s.value / (stages[i - 1].value || 1)) * 100
    s.overall = (s.value / (stages[0].value || 1)) * 100
  })
  const funnel = { stages, scaleLabel: w.label }

  // ---------- 8. Work orders (single table: open + closed) ----------
  const allWO = data.workOrders.filter(inSel)
  const wo = allWO.filter((o) => o.status !== 'Closed')
  const closedRecent = allWO.filter((o) => o.status === 'Closed' && NOW.getTime() - o.closedAt.getTime() <= 90 * DAY)
  const avgHrs = (rows, fallback) => (rows.length ? rows.reduce((a, o) => a + o.hours, 0) / rows.length : fallback)
  const prio = ['Emergency', 'Urgent', 'Routine'].map((k) => {
    const rows = wo.filter((o) => o.priority === k)
    return {
      key: k,
      count: rows.length,
      aged: rows.filter((o) => o.age > 7).length,
      avgAge: rows.reduce((a, o) => a + o.age, 0) / (rows.length || 1),
      resolutionHrs: avgHrs(closedRecent.filter((o) => o.priority === k), data.resolution[k]),
    }
  })
  const workOrders = {
    open: wo.length,
    byPriority: prio,
    aged: wo.filter((o) => o.age > 7).sort((a, b) => b.age - a.age),
    rows: [...wo].sort((a, b) => b.age - a.age),
    awaitingInspection: wo.filter((o) => o.status === 'Awaiting inspection').length,
    avgResolutionHrs: avgHrs(closedRecent, 0),
    closedRecent: closedRecent.length,
  }

  // ---------- 9. CapEx ----------
  const projects = data.capex.filter(inSel).map((c) => {
    const p = data.properties.find((x) => x.id === c.propertyId)
    return { ...c, property: p.name, variance: c.forecast - c.budget, variancePct: ((c.forecast - c.budget) / c.budget) * 100, spentPct: (c.actual / c.budget) * 100, color: p.color }
  })
  const capex = {
    projects,
    budget: projects.reduce((a, c) => a + c.budget, 0),
    actual: projects.reduce((a, c) => a + c.actual, 0),
    forecast: projects.reduce((a, c) => a + c.forecast, 0),
    over: projects.filter((c) => c.variance > 0),
  }
  capex.variance = capex.forecast - capex.budget

  // ---------- 10. Lease expirations ----------
  const ls = data.leases.filter(inSel)
  const lb = [
    { key: '30', label: 'Next 30 days', min: 0, max: 30 },
    { key: '60', label: '31–60 days', min: 31, max: 60 },
    { key: '90', label: '61–90 days', min: 61, max: 90 },
  ].map((b) => {
    const rows = ls.filter((l) => l.daysOut >= b.min && l.daysOut <= b.max)
    const by = (s) => rows.filter((r) => r.status === s).length
    return {
      ...b,
      count: rows.length,
      Renewed: by('Renewed'),
      'Offer sent': by('Offer sent'),
      'No response': by('No response'),
      'Notice to vacate': by('Notice to vacate'),
      rows,
    }
  })
  const leases = {
    buckets: lb,
    rows: [...ls].sort((a, b) => a.daysOut - b.daysOut),
    total: ls.length,
    atRisk: ls.filter((l) => l.daysOut <= 30 && (l.status === 'No response' || l.status === 'Notice to vacate')),
    renewalRate: (ls.filter((l) => l.status === 'Renewed').length / (ls.length || 1)) * 100,
  }

  // ---------- Executive alerts ----------
  const alerts = []
  if (dscr.alerts.length)
    alerts.push({ id: 'dscr', tone: dscr.alerts.some((a) => a.status === 'red') ? 'red' : 'yellow', text: `${dscr.alerts.length} DSCR alert${dscr.alerts.length > 1 ? 's' : ''} detected`, modal: 'dscr' })
  if (turns.over15.length)
    alerts.push({ id: 'turns', tone: 'yellow', text: `${turns.over15.length} unrented turns exceeding 15 days`, modal: 'turns' })
  alerts.push({ id: 'cash', tone: runwayDays < 45 ? 'yellow' : 'green', text: `Cash runway at ${Math.round(runwayDays)} days`, modal: 'cash' })
  if (workOrders.aged.length)
    alerts.push({ id: 'wo', tone: 'yellow', text: `${workOrders.aged.length} work orders aged >7 days`, modal: 'workorders' })
  if (collections.over60.length)
    alerts.push({ id: 'delinq', tone: 'red', text: `${collections.over60.length} tenants 60+ days late · ${Math.round(collections.over60.reduce((a, d) => a + d.balance, 0) / 1000)}K owed`, modal: 'delinquency' })
  if (leases.atRisk.length)
    alerts.push({ id: 'leases', tone: 'yellow', text: `${leases.atRisk.length} leases expiring in 30 days with no renewal`, modal: 'leases' })
  if (capex.over.length)
    alerts.push({ id: 'capex', tone: 'yellow', text: `${capex.over.length} CapEx project${capex.over.length > 1 ? 's' : ''} forecast over budget`, modal: 'capex' })

  return {
    window: w,
    scope: ids.length ? props.map((p) => p.name).join(' + ') : 'Portfolio-wide',
    units,
    cash: { ...cash, runwayDays, series: cashSeries, delta: cashDelta, deltaPct: (cashDelta / slice[0]) * 100, byProperty: cashByProperty },
    occupancy,
    collections,
    dscr,
    turns,
    noi,
    funnel,
    workOrders,
    capex,
    leases,
    alerts,
  }
}
