import { DATA, NOW, CLIENT } from './portfolio'
import { computeMetrics } from './metrics'
import { mulberry32 } from '../lib/rng'

/*
 * Contact directory (demo data only). Every person or company shown anywhere (tenant, lender, vendor / trade,
 * contractor, realtor, maintenance staff) resolves to a contact with details and a full communication history.
 * All of it is derived deterministically from the portfolio records and a per-contact seed, so it is stable on
 * every load and never touches the portfolio's own random sequence. Swap getContact() for your CRM / n8n feed.
 *
 * Contact ids:  t-<unitId> tenant · lender-<slug> · v-<slug> vendor · s-<slug> staff · c-<slug> contractor · r-<slug> realtor
 */
const DAY = 86400000
const HOUR = 3600000
const hash = (str) => {
  let h = 2166136261
  for (let i = 0; i < str.length; i++) h = Math.imul(h ^ str.charCodeAt(i), 16777619)
  return h >>> 0
}
const slug = (t) => String(t).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
const initialsEmail = (name, domain) => `${slug(name).replace(/-/g, '.')}@${domain}`

export const TYPE_LABEL = { text: 'Text', email: 'Email', call: 'Phone call', mail: 'Snail mail' }
export const TYPES = ['text', 'email', 'call', 'mail']

const STREETS = ['Maple Ave', 'Cedar Lane', 'Harbor Dr', 'Oak Street', 'Birch Way', 'Ridge Rd', 'Lakeview Blvd', 'Park Place', 'Mill Street', 'Summit Ave']
const street = (key) => {
  const h = hash(key)
  return `${100 + (h % 880)} ${STREETS[(h >>> 9) % STREETS.length]}`
}
const CITY = 'Demo City, ST 00000'
const phoneFor = (key) => `555-0${200 + (hash(`ph-${key}`) % 790)}`

const LENDER_REPS = ['Patricia Hale', 'Gordon Wu', 'Renee Castellano', 'Samuel Okoye', 'Dana Whitfield']
const REALTORS = [
  { name: 'Jordan Pierce', company: 'Keystone Realty Group' },
  { name: 'Alicia Moreno', company: 'Northgate Leasing Partners' },
  { name: 'Brandon Kerr', company: 'Summit & Co. Realtors' },
  { name: 'Tasha Bell', company: 'Harborline Brokerage' },
]
const CONTRACTORS = {
  Roof: { company: 'Summit Roofing Co.', person: 'Hank Dobrow', trade: 'Roofing' },
  HVAC: { company: 'Northline Mechanical', person: 'Priya Raman', trade: 'HVAC' },
  Exterior: { company: 'Cornerstone Exteriors', person: 'Luis Barrera', trade: 'Exterior & siding' },
  Site: { company: 'BlackTop Paving Inc.', person: 'Wanda Frisk', trade: 'Paving' },
  Interiors: { company: 'Fairview Interiors', person: 'Cole Matheson', trade: 'Interior finishes' },
  Amenity: { company: 'AquaFit Builders', person: 'Noor Haddad', trade: 'Amenity build-out' },
}
const VENDORS = {
  proflow: { company: 'ProFlow Plumbing & Drain', person: 'Marcus Reid', trade: 'Plumbing' },
  coolair: { company: 'CoolAir HVAC Services', person: 'Elena Ortiz', trade: 'HVAC' },
}

/* ---------- id helpers used by the UI ---------- */
export const assigneeContactId = (name) => (String(name).startsWith('Vendor:') ? `v-${slug(String(name).slice(7))}` : `s-${slug(name)}`)
export const lenderContactId = (lender) => `lender-${slug(lender)}`
export const contractorFor = (project) => {
  const c = CONTRACTORS[project.category] || { company: `${project.category || 'General'} Contractors`, person: 'Site manager', trade: project.category || 'General' }
  return { id: `c-${slug(c.company)}`, name: c.company }
}
export function realtorForUnit(unit) {
  if (!unit || !unit.vacant || !['Listed', 'Pre-leased'].includes(unit.vacantStatus)) return null
  const r = REALTORS[hash(unit.id) % REALTORS.length]
  return { id: `r-${slug(r.name)}`, name: r.name, company: r.company }
}

/* ---------- communication generators ---------- */
const entry = (rnd, type, direction, ago, subject, summary, ref) => ({
  type,
  direction,
  at: new Date(NOW.getTime() - ago * DAY - Math.floor(rnd() * 7) * HOUR),
  subject,
  summary,
  ref,
})
const scatter = (rnd, templates, n, maxAgo) =>
  Array.from({ length: n }, () => {
    const t = templates[Math.floor(rnd() * templates.length)]
    return entry(rnd, t.type, t.dir || (rnd() < 0.7 ? 'out' : 'in'), 2 + Math.floor(rnd() * (maxAgo - 2)), t.subject, t.summary)
  })

const TENANT_T = [
  { type: 'email', subject: 'Rent reminder', summary: 'Sent the monthly rent reminder.' },
  { type: 'email', subject: 'Lease renewal information', summary: 'Sent renewal options and the timeline.' },
  { type: 'email', subject: 'Building notice', summary: 'Emailed the upcoming maintenance schedule for the building.' },
  { type: 'text', subject: 'Maintenance window', summary: 'Confirmed the maintenance visit window.' },
  { type: 'text', subject: 'Building notice', summary: 'Texted building notice: water shut-off Tuesday 9–11 am.' },
  { type: 'text', subject: 'Parking', summary: 'Sent parking permit instructions.' },
  { type: 'call', subject: 'Parking permit', summary: 'Spoke about the parking permit.' },
  { type: 'call', subject: 'Package room', summary: 'Follow-up on package room access.' },
  { type: 'mail', dir: 'out', subject: 'House rules update', summary: 'Mailed the updated house rules and quiet hours.' },
  { type: 'mail', dir: 'out', subject: 'Annual inspection notice', summary: 'Mailed 48-hour notice for the annual unit inspection.' },
]
const LENDER_T = [
  { type: 'email', dir: 'out', subject: 'Quarterly covenant certificate', summary: 'Sent the quarterly covenant compliance certificate.' },
  { type: 'email', dir: 'in', subject: 'Reporting request', summary: 'Lender requested updated rent roll and operating statement.' },
  { type: 'call', subject: 'Quarterly check-in', summary: 'Quarterly call on performance and upcoming capital plans.' },
  { type: 'mail', dir: 'in', subject: 'Annual escrow statement', summary: 'Received the annual escrow analysis by post.' },
  { type: 'mail', dir: 'in', subject: 'Payment coupon', summary: 'Received the coupon book / payment notice.' },
  { type: 'text', dir: 'out', subject: 'Wire confirmation', summary: 'Texted wire confirmation for the monthly debt service.' },
]
const VENDOR_T = [
  { type: 'text', dir: 'out', subject: 'Dispatch', summary: 'Texted the access details for the next job.' },
  { type: 'call', subject: 'Scheduling', summary: 'Called to confirm the visit window.' },
  { type: 'email', dir: 'in', subject: 'Invoice', summary: 'Received the invoice for completed work.' },
  { type: 'mail', dir: 'in', subject: 'Certificate of insurance', summary: 'Received the renewed certificate of insurance.' },
]
const STAFF_T = [
  { type: 'text', dir: 'out', subject: 'Shift update', summary: 'Texted the schedule change for the week.' },
  { type: 'call', subject: 'Parts question', summary: 'Called about parts for an open ticket.' },
  { type: 'email', dir: 'out', subject: 'Safety reminder', summary: 'Emailed the monthly safety reminder.' },
  { type: 'mail', dir: 'out', subject: 'Training certificate', summary: 'Mailed the completed training certificate.' },
]
const CONTRACTOR_T = [
  { type: 'email', dir: 'in', subject: 'Draw request', summary: 'Received the monthly draw request with backup.' },
  { type: 'email', dir: 'out', subject: 'Change order', summary: 'Sent the approved change order.' },
  { type: 'call', subject: 'Progress call', summary: 'Weekly progress call with the site manager.' },
  { type: 'text', subject: 'Site access', summary: 'Texted gate code and site access times.' },
  { type: 'mail', dir: 'in', subject: 'Lien waiver', summary: 'Received the signed lien waiver by post.' },
]
const REALTOR_T = [
  { type: 'email', dir: 'in', subject: 'Showing request', summary: 'Showing request for a listed unit.' },
  { type: 'text', subject: 'Tour confirmation', summary: 'Confirmed tour times with the prospect.' },
  { type: 'call', subject: 'Pre-lease terms', summary: 'Discussed pre-lease terms and move-in date.' },
  { type: 'mail', dir: 'out', subject: 'Listing agreement', summary: 'Mailed the signed listing agreement.' },
]

let _loans
const dscrLoans = () => (_loans ||= computeMetrics(DATA, [], 't12').dscr.loans)

function tenantComms(unit, rnd) {
  const out = scatter(rnd, TENANT_T, 6 + Math.floor(rnd() * 5), 360)
  const delinq = DATA.delinquents.find((d) => d.unitId === unit.id)
  const lease = DATA.leases.find((l) => l.unitId === unit.id)
  const ago = (n) => Math.max(1, Math.round(n))

  const movedIn = Math.round((NOW - unit.moveIn) / DAY)
  out.push(entry(rnd, 'mail', 'out', movedIn, 'Welcome letter', 'Mailed the welcome packet, house rules and amenity guide.'))
  out.push(entry(rnd, 'email', 'out', Math.round((NOW - unit.leaseStart) / DAY) + 20, 'Lease documents', 'Sent the lease for e-signature.'))

  if (lease) {
    const offerAgo = ago(90 - lease.daysOut)
    out.push(entry(rnd, 'mail', 'out', offerAgo, 'Renewal offer letter', `Mailed the renewal offer (+${lease.increase}%).`))
    out.push(entry(rnd, 'email', 'out', ago(offerAgo - 1), 'Renewal offer', 'Emailed a copy of the renewal offer.'))
    if (lease.status === 'Renewed') out.push(entry(rnd, 'email', 'in', ago(offerAgo - 9), 'Signed renewal', 'Tenant returned the signed renewal.'))
    if (lease.status === 'Notice to vacate') out.push(entry(rnd, 'mail', 'in', ago(offerAgo - 12), 'Notice to vacate', 'Received written notice to vacate at lease end.'))
    if (lease.status === 'No response') out.push(entry(rnd, 'call', 'out', ago(offerAgo - 14), 'Renewal follow-up', 'Left a voicemail about the renewal offer; no reply yet.'))
  }
  if (delinq) {
    const late = delinq.days
    out.push(entry(rnd, 'text', 'out', ago(late - 1), 'Rent reminder', `Text reminder: rent balance is past due.`))
    out.push(entry(rnd, 'email', 'out', ago(late - 3), 'Past-due notice', `Emailed the past-due notice (${delinq.status}).`))
    if (late > 14) out.push(entry(rnd, 'call', 'out', ago(late - 10), 'Balance call', 'Called about the balance and left a voicemail.'))
    if (delinq.status === 'Payment plan') out.push(entry(rnd, 'call', 'in', ago(late - 18), 'Payment plan', 'Tenant called back and agreed a payment plan.'))
    if (late > 30) out.push(entry(rnd, 'mail', 'out', ago(late - 30), 'Formal late-rent notice', 'Mailed the formal notice of late rent.'))
    if (delinq.status === 'Eviction filed') out.push(entry(rnd, 'mail', 'out', ago(late - 70), 'Notice of filing', 'Mailed the notice of court filing.'))
  }
  DATA.workOrders
    .filter((w) => w.tenantId === unit.id)
    .forEach((w) => {
      const openedAgo = Math.max(0, Math.round((NOW - w.openedAt) / DAY))
      out.push(entry(rnd, rnd() < 0.5 ? 'call' : 'text', 'in', openedAgo, `Request ${w.id}`, `Tenant reported: ${w.title}.`, { type: 'wo', id: w.id }))
      out.push(entry(rnd, 'text', 'out', Math.max(0, openedAgo - 1), `Scheduled ${w.id}`, `Technician ${w.assignee} scheduled for ${w.title.toLowerCase()}.`, { type: 'wo', id: w.id }))
      if (w.status === 'Closed' && w.closedAt) out.push(entry(rnd, 'text', 'out', Math.max(0, Math.round((NOW - w.closedAt) / DAY)), `Closed ${w.id}`, 'Work order closed; asked the tenant to confirm the repair.', { type: 'wo', id: w.id }))
    })
  return out
}

function finish(id, comms) {
  return comms
    .sort((a, b) => b.at - a.at)
    .map((c, i) => ({ ...c, id: `${id}-${i}` }))
}

/* ---------- contact builders ---------- */
function tenantContact(unitId) {
  const unit = DATA.unitIndex[unitId]
  if (!unit || unit.vacant) return null
  const id = `t-${unitId}`
  const rnd = mulberry32(hash(id))
  const delinq = DATA.delinquents.find((d) => d.unitId === unitId)
  const open = DATA.workOrders.filter((w) => w.tenantId === unitId && w.status !== 'Closed')
  return {
    id,
    kind: 'tenant',
    name: unit.tenant,
    role: 'Tenant',
    company: unit.property,
    phone: unit.phone,
    email: unit.email,
    address: `${street(unit.propertyId)}, Unit ${unit.number}`,
    city: CITY,
    facts: [
      { label: 'Unit', route: { type: 'unit', id: unit.id }, text: `${unit.property} · ${unit.number}` },
      { label: 'Monthly rent', text: `$${unit.rent.toLocaleString('en-US')}` },
      { label: 'Account', text: delinq ? `${delinq.days} days late · $${delinq.balance.toLocaleString('en-US')} due` : 'Current on rent' },
    ],
    related: [
      { label: 'Tenant dashboard', route: { type: 'tenant', id: unitId } },
      { label: `Unit ${unit.number} dashboard`, route: { type: 'unit', id: unit.id } },
      ...open.slice(0, 5).map((w) => ({ label: `${w.id} · ${w.title}`, route: { type: 'wo', id: w.id } })),
    ],
    comms: finish(id, tenantComms(unit, rnd)),
  }
}

function lenderContact(rest) {
  const loans = DATA.loans.filter((l) => slug(l.lender) === rest)
  if (!loans.length) return null
  const id = `lender-${rest}`
  const rnd = mulberry32(hash(id))
  const company = loans[0].lender
  const person = LENDER_REPS[hash(id) % LENDER_REPS.length]
  const comms = scatter(rnd, LENDER_T, 9 + Math.floor(rnd() * 5), 360)
  const status = Object.fromEntries(dscrLoans().map((l) => [l.id, l]))
  loans.forEach((l) => {
    const s = status[l.id]
    if (s && s.status !== 'green') comms.push(entry(rnd, 'email', 'in', 4 + Math.floor(rnd() * 20), 'Covenant watch', `DSCR ${s.dscr.toFixed(2)}x on ${l.property}: lender asked for an expense and NOI plan.`, { type: 'page', id: 'loans', params: { property: l.propertyId } }))
  })
  return {
    id,
    kind: 'lender',
    name: company,
    role: 'Lender',
    company,
    person: `${person} · Relationship manager`,
    phone: phoneFor(id),
    email: initialsEmail(person, `${slug(company)}.example.com`),
    address: `${street(id)}, Suite ${100 + (hash(id) % 400)}`,
    city: CITY,
    facts: [
      { label: 'Loans', text: loans.map((l) => `${l.property} (${l.rate.toFixed(2)}%)`).join(', ') },
      { label: 'Balance', text: `$${Math.round(loans.reduce((a, l) => a + l.balance, 0)).toLocaleString('en-US')}` },
    ],
    related: loans.map((l) => ({ label: `${l.property} loan`, route: { type: 'page', id: 'loans', params: { property: l.propertyId } } })),
    comms: finish(id, comms),
  }
}

function assigneeContact(kind, rest) {
  const prefix = kind === 'vendor' ? 'v' : 's'
  const id = `${prefix}-${rest}`
  const names = [...new Set(DATA.workOrders.map((w) => w.assignee))]
  const raw = names.find((n) => assigneeContactId(n) === id)
  if (!raw) return null
  const rnd = mulberry32(hash(id))
  const mine = DATA.workOrders.filter((w) => w.assignee === raw).sort((a, b) => b.openedAt - a.openedAt)
  const comms = scatter(rnd, kind === 'vendor' ? VENDOR_T : STAFF_T, 8 + Math.floor(rnd() * 5), 360)
  mine.slice(0, 12).forEach((w) => {
    const a = Math.max(0, Math.round((NOW - w.openedAt) / DAY))
    comms.push(entry(rnd, 'text', 'out', Math.max(0, a - 1), `Dispatched ${w.id}`, `${w.title} · ${w.property} unit ${w.unit}.`, { type: 'wo', id: w.id }))
    if (kind === 'vendor' && w.status === 'Closed') comms.push(entry(rnd, 'email', 'in', Math.max(0, Math.round((NOW - w.closedAt) / DAY)), `Invoice for ${w.id}`, `Invoice received for ${w.title.toLowerCase()}.`, { type: 'wo', id: w.id }))
  })
  const v = kind === 'vendor' ? VENDORS[rest] || { company: raw.replace('Vendor: ', ''), person: 'Dispatcher', trade: 'General' } : null
  const open = mine.filter((w) => w.status !== 'Closed')
  const name = v ? v.company : raw
  return {
    id,
    kind,
    name,
    role: v ? `${v.trade} vendor` : 'Maintenance technician',
    company: v ? v.company : CLIENT.name || 'Property management',
    person: v ? `${v.person} · Dispatcher` : undefined,
    phone: phoneFor(id),
    email: v ? `dispatch@${slug(v.company)}.example.com` : initialsEmail(raw.replace('.', ''), 'example.com'),
    address: v ? `${street(id)}, ${CITY}` : `${street(CLIENT.name || 'office')} (management office)`,
    city: v ? undefined : CITY,
    facts: [
      { label: 'Open tickets', text: String(open.length) },
      { label: 'Closed tickets', text: String(mine.length - open.length) },
    ],
    related: [
      { label: 'All tickets', route: { type: 'page', id: 'tickets' } },
      ...open.slice(0, 6).map((w) => ({ label: `${w.id} · ${w.title}`, route: { type: 'wo', id: w.id } })),
    ],
    comms: finish(id, comms),
  }
}

function contractorContact(rest) {
  const projects = DATA.capex.map((p) => ({ p, c: contractorFor(p) })).filter((x) => x.c.id === `c-${rest}`)
  if (!projects.length) return null
  const id = `c-${rest}`
  const rnd = mulberry32(hash(id))
  const info = CONTRACTORS[projects[0].p.category] || { company: projects[0].c.name, person: 'Site manager', trade: projects[0].p.category }
  const comms = scatter(rnd, CONTRACTOR_T, 10 + Math.floor(rnd() * 5), 300)
  projects.forEach(({ p }) => comms.push(entry(rnd, 'email', 'out', 3 + Math.floor(rnd() * 25), 'Progress update', `${p.name}: ${p.complete}% complete.`, { type: 'page', id: 'projects', params: { id: p.id } })))
  return {
    id,
    kind: 'contractor',
    name: info.company,
    role: `${info.trade} contractor`,
    company: info.company,
    person: `${info.person} · Site manager`,
    phone: phoneFor(id),
    email: `office@${slug(info.company)}.example.com`,
    address: `${street(id)}, ${CITY}`,
    facts: [{ label: 'CapEx projects', text: projects.map(({ p }) => p.name).join('; ') }],
    related: projects.map(({ p }) => ({ label: p.name, route: { type: 'page', id: 'projects', params: { id: p.id } } })),
    comms: finish(id, comms),
  }
}

function realtorContact(rest) {
  const r = REALTORS.find((x) => slug(x.name) === rest)
  if (!r) return null
  const id = `r-${rest}`
  const rnd = mulberry32(hash(id))
  const listed = DATA.units.filter((u) => realtorForUnit(u)?.id === id)
  const comms = scatter(rnd, REALTOR_T, 8 + Math.floor(rnd() * 4), 240)
  listed.slice(0, 6).forEach((u) => comms.push(entry(rnd, 'email', 'in', Math.min(u.vacantDays, 30), 'Showing request', `Showing request for ${u.property} unit ${u.number}.`)))
  return {
    id,
    kind: 'realtor',
    name: r.name,
    role: 'Leasing agent / realtor',
    company: r.company,
    phone: phoneFor(id),
    email: initialsEmail(r.name, `${slug(r.company)}.example.com`),
    address: `${street(id)}, ${CITY}`,
    facts: [{ label: 'Listings', text: `${listed.length} vacant unit${listed.length === 1 ? '' : 's'}` }],
    related: listed.slice(0, 8).map((u) => ({ label: `${u.property} · ${u.number}`, route: { type: 'unit', id: u.id } })),
    comms: finish(id, comms),
  }
}

/** The contact record (details + full communication history, newest first) or null. */
export function getContact(id) {
  const s = String(id || '')
  const i = s.indexOf('-')
  if (i < 1) return null
  const p = s.slice(0, i)
  const rest = s.slice(i + 1)
  switch (p) {
    case 't': return tenantContact(rest)
    case 'lender': return lenderContact(rest)
    case 'v': return assigneeContact('vendor', rest)
    case 's': return assigneeContact('staff', rest)
    case 'c': return contractorContact(rest)
    case 'r': return realtorContact(rest)
    default: return null
  }
}

/** Every contact id in the demo directory. */
export function allContactIds() {
  const ids = []
  DATA.units.filter((u) => !u.vacant).forEach((u) => ids.push(`t-${u.id}`))
  new Set(DATA.loans.map((l) => lenderContactId(l.lender))).forEach((x) => ids.push(x))
  new Set(DATA.workOrders.map((w) => assigneeContactId(w.assignee))).forEach((x) => ids.push(x))
  new Set(DATA.capex.map((p) => contractorFor(p).id)).forEach((x) => ids.push(x))
  new Set(DATA.units.map((u) => realtorForUnit(u)?.id).filter(Boolean)).forEach((x) => ids.push(x))
  return ids
}

/** Activity log: communications across every contact plus work-order history, newest first. */
export function recentActivity(days = 45) {
  const since = NOW.getTime() - days * DAY
  const rows = []
  allContactIds().forEach((cid) => {
    const c = getContact(cid)
    if (!c) return
    c.comms.forEach((m) => {
      if (m.at.getTime() >= since) rows.push({ id: m.id, at: m.at, type: m.type, direction: m.direction, subject: m.subject, summary: m.summary, ref: m.ref, contact: { id: c.id, name: c.name, kind: c.kind } })
    })
  })
  DATA.workOrders.forEach((w) => {
    w.log.forEach((l, i) => {
      if (l.at.getTime() >= since) rows.push({ id: `${w.id}-log-${i}`, at: l.at, type: 'wo', subject: `${w.id} · ${l.text}`, summary: `${w.title} · ${w.property} unit ${w.unit}`, ref: { type: 'wo', id: w.id }, contact: w.tenantId ? { id: `t-${w.tenantId}`, name: w.tenant, kind: 'tenant' } : { id: assigneeContactId(w.assignee), name: w.assignee, kind: 'staff' } })
    })
  })
  return rows.sort((a, b) => b.at - a.at)
}
