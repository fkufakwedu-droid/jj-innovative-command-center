import { useSyncExternalStore } from 'react'
import { DATA, NOW } from './portfolio'

/*
 * Tiny mutable store over the demo work-order table. Every screen reads
 * DATA.workOrders; actions below mutate it and bump a version so the whole
 * app recomputes (counts, aged tickets, resolution time, alerts).
 */
let version = 0
const subs = new Set()
const bump = () => {
  version += 1
  subs.forEach((f) => f())
}
export const subscribe = (f) => {
  subs.add(f)
  return () => subs.delete(f)
}
export const useVersion = () => useSyncExternalStore(subscribe, () => version)

export const findWorkOrder = (id) => DATA.workOrders.find((w) => w.id === id)
export const isOpen = (w) => w.status !== 'Closed'

/** What is still missing before a work order may be closed. */
export function closeBlockers(w) {
  const missing = []
  if (w.inspectionRequired) {
    if (!w.photos.before.length) missing.push('Before photo')
    if (!w.photos.after.length) missing.push('After photo')
  }
  return missing
}

const addLog = (w, text) => w.log.push({ at: new Date(), text })

export function addPhoto(id, kind, photo) {
  const w = findWorkOrder(id)
  if (!w || w.status === 'Closed') return
  w.photos[kind].push(photo)
  addLog(w, `${kind === 'before' ? 'Before' : 'After'} photo added`)
  bump()
}

export function removePhoto(id, kind, photoId) {
  const w = findWorkOrder(id)
  if (!w || w.status === 'Closed') return
  w.photos[kind] = w.photos[kind].filter((p) => p.id !== photoId)
  addLog(w, `${kind === 'before' ? 'Before' : 'After'} photo removed`)
  bump()
}

export function setStatus(id, status) {
  const w = findWorkOrder(id)
  if (!w || w.status === 'Closed') return { ok: false, error: 'Work order is closed' }
  w.status = status
  addLog(w, `Status changed to ${status}`)
  bump()
  return { ok: true }
}

/** The only way a work order is closed. Enforces the photo rule for inspection work. */
export function closeWorkOrder(id) {
  const w = findWorkOrder(id)
  if (!w) return { ok: false, error: 'Work order not found' }
  const missing = closeBlockers(w)
  if (missing.length) return { ok: false, error: `Cannot close: ${missing.join(' and ')} required`, missing }
  const closedAt = new Date()
  w.status = 'Closed'
  w.closedAt = closedAt
  w.hours = Math.max(0.5, Math.round(((closedAt - w.openedAt) / 3600000) * 10) / 10)
  w.actual = w.actual || w.estimate
  addLog(w, w.inspectionRequired ? 'Inspected · before and after photos attached' : 'Work completed')
  addLog(w, 'Closed')
  bump()
  return { ok: true }
}

export function reopenWorkOrder(id) {
  const w = findWorkOrder(id)
  if (!w || w.status !== 'Closed') return
  w.status = 'In progress'
  w.closedAt = null
  w.hours = null
  addLog(w, 'Reopened')
  bump()
}

export const ageDays = (w) => (w.status === 'Closed' ? w.age : Math.max(0, Math.floor((NOW - w.openedAt) / 86400000)))

/** Draws a clearly-labelled placeholder photo for demo records. */
export function demoPhotoSrc(photo, w) {
  if (photo.src) return photo.src
  const before = photo.kind === 'before'
  const c1 = before ? '#5b3a2e' : '#1f4d3a'
  const c2 = before ? '#2a1a15' : '#0f2a20'
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 220"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient></defs><rect width="320" height="220" fill="url(#g)"/><g fill="none" stroke="rgba(255,255,255,0.18)" stroke-width="2"><rect x="40" y="48" width="240" height="124" rx="10"/><path d="M40 140 L120 96 L180 130 L230 100 L280 140"/></g><text x="160" y="196" text-anchor="middle" font-family="sans-serif" font-size="14" fill="rgba(255,255,255,0.75)">${before ? 'BEFORE' : 'AFTER'} · ${w.id} · demo photo</text></svg>`
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`
}

/** Reads an image file and downsizes it so the demo stays light. */
export function fileToPhoto(file, kind) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onerror = () => reject(new Error('Could not read file'))
    reader.onload = () => {
      const img = new Image()
      img.onerror = () => reject(new Error('That file is not an image'))
      img.onload = () => {
        const max = 1000
        const scale = Math.min(1, max / Math.max(img.width, img.height))
        const canvas = document.createElement('canvas')
        canvas.width = Math.round(img.width * scale)
        canvas.height = Math.round(img.height * scale)
        canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height)
        resolve({ id: `up-${Date.now()}-${Math.floor(Math.random() * 1e4)}`, kind, name: file.name, src: canvas.toDataURL('image/jpeg', 0.82) })
      }
      img.src = reader.result
    }
    reader.readAsDataURL(file)
  })
}
