import { mulberry32 } from '../lib/rng'
import { NOW } from './portfolio'

const DAY = 86400000
const hash = (str) => {
  let h = 2166136261
  for (let i = 0; i < str.length; i++) h = Math.imul(h ^ str.charCodeAt(i), 16777619)
  return h >>> 0
}

const CLOSED_TITLES = ['Replaced smoke detector battery', 'Cleared kitchen drain', 'Serviced thermostat', 'Fixed bedroom outlet', 'Replaced door weatherstrip', 'Re-caulked tub', 'Swapped HVAC filter', 'Repaired window latch']
const TASKS = ['Move-out inspection', 'Paint & patch', 'Flooring / repairs', 'Deep clean', 'Photos & listing live', 'Showings & applications']
const TASK_DONE = { 'Make-ready': 2, 'Awaiting repairs': 2, Listed: 5, 'Pre-leased': 6 }

/**
 * Everything the Unit Dashboard shows for a single unit, built from the
 * portfolio records plus a deterministic per-unit ledger and history.
 */
export function buildUnitDetail(data, unitId) {
  const unit = data.unitIndex[unitId]
  if (!unit) return null
  const prop = data.properties.find((p) => p.id === unit.propertyId)
  const rnd = mulberry32(hash(unitId))
  const pick = (a) => a[Math.floor(rnd() * a.length)]

  const delinquency = data.delinquents.find((d) => d.unitId === unitId) || null
  const unitOrders = data.workOrders.filter((w) => w.unitId === unitId)
  const openOrders = unitOrders.filter((w) => w.status !== 'Closed').sort((a, b) => b.age - a.age)
  const closed = unitOrders
    .filter((w) => w.status === 'Closed')
    .sort((a, b) => b.closedAt - a.closedAt)
    .map((w) => ({ ...w, closedAgo: Math.round((NOW - w.closedAt) / DAY) }))
  const turns = data.completedTurns.filter((t) => t.unitId === unitId).sort((a, b) => b.moveOut - a.moveOut)
  const lease = data.leases.find((l) => l.unitId === unitId) || null

  // Rent ledger: last 6 months charged vs paid
  const vacantSince = unit.vacant ? new Date(NOW.getTime() - unit.vacantDays * DAY) : null
  let unpaidLeft = delinquency ? delinquency.balance : 0
  const ledger = []
  for (let i = 5; i >= 0; i--) {
    const d = new Date(NOW.getFullYear(), NOW.getMonth() - i, 1)
    const monthEnd = new Date(d.getFullYear(), d.getMonth() + 1, 0)
    const label = d.toLocaleDateString('en-US', { month: 'short' })
    if (unit.vacant && vacantSince < monthEnd) {
      const monthDays = monthEnd.getDate()
      const occupiedDays = Math.max(0, Math.min(monthDays, Math.round((vacantSince - d) / DAY)))
      const charged = Math.round((unit.rent * occupiedDays) / monthDays)
      ledger.push({ label, charged, paid: charged })
      continue
    }
    ledger.push({ label, charged: unit.rent, paid: unit.rent })
  }
  if (!unit.vacant) {
    for (let i = ledger.length - 1; i >= 0 && unpaidLeft > 0; i--) {
      const unpaid = Math.min(unpaidLeft, ledger[i].charged)
      ledger[i].paid = ledger[i].charged - unpaid
      unpaidLeft -= unpaid
    }
  }

  const checklist = unit.vacant
    ? TASKS.map((t, i) => ({ task: t, done: i < (TASK_DONE[unit.vacantStatus] ?? 2), blocked: unit.vacantStatus === 'Awaiting repairs' && i === 2 }))
    : []

  // Activity timeline (items may carry a link so tenants and work orders stay clickable)
  const events = []
  if (unit.vacant) {
    events.push({ ago: unit.vacantDays, post: 'Move-out recorded · unit vacant', tone: 'yellow' })
    events.push({ ago: Math.max(0, unit.vacantDays - 3), post: `Stage: ${unit.vacantStatus}`, tone: 'blue' })
  } else {
    events.push({ ago: Math.round((NOW - unit.leaseStart) / DAY), pre: 'Lease started ·', link: { type: 'tenant', id: unit.id, label: unit.tenant }, tone: 'green' })
    if (lease) events.push({ ago: 0, post: `Renewal status: ${lease.status} (+${lease.increase}% offer)`, tone: lease.status === 'Renewed' ? 'green' : lease.status === 'Notice to vacate' ? 'red' : 'yellow' })
    if (delinquency) events.push({ ago: Math.max(0, delinquency.days - 2), post: `Rent late ${delinquency.days} days · ${delinquency.status}`, tone: 'red' })
  }
  openOrders.forEach((w) => events.push({ ago: w.age, link: { type: 'wo', id: w.id, label: w.id }, post: `opened · ${w.title}`, tone: w.priority === 'Emergency' ? 'red' : 'blue' }))
  closed.slice(0, 6).forEach((c) => events.push({ ago: c.closedAgo, link: { type: 'wo', id: c.id, label: c.id }, post: `closed · ${c.title}`, tone: 'slate' }))
  events.sort((a, b) => a.ago - b.ago)

  const marketRent = unit.vacant ? unit.askRent : Math.round(unit.rent * (1.03 + rnd() * 0.05))
  return {
    unit,
    prop,
    delinquency,
    openOrders,
    closed,
    turns,
    lease,
    ledger,
    checklist,
    events,
    marketRent,
    lossToLease: unit.vacant ? 0 : marketRent - unit.rent,
    avgTurn: turns.length ? turns.reduce((a, t) => a + t.days, 0) / turns.length : null,
  }
}
