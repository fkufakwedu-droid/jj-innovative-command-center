import { mulberry32 } from '../lib/rng'
import { NOW } from './portfolio'

const DAY = 86400000
const hash = (str) => {
  let h = 2166136261
  for (let i = 0; i < str.length; i++) h = Math.imul(h ^ str.charCodeAt(i), 16777619)
  return h >>> 0
}
const NOTES = [
  ['Email', 'Sent rent reminder'],
  ['Call', 'Spoke about parking permit'],
  ['Text', 'Confirmed maintenance visit window'],
  ['Email', 'Sent lease renewal information'],
  ['Call', 'Follow-up on package room access'],
  ['Text', 'Sent building notice: water shut-off'],
]

/** Everything the Tenant Dashboard shows, keyed by the tenant's unit id. */
export function buildTenantDetail(data, unitId) {
  const unit = data.unitIndex[unitId]
  if (!unit || unit.vacant) return null
  const prop = data.properties.find((p) => p.id === unit.propertyId)
  const rnd = mulberry32(hash(`tenant-${unitId}`))
  const delinquency = data.delinquents.find((d) => d.unitId === unitId) || null
  const lease = data.leases.find((l) => l.unitId === unitId) || null
  const orders = data.workOrders.filter((w) => w.unitId === unitId && w.tenantId === unitId)
  const open = orders.filter((w) => w.status !== 'Closed').sort((a, b) => b.age - a.age)
  const closed = orders.filter((w) => w.status === 'Closed').sort((a, b) => b.closedAt - a.closedAt)

  let left = delinquency ? delinquency.balance : 0
  const ledger = []
  for (let i = 5; i >= 0; i--) {
    const d = new Date(NOW.getFullYear(), NOW.getMonth() - i, 1)
    ledger.push({ label: d.toLocaleDateString('en-US', { month: 'short' }), charged: unit.rent, paid: unit.rent, due: 0 })
  }
  for (let i = ledger.length - 1; i >= 0 && left > 0; i--) {
    const unpaid = Math.min(left, ledger[i].charged)
    ledger[i].paid = ledger[i].charged - unpaid
    ledger[i].due = unpaid
    left -= unpaid
  }

  const comms = []
  const n = 4 + Math.floor(rnd() * 3)
  for (let i = 0; i < n; i++) {
    const [channel, text] = NOTES[Math.floor(rnd() * NOTES.length)]
    comms.push({ ago: 2 + Math.floor(rnd() * 80), channel, text })
  }
  if (delinquency) comms.push({ ago: Math.max(1, delinquency.days - 3), channel: 'Email', text: `Past-due notice · ${delinquency.status}` })
  comms.sort((a, b) => a.ago - b.ago)

  const events = [
    { ago: Math.round((NOW - unit.moveIn) / DAY), text: 'Moved in', tone: 'green' },
    { ago: Math.round((NOW - unit.leaseStart) / DAY), text: 'Current lease started', tone: 'blue' },
  ]
  if (lease) events.push({ ago: 0, text: `Renewal: ${lease.status}`, tone: lease.status === 'Notice to vacate' ? 'red' : 'yellow' })
  if (delinquency) events.push({ ago: Math.max(0, delinquency.days - 2), text: `Rent late ${delinquency.days} days`, tone: 'red' })
  open.forEach((w) => events.push({ ago: w.age, link: { type: 'wo', id: w.id, label: w.id }, post: `requested · ${w.title}`, tone: 'yellow' }))
  closed.slice(0, 4).forEach((w) => events.push({ ago: Math.round((NOW - w.closedAt) / DAY), link: { type: 'wo', id: w.id, label: w.id }, post: `closed · ${w.title}`, tone: 'slate' }))
  events.sort((a, b) => a.ago - b.ago)

  return {
    unit, prop, delinquency, lease, open, closed, ledger, comms, events,
    tenureMonths: Math.max(1, Math.round((NOW - unit.moveIn) / (30.4 * DAY))),
  }
}
