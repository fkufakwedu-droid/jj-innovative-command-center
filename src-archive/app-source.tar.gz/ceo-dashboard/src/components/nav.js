import { createContext } from 'react'

const noop = () => {}

/**
 * Navigation context shared by every card, tile, row and link.
 *  go(route)               push a route (hash deep link)
 *  openUnit / openTenant / openWorkOrder / openContact(id)
 *  openPage(name, params)  open a source page (Units, Rent arrears, Loans, ...)
 *  pageRoute(name, params) build the route for a source page (adds the current property filter)
 */
export const Nav = createContext({
  go: noop,
  openUnit: noop,
  openTenant: noop,
  openWorkOrder: noop,
  openContact: noop,
  openPage: noop,
  pageRoute: (page, params = {}) => ({ type: 'page', id: page, params }),
})

/** Contact ids: t-<unitId> tenant · lender-<slug> · v-<slug> vendor · s-<slug> staff · c-<slug> contractor · r-<slug> realtor */
export const contactKind = (id) => {
  const p = String(id).split('-')[0]
  return { t: 'tenant', lender: 'lender', v: 'vendor', s: 'staff', c: 'contractor', r: 'realtor' }[p] || 'contact'
}

/** The href of the card an element sits in. A tile that points at the same place adds no extra Tab stop. */
export const CardTarget = createContext(null)
