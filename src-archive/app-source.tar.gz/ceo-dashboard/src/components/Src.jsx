import { useContext } from 'react'
import { ChevronRight, ExternalLink } from 'lucide-react'
import { CardTarget, Nav } from './nav'
import { resolveSource } from '../lib/sources'
import { formatHash } from '../lib/route'

/*
 * Click targets.
 *   { src: 'collections', params: { bucket: '60' } }  -> the source page for that card (client's sourceMap decides)
 *   { route: { type: 'unit', id } , label }            -> a record page (unit, tenant, work order, contact, page)
 * Buttons, links and inputs nested inside a clickable element keep their own action.
 */
export function resolveTarget(target, nav) {
  if (!target) return null
  if (target.src) {
    const s = resolveSource(target.src, target.params)
    if (!s) return null
    if (s.external) return { label: s.label, url: s.url }
    return { label: s.label, route: nav.pageRoute(s.page, s.params) }
  }
  if (target.route) return { label: target.label || 'page', route: target.route }
  return null
}

const INTERACTIVE = 'a[href],button,input,select,textarea,label,summary,[data-own],[role="link"],[role="button"]'

const hasSelection = () => {
  try { return String(window.getSelection() || '').length > 0 } catch { return false }
}

function open(t, nav, e) {
  if (t.url) {
    window.open(t.url, '_blank', 'noopener,noreferrer')
    return
  }
  if (e && (e.metaKey || e.ctrlKey || e.shiftKey)) {
    window.open(`${window.location.pathname}${window.location.search}${formatHash(t.route)}`, '_blank', 'noopener')
    return
  }
  nav.go(t.route)
}

export const hrefOf = (t) => t.url || formatHash(t.route) || '#'

/** Mouse + keyboard handlers shared by Hit and Card. */
export function handlers(t, nav, { keyboard = true } = {}) {
  return {
    onClick: (e) => {
      if (e.defaultPrevented) return
      const inner = e.target.closest?.(INTERACTIVE)
      if (inner && inner !== e.currentTarget && e.currentTarget.contains(inner)) return
      if (hasSelection()) return
      e.stopPropagation()
      open(t, nav, e)
    },
    ...(keyboard
      ? {
          onKeyDown: (e) => {
            if (e.target !== e.currentTarget) return
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault()
              e.stopPropagation()
              open(t, nav, e)
            }
          },
        }
      : {}),
  }
}

/**
 * A keyboard-accessible clickable element (tile, list row, table row, chart legend item...).
 * Renders a plain element when there is no target, so it is always safe to wrap content in it.
 */
export function Hit({ to, as: Tag = 'div', className = '', title, focusable = true, children, ...rest }) {
  const nav = useContext(Nav)
  const cardHref = useContext(CardTarget)
  const t = resolveTarget(to, nav)
  if (!t) return <Tag className={className} {...rest}>{children}</Tag>
  const href = hrefOf(t)
  // Same destination as the card, or a row that already contains links: mouse-clickable, but no extra Tab stop.
  const tabbable = focusable && href !== cardHref
  return (
    <Tag
      {...(tabbable ? { role: 'link', tabIndex: 0 } : {})}
      data-target={href}
      title={title ? `${title} · Source: ${t.label}` : `Source: ${t.label}`}
      className={`src-hit ${className}`}
      {...handlers(t, nav, { keyboard: tabbable })}
      {...rest}
    >
      {children}
    </Tag>
  )
}

/** For chart bars: onClick={(d, i, e) => open({ src: 'collections', params: { bucket } }, e)} */
export function useOpen() {
  const nav = useContext(Nav)
  return (target, e) => {
    const t = resolveTarget(target, nav)
    if (!t) return
    e?.stopPropagation?.()
    open(t, nav, e?.nativeEvent || e)
  }
}

/** The visible "Source: <table or page> ›" label. It is a real link, so it is reachable with Tab and Enter. */
export function SourceLabel({ to, className = '' }) {
  const nav = useContext(Nav)
  const t = resolveTarget(to, nav)
  if (!t) return null
  const ext = !!t.url
  return (
    <a
      href={hrefOf(t)}
      data-own
      data-source-label=""
      {...(ext ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
      onClick={(e) => {
        e.stopPropagation()
        if (ext || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey) return // browser handles new tab / external
        e.preventDefault()
        nav.go(t.route)
      }}
      className={`group/src inline-flex items-center gap-0.5 rounded-md px-1.5 py-1 text-[11px] font-medium text-slate-400 transition hover:bg-white/5 hover:text-sky-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60 ${className}`}
    >
      Source: {t.label}
      {ext ? <ExternalLink className="ml-0.5 h-3 w-3" /> : <ChevronRight className="h-3.5 w-3.5 transition group-hover/src:translate-x-0.5" />}
    </a>
  )
}
