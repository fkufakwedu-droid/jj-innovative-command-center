import { useContext, useEffect, useRef, useState } from 'react'
import { Area, AreaChart, ResponsiveContainer, YAxis } from 'recharts'
import { ArrowDownRight, ArrowUpRight, Briefcase, ChevronDown, ChevronRight, DoorOpen, Hammer, Landmark, UserRound, Wrench, X } from 'lucide-react'
import { CardTarget, Nav, contactKind } from './nav'
import { SourceLabel, handlers, hrefOf, resolveTarget } from './Src'

/* Navigation: every unit, tenant, work order and contact name shown anywhere is a link to its own page. */
export { Nav }

const linkBase =
  'group inline-flex items-center gap-1 rounded-md px-1 py-0.5 text-left font-medium underline decoration-dotted underline-offset-4 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60'

function makeLink(Icon, getOpen, title, tone) {
  return function EntityLink({ id, children, className = '' }) {
    const nav = useContext(Nav)
    return (
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation()
          getOpen(nav)(id)
        }}
        title={title}
        className={`${linkBase} ${tone} ${className}`}
      >
        <Icon className="h-3.5 w-3.5 shrink-0 opacity-70 transition group-hover:opacity-100" />
        {children}
      </button>
    )
  }
}

export const UnitLink = makeLink(DoorOpen, (n) => n.openUnit, 'Open unit dashboard', 'text-sky-300 decoration-sky-400/30 hover:bg-sky-400/10 hover:text-sky-200 hover:decoration-sky-300')
/* A tenant's name opens their contact page (details + full communication history); `id` is the tenant's unit id. */
export const TenantLink = makeLink(UserRound, (n) => (id) => n.openContact(`t-${id}`), 'Open contact page', 'text-violet-300 decoration-violet-400/30 hover:bg-violet-400/10 hover:text-violet-200 hover:decoration-violet-300')

const KIND_ICON = { tenant: UserRound, lender: Landmark, vendor: Hammer, staff: Hammer, contractor: Hammer, realtor: Briefcase, contact: UserRound }

/** Any person or company (lender, vendor, trade, contractor, realtor, staff, tenant): opens the Contact page. */
export function ContactLink({ id, children, className = '' }) {
  const nav = useContext(Nav)
  const Icon = KIND_ICON[contactKind(id)] || UserRound
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation()
        nav.openContact(id)
      }}
      title="Open contact page"
      className={`${linkBase} text-violet-300 decoration-violet-400/30 hover:bg-violet-400/10 hover:text-violet-200 hover:decoration-violet-300 ${className}`}
    >
      <Icon className="h-3.5 w-3.5 shrink-0 opacity-70 transition group-hover:opacity-100" />
      {children}
    </button>
  )
}
export const WorkOrderLink = makeLink(Wrench, (n) => n.openWorkOrder, 'Open work order', 'font-mono text-xs text-amber-300 decoration-amber-400/30 hover:bg-amber-400/10 hover:text-amber-200 hover:decoration-amber-300')

export const TONES = {
  green: { text: 'text-emerald-300', bg: 'bg-emerald-400/10', ring: 'ring-emerald-400/30', dot: 'bg-emerald-400', hex: '#34d399' },
  yellow: { text: 'text-amber-300', bg: 'bg-amber-400/10', ring: 'ring-amber-400/30', dot: 'bg-amber-400', hex: '#fbbf24' },
  red: { text: 'text-rose-300', bg: 'bg-rose-400/10', ring: 'ring-rose-400/30', dot: 'bg-rose-400', hex: '#fb7185' },
  blue: { text: 'text-sky-300', bg: 'bg-sky-400/10', ring: 'ring-sky-400/30', dot: 'bg-sky-400', hex: '#38bdf8' },
  violet: { text: 'text-violet-300', bg: 'bg-violet-400/10', ring: 'ring-violet-400/30', dot: 'bg-violet-400', hex: '#a78bfa' },
  slate: { text: 'text-slate-300', bg: 'bg-slate-400/10', ring: 'ring-slate-400/20', dot: 'bg-slate-400', hex: '#94a3b8' },
}

export function useCountUp(value, ms = 650) {
  const [v, setV] = useState(value)
  const from = useRef(value)
  useEffect(() => {
    const start = performance.now()
    const a = from.current
    let raf
    const tick = (t) => {
      const p = Math.min(1, (t - start) / ms)
      const e = 1 - Math.pow(1 - p, 3)
      setV(a + (value - a) * e)
      if (p < 1) raf = requestAnimationFrame(tick)
      else from.current = value
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [value, ms])
  return v
}

export function Num({ value, format, className = '' }) {
  const v = useCountUp(value)
  return <span className={className}>{format(v)}</span>
}

const COLL_KEY = 'cc-collapsed'
const readColl = () => {
  try { return JSON.parse(localStorage.getItem(COLL_KEY) || '[]') } catch { return [] }
}

/**
 * A dashboard card. `source` is the card's data key (cash, collections, ...): the whole card becomes a link to the
 * page that holds its data, with a visible "Source: ... ›" label. Buttons and links inside keep their own action.
 */
export function Card({ title, icon: Icon, tone = 'blue', right, children, className = '', delay = 0, onOpen, openLabel = 'Details', collapsible = true, source, sourceParams }) {
  const t = TONES[tone]
  const nav = useContext(Nav)
  const to = source ? { src: source, params: sourceParams } : null
  const target = resolveTarget(to, nav)
  const key = `${(typeof window !== 'undefined' && window.CLIENT?.name) || ''}|${title}`
  const [collapsed, setCollapsed] = useState(() => collapsible && readColl().includes(key))
  const toggle = () => {
    setCollapsed((c) => {
      const next = !c
      try {
        const all = readColl().filter((k) => k !== key)
        localStorage.setItem(COLL_KEY, JSON.stringify(next ? [...all, key] : all))
      } catch { /* storage unavailable */ }
      return next
    })
  }
  return (
    <section
      className={`glass glass-hover rise relative flex flex-col rounded-2xl p-4 sm:p-5 ${collapsed ? 'self-start' : ''} ${target ? 'src-card' : ''} ${className}`}
      style={{ animationDelay: `${delay}ms` }}
      {...(target ? { ...handlers(target, nav, { keyboard: false }), 'data-target': hrefOf(target), 'data-card': source } : {})}
    >
      <header className={`${collapsed ? '' : 'mb-3'} flex items-start justify-between gap-3`}>
        <div className="flex min-w-0 items-center gap-2.5">
          {Icon && (
            <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg ring-1 ${t.bg} ${t.ring}`}>
              <Icon className={`h-4 w-4 ${t.text}`} strokeWidth={2} />
            </span>
          )}
          <h2 className="truncate text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-400">{title}</h2>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {!collapsed && right}
          {!collapsed && onOpen && (
            <button
              onClick={onOpen}
              className="group inline-flex items-center gap-0.5 rounded-md px-1.5 py-1 text-[11px] font-medium text-slate-400 transition hover:bg-white/5 hover:text-sky-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60"
            >
              {openLabel}
              <ChevronRight className="h-3.5 w-3.5 transition group-hover:translate-x-0.5" />
            </button>
          )}
          {collapsible && (
            <button
              type="button"
              onClick={toggle}
              aria-expanded={!collapsed}
              aria-label={collapsed ? `Expand ${title}` : `Collapse ${title}`}
              className="rounded-md p-1 text-slate-400 transition hover:bg-white/10 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60"
            >
              <ChevronDown className={`h-4 w-4 transition-transform ${collapsed ? '-rotate-90' : ''}`} />
            </button>
          )}
        </div>
      </header>
      <CardTarget.Provider value={target ? hrefOf(target) : null}>
        {!collapsed && children}
        {!collapsed && target && (
          <footer className="mt-auto flex justify-end pt-3">
            <SourceLabel to={to} />
          </footer>
        )}
      </CardTarget.Provider>
    </section>
  )
}

export function Pill({ tone = 'slate', children, className = '' }) {
  const t = TONES[tone]
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ${t.bg} ${t.text} ${t.ring} ${className}`}>
      {children}
    </span>
  )
}

export function Dot({ tone = 'green', pulse = false }) {
  return <span className={`inline-block h-2 w-2 rounded-full ${TONES[tone].dot} ${pulse ? 'pulse-dot' : ''}`} />
}

export function Delta({ value, suffix = '%', good = 'up', digits = 1, className = '' }) {
  const up = value >= 0
  const isGood = good === 'up' ? up : !up
  const tone = Math.abs(value) < 0.05 ? 'slate' : isGood ? 'green' : 'red'
  const Icon = up ? ArrowUpRight : ArrowDownRight
  return (
    <span className={`inline-flex items-center gap-0.5 text-xs font-medium ${TONES[tone].text} ${className}`}>
      <Icon className="h-3.5 w-3.5" />
      {Math.abs(value).toFixed(digits)}
      {suffix}
    </span>
  )
}

export function Sparkline({ data, dataKey = 'v', color = '#38bdf8', height = 54, id }) {
  const gid = `spark-${id || dataKey}-${color.replace('#', '')}`
  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 4, right: 0, bottom: 0, left: 0 }}>
          <defs>
            <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.45} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <YAxis hide domain={['dataMin - 4000', 'dataMax + 2000']} />
          <Area type="monotone" dataKey={dataKey} stroke={color} strokeWidth={2} fill={`url(#${gid})`} isAnimationActive animationDuration={700} dot={false} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}

export function ProgressBar({ value, max = 100, color = '#38bdf8', marker, height = 8 }) {
  const w = Math.min(100, (value / max) * 100)
  return (
    <div className="relative w-full overflow-hidden rounded-full bg-white/[0.06]" style={{ height }}>
      <div className="h-full rounded-full transition-all duration-700 ease-out" style={{ width: `${w}%`, background: color }} />
      {marker !== undefined && (
        <div className="absolute top-[-2px] h-[calc(100%+4px)] w-[2px] bg-white/70" style={{ left: `${Math.min(100, (marker / max) * 100)}%` }} />
      )}
    </div>
  )
}

export const chartTooltipStyle = {
  contentStyle: {
    background: 'rgba(8, 13, 25, 0.95)',
    border: '1px solid rgba(148, 163, 184, 0.25)',
    borderRadius: 10,
    fontSize: 12,
    color: '#e2e8f0',
    boxShadow: '0 12px 30px rgba(0,0,0,0.5)',
  },
  labelStyle: { color: '#94a3b8', marginBottom: 4 },
  itemStyle: { color: '#e2e8f0' },
  cursor: { stroke: 'rgba(148,163,184,0.3)', fill: 'rgba(148,163,184,0.06)' },
}

export function Modal({ title, subtitle, onClose, children, wide = true, source }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = prev
    }
  }, [onClose])
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-6" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className={`glass pop relative flex max-h-[92vh] w-full flex-col rounded-t-2xl sm:rounded-2xl ${wide ? 'sm:max-w-4xl' : 'sm:max-w-xl'}`} style={{ background: 'linear-gradient(160deg, rgba(20,30,52,0.98), rgba(9,14,27,0.99))' }}>
        <div className="flex items-start justify-between gap-4 border-b border-white/10 px-5 py-4">
          <div>
            <h3 className="text-base font-semibold text-white">{title}</h3>
            {subtitle && <p className="mt-0.5 text-xs text-slate-400">{subtitle}</p>}
          </div>
          <button onClick={onClose} aria-label="Close" className="rounded-lg p-1.5 text-slate-400 transition hover:bg-white/10 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="scroll-thin overflow-y-auto px-5 py-4">{children}</div>
        {source && (
          <div className="flex justify-end border-t border-white/10 px-4 py-2">
            <SourceLabel to={source} />
          </div>
        )}
      </div>
    </div>
  )
}

/**
 * Table. A row is clickable when `rowTo(row)` returns a target ({ route, label } or { src }), or, for older callers,
 * when `rowUnit(row)` returns a unit id. Rows are focusable and open with Enter. `source` adds a visible
 * "Source: ... ›" label under the table.
 */
export function DataTable({ columns, rows, empty = 'Nothing to show', maxHeight = '52vh', rowUnit, rowTo, source, highlight }) {
  const nav = useContext(Nav)
  if (!rows.length) return <p className="py-8 text-center text-sm text-slate-400">{empty}</p>
  const targetOf = (r) => {
    if (rowTo) return resolveTarget(rowTo(r), nav)
    const id = rowUnit && rowUnit(r)
    return id ? resolveTarget({ route: { type: 'unit', id }, label: 'Unit' }, nav) : null
  }
  return (
    <div>
      <div className="scroll-thin overflow-auto rounded-xl border border-white/10" style={{ maxHeight }}>
        <table className="w-full min-w-[560px] text-left text-sm">
          <thead className="sticky top-0 z-10 bg-[#0c1322] text-[11px] uppercase tracking-wider text-slate-400">
            <tr>
              {columns.map((c) => (
                <th key={c.key} className={`px-3 py-2.5 font-semibold ${c.align === 'right' ? 'text-right' : ''}`}>
                  {c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {rows.map((r, i) => {
              const t = targetOf(r)
              return (
                <tr
                  key={r.id || i}
                  {...(t ? { ...handlers(t, nav), tabIndex: 0, 'data-target': hrefOf(t), title: `Open ${t.label}` } : {})}
                  data-highlight={highlight && r.id === highlight ? 'true' : undefined}
                  className={`transition hover:bg-white/[0.04] ${t ? 'src-row cursor-pointer' : ''} ${highlight && r.id === highlight ? 'bg-sky-400/10 ring-1 ring-inset ring-sky-400/40' : ''}`}
                >
                  {columns.map((c) => (
                    <td key={c.key} className={`px-3 py-2.5 text-slate-200 ${c.align === 'right' ? 'text-right' : ''}`}>
                      {c.render ? c.render(r) : r[c.key]}
                    </td>
                  ))}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      {source && (
        <div className="mt-1.5 flex justify-end">
          <SourceLabel to={source} />
        </div>
      )}
    </div>
  )
}

export function Tabs({ tabs, value, onChange }) {
  return (
    <div className="mb-3 flex flex-wrap gap-1.5">
      {tabs.map((t) => (
        <button
          key={t.key}
          onClick={() => onChange(t.key)}
          className={`rounded-lg px-3 py-1.5 text-xs font-medium transition focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60 ${
            value === t.key ? 'bg-sky-400/15 text-sky-200 ring-1 ring-sky-400/40' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
          }`}
        >
          {t.label}
          {t.count !== undefined && <span className="ml-1.5 text-slate-500">{t.count}</span>}
        </button>
      ))}
    </div>
  )
}
