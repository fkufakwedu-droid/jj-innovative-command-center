import { useMemo, useState } from 'react'
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Cell } from 'recharts'
import { ContactLink, DataTable, Dot, Modal, Pill, Tabs, TONES, TenantLink, UnitLink, WorkOrderLink, chartTooltipStyle } from './ui'
import { assigneeContactId, contractorFor, lenderContactId } from '../data/contacts'
import { money, pct, shortDate } from '../lib/format'

const prioTone = { Emergency: 'red', Urgent: 'yellow', Routine: 'blue' }

export function DrillModal({ modal, m, onClose }) {
  if (!modal) return null
  const { type, arg } = modal
  const props = { m, onClose, arg }
  switch (type) {
    case 'delinquency': return <Delinquency {...props} />
    case 'dscr': return <Dscr {...props} />
    case 'workorders': return <WorkOrders {...props} />
    case 'turns': return <Turns {...props} />
    case 'leases': return <Leases {...props} />
    case 'cash': return <Cash {...props} />
    case 'capex': return <Capex {...props} />
    default: return null
  }
}

function Delinquency({ m, onClose }) {
  const c = m.collections
  const [tab, setTab] = useState('all')
  const rows = useMemo(() => {
    const b = c.buckets.find((x) => x.key === tab)
    return b ? c.rows.filter((r) => r.days >= b.min && r.days <= b.max) : c.rows
  }, [tab, c])
  return (
    <Modal source="collections" title="Delinquent Tenants" subtitle={`${m.scope} · ${money(c.delinquentTotal)} across ${c.delinquentCount} tenants`} onClose={onClose}>
      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[{ key: 'all', label: 'All', count: c.delinquentCount }, ...c.buckets.map((b) => ({ key: b.key, label: b.label, count: b.count }))]}
      />
      <DataTable
        rowUnit={(r) => r.unitId}
        rows={rows}
        columns={[
          { key: 'tenant', label: 'Tenant', render: (r) => <TenantLink id={r.unitId}>{r.tenant}</TenantLink> },
          { key: 'property', label: 'Property' },
          { key: 'unit', label: 'Unit', render: (r) => <UnitLink id={r.unitId}>{r.unit}</UnitLink> },
          { key: 'days', label: 'Days late', align: 'right', render: (r) => <span className={r.days > 60 ? 'font-semibold text-rose-300' : r.days > 30 ? 'text-orange-300' : 'text-amber-300'}>{r.days}</span> },
          { key: 'balance', label: 'Balance', align: 'right', render: (r) => money(r.balance) },
          { key: 'status', label: 'Status', render: (r) => <Pill tone={r.status === 'Eviction filed' ? 'red' : r.status === 'Payment plan' ? 'green' : 'slate'}>{r.status}</Pill> },
        ]}
      />
    </Modal>
  )
}

function Dscr({ m, onClose }) {
  const d = m.dscr
  return (
    <Modal source="dscr" title="Debt Service Coverage" subtitle={`${m.scope} · ${d.basis} · green ≥ 1.25x, yellow 1.15–1.24x, red < 1.15x`} onClose={onClose}>
      <div className="mb-4 h-[180px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={d.loans} margin={{ top: 8, right: 8, bottom: 0, left: -12 }}>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="property" tickLine={false} axisLine={false} />
            <YAxis domain={[0.9, 1.6]} ticks={[0.9, 1.15, 1.25, 1.6]} tickLine={false} axisLine={false} tickFormatter={(v) => `${v.toFixed(2)}x`} width={50} />
            <Tooltip {...chartTooltipStyle} formatter={(v) => [`${v.toFixed(2)}x`, 'DSCR']} />
            <Bar dataKey="dscr" radius={[6, 6, 0, 0]} animationDuration={700}>
              {d.loans.map((l) => (
                <Cell key={l.id} fill={TONES[l.status].hex} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <DataTable
        rowTo={(r) => ({ src: 'dscr', params: { id: r.id } })}
        rows={[...d.loans].sort((a, b) => a.dscr - b.dscr)}
        columns={[
          { key: 'property', label: 'Property', render: (r) => <span className="flex items-center gap-2"><Dot tone={r.status} />{r.property}</span> },
          { key: 'lender', label: 'Lender', render: (r) => <ContactLink id={lenderContactId(r.lender)}>{r.lender}</ContactLink> },
          { key: 'rate', label: 'Rate', align: 'right', render: (r) => pct(r.rate, 2) },
          { key: 'balance', label: 'Balance', align: 'right', render: (r) => money(r.balance, { compact: true }) },
          { key: 'ds', label: 'Debt service / mo', align: 'right', render: (r) => money(r.monthlyDS) },
          { key: 'noi', label: 'NOI (annualized)', align: 'right', render: (r) => money(r.noi, { compact: true }) },
          { key: 'dscr', label: 'DSCR', align: 'right', render: (r) => <span className={`font-semibold ${TONES[r.status].text}`}>{r.dscr.toFixed(2)}x</span> },
        ]}
      />
      {d.alerts.length > 0 && (
        <p className="mt-3 text-xs text-slate-400">
          Recommended: review lender covenants and expense plans for {d.alerts.map((a) => a.property).join(', ')}.
          Lifting NOI by {money(Math.max(...d.alerts.map((a) => a.annualDS * 1.25 - a.noi)), { compact: true })}/yr on the weakest asset clears the 1.25x line.
        </p>
      )}
    </Modal>
  )
}

function WorkOrders({ m, onClose }) {
  const w = m.workOrders
  const [tab, setTab] = useState('aged')
  const rows = tab === 'aged' ? w.aged : tab === 'all' ? w.rows : w.rows.filter((r) => r.priority === tab)
  return (
    <Modal source="workorders" title="Maintenance Work Orders" subtitle={`${m.scope} · ${w.open} open · ${w.aged.length} aged more than 7 days`} onClose={onClose}>
      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { key: 'aged', label: 'Aged > 7 days', count: w.aged.length },
          { key: 'Emergency', label: 'Emergency', count: w.byPriority[0].count },
          { key: 'Urgent', label: 'Urgent', count: w.byPriority[1].count },
          { key: 'Routine', label: 'Routine', count: w.byPriority[2].count },
          { key: 'all', label: 'All open', count: w.open },
        ]}
      />
      <DataTable
        rowUnit={(r) => r.unitId}
        rows={rows}
        columns={[
          { key: 'id', label: 'Ticket', render: (r) => <WorkOrderLink id={r.id}>{r.id}</WorkOrderLink> },
          { key: 'title', label: 'Issue', render: (r) => <div><div>{r.title}</div><div className="text-[11px] text-slate-500">{r.category}</div></div> },
          { key: 'property', label: 'Property · Unit', render: (r) => <UnitLink id={r.unitId}>{`${r.property} · ${r.unit}`}</UnitLink> },
          { key: 'priority', label: 'Priority', render: (r) => <Pill tone={prioTone[r.priority]}>{r.priority}</Pill> },
          { key: 'age', label: 'Age', align: 'right', render: (r) => <span className={r.age > 7 ? 'font-semibold text-rose-300' : ''}>{r.age}d</span> },
          { key: 'assignee', label: 'Assigned', render: (r) => <ContactLink id={assigneeContactId(r.assignee)}>{String(r.assignee).replace(/^Vendor:\s*/, '')}</ContactLink> },
          { key: 'status', label: 'Status' },
          { key: 'photos', label: 'Inspection', render: (r) => r.inspectionRequired ? <Pill tone={r.photos.before.length && r.photos.after.length ? 'green' : 'yellow'}>{r.photos.before.length && r.photos.after.length ? 'Photos ready' : 'Photos needed'}</Pill> : <span className="text-slate-500">—</span> },
        ]}
      />
    </Modal>
  )
}

function Turns({ m, onClose }) {
  const t = m.turns
  const [tab, setTab] = useState('over')
  const rows = tab === 'over' ? t.over15 : t.vacantNow
  return (
    <Modal source="turn" title="Vacant Units & Turn Times" subtitle={`${m.scope} · ${t.vacantNow.length} vacant · ${t.over15.length} over 15 days · target under ${t.target} days`} onClose={onClose}>
      <Tabs value={tab} onChange={setTab} tabs={[{ key: 'over', label: 'Over 15 days', count: t.over15.length }, { key: 'all', label: 'All vacant', count: t.vacantNow.length }]} />
      <DataTable
        rowUnit={(r) => r.unitId}
        rows={rows}
        columns={[
          { key: 'property', label: 'Property' },
          { key: 'unit', label: 'Unit', render: (r) => <UnitLink id={r.unitId}>{r.unit}</UnitLink> },
          { key: 'days', label: 'Days vacant', align: 'right', render: (r) => <span className={`font-semibold ${r.days > 15 ? 'text-rose-300' : r.days > 10 ? 'text-amber-300' : 'text-emerald-300'}`}>{r.days}</span> },
          { key: 'status', label: 'Stage', render: (r) => <Pill tone={r.status === 'Pre-leased' ? 'green' : r.status === 'Awaiting repairs' ? 'red' : 'slate'}>{r.status}</Pill> },
          { key: 'askRent', label: 'Ask rent', align: 'right', render: (r) => money(r.askRent) },
          { key: 'cost', label: 'Rent lost to date', align: 'right', render: (r) => money((r.askRent / 30) * r.days) },
        ]}
      />
    </Modal>
  )
}

function Leases({ m, onClose, arg }) {
  const l = m.leases
  const [tab, setTab] = useState(arg || 'all')
  const b = l.buckets.find((x) => x.key === tab)
  const rows = b ? b.rows.sort((a, c) => a.daysOut - c.daysOut) : l.rows
  const tone = { Renewed: 'green', 'Offer sent': 'blue', 'No response': 'yellow', 'Notice to vacate': 'red' }
  return (
    <Modal source="leases" title="Lease Expirations" subtitle={`${m.scope} · ${l.total} leases in the next 90 days · ${l.atRisk.length} at risk within 30 days`} onClose={onClose}>
      <Tabs value={tab} onChange={setTab} tabs={[{ key: 'all', label: 'All 90 days', count: l.total }, ...l.buckets.map((x) => ({ key: x.key, label: x.label, count: x.count }))]} />
      <DataTable
        rowUnit={(r) => r.unitId}
        rows={rows}
        columns={[
          { key: 'tenant', label: 'Tenant', render: (r) => <TenantLink id={r.unitId}>{r.tenant}</TenantLink> },
          { key: 'property', label: 'Property · Unit', render: (r) => <UnitLink id={r.unitId}>{`${r.property} · ${r.unit}`}</UnitLink> },
          { key: 'expires', label: 'Expires', render: (r) => `${shortDate(r.expires)} (${r.daysOut}d)` },
          { key: 'rent', label: 'Rent', align: 'right', render: (r) => money(r.rent) },
          { key: 'increase', label: 'Offer', align: 'right', render: (r) => `+${r.increase}%` },
          { key: 'status', label: 'Status', render: (r) => <Pill tone={tone[r.status]}>{r.status}</Pill> },
        ]}
      />
    </Modal>
  )
}

function Cash({ m, onClose }) {
  const c = m.cash
  return (
    <Modal source="cash" title="Cash Position by Property" subtitle={`${m.scope} · ${Math.round(c.runwayDays)} days of operating and debt-service cash on hand`} onClose={onClose}>
      <DataTable
        rowTo={(r) => ({ src: 'cash', params: { property: r.id } })}
        rows={c.byProperty}
        columns={[
          { key: 'name', label: 'Property', render: (r) => <span className="flex items-center gap-2"><span className="h-2 w-2 rounded-full" style={{ background: r.color }} />{r.name}</span> },
          { key: 'operating', label: 'Operating', align: 'right', render: (r) => money(r.operating) },
          { key: 'reserve', label: 'Reserve', align: 'right', render: (r) => money(r.reserve) },
          { key: 'escrow', label: 'Escrow', align: 'right', render: (r) => money(r.escrow) },
          { key: 'total', label: 'Total', align: 'right', render: (r) => <span className="font-semibold">{money(r.total)}</span> },
          { key: 'days', label: 'Runway', align: 'right', render: (r) => <span className={r.days < 35 ? 'font-semibold text-rose-300' : r.days < 45 ? 'text-amber-300' : 'text-emerald-300'}>{Math.round(r.days)} days</span> },
        ]}
      />
      <p className="mt-3 text-xs text-slate-400">Runway = total liquid cash ÷ daily operating expenses plus debt service.</p>
    </Modal>
  )
}

function Capex({ m, onClose }) {
  const c = m.capex
  return (
    <Modal source="capex" title="CapEx Projects" subtitle={`${m.scope} · ${money(c.actual, { compact: true })} spent of ${money(c.budget, { compact: true })} budget · forecast ${money(c.forecast, { compact: true })}`} onClose={onClose}>
      <DataTable
        rowTo={(r) => ({ src: 'capex', params: { id: r.id } })}
        rows={c.projects}
        columns={[
          { key: 'name', label: 'Project', render: (r) => <div><div>{r.name}</div><div className="text-[11px] text-slate-500">{r.property} · <ContactLink id={contractorFor(r).id} className="text-[11px]">{contractorFor(r).name}</ContactLink></div></div> },
          { key: 'budget', label: 'Budget', align: 'right', render: (r) => money(r.budget) },
          { key: 'actual', label: 'Actual', align: 'right', render: (r) => money(r.actual) },
          { key: 'forecast', label: 'Forecast', align: 'right', render: (r) => money(r.forecast) },
          { key: 'variance', label: 'Variance', align: 'right', render: (r) => <span className={r.variance > 0 ? 'font-semibold text-rose-300' : 'text-emerald-300'}>{r.variance > 0 ? '+' : ''}{money(r.variance)} ({pct(r.variancePct)})</span> },
          { key: 'complete', label: '% done', align: 'right', render: (r) => `${r.complete}%` },
        ]}
      />
    </Modal>
  )
}
