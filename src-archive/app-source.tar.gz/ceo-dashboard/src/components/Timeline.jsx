import { TONES, TenantLink, UnitLink, WorkOrderLink } from './ui'

const LinkFor = ({ link }) =>
  link.type === 'wo' ? <WorkOrderLink id={link.id}>{link.label}</WorkOrderLink>
  : link.type === 'tenant' ? <TenantLink id={link.id}>{link.label}</TenantLink>
  : <UnitLink id={link.id}>{link.label}</UnitLink>

/** Timeline where an event may carry a link (tenant / work order / unit) between pre and post text. */
export function Timeline({ events, limit = 9 }) {
  return (
    <ol className="relative ml-2 space-y-3 border-l border-white/10 pl-4">
      {events.slice(0, limit).map((e, i) => (
        <li key={i} className="relative">
          <span className={`absolute -left-[21px] top-1.5 h-2.5 w-2.5 rounded-full ring-4 ring-[#0d1424] ${TONES[e.tone].dot}`} />
          <p className="text-sm text-slate-200">
            {e.pre && <span>{e.pre} </span>}
            {e.link && <LinkFor link={e.link} />}
            {(e.post || e.text) && <span>{e.link ? ' ' : ''}{e.post || e.text}</span>}
          </p>
          <p className="text-[11px] text-slate-500">{e.ago === 0 ? 'Today' : `${e.ago} days ago`}</p>
        </li>
      ))}
    </ol>
  )
}
