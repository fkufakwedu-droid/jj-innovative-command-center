import { Building2, Radio } from 'lucide-react'
import { RANGES } from '../data/metrics'
import { CLIENT, DATA } from '../data/portfolio'

export function Header({ selected, onToggle, onClear, range, onRange }) {
  const portfolioWide = selected.length === 0
  return (
    <header className="rise flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {CLIENT.logo ? (
            <img src={CLIENT.logo} alt={`${CLIENT.name || 'Client'} logo`} className="h-10 w-10 rounded-xl bg-white/90 object-contain p-1" />
          ) : (
            <span className="grid h-10 w-10 place-items-center rounded-xl shadow-lg shadow-sky-500/20" style={{ background: CLIENT.accent ? `linear-gradient(135deg, ${CLIENT.accent}, ${CLIENT.accent2 || '#8b5cf6'})` : 'linear-gradient(135deg,#38bdf8,#8b5cf6)' }}>
              <Building2 className="h-5 w-5 text-white" />
            </span>
          )}
          <div>
            <h1 className="text-lg font-semibold leading-tight tracking-tight text-white sm:text-xl">{CLIENT.name ? `${CLIENT.name} · ` : ''}Command Center</h1>
            <p className="text-xs text-slate-400">{DATA.properties.reduce((a, p) => a + p.units, 0)} doors · {DATA.properties.length} {DATA.properties.length === 1 ? 'property' : 'properties'} · {CLIENT.subtitle || 'multifamily'}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-xs text-slate-300">
          <Radio className="h-3.5 w-3.5 text-emerald-400" />
          <span>Live · as of {DATA.asOf.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}</span>
        </div>
      </div>

      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="scroll-thin -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1" role="group" aria-label="Property filter">
          <Chip active={portfolioWide} onClick={onClear}>
            Portfolio-Wide <span className="ml-1 text-[10px] opacity-70">{DATA.properties.reduce((a, p) => a + p.units, 0)}</span>
          </Chip>
          {DATA.properties.map((p) => (
            <Chip key={p.id} active={selected.includes(p.id)} onClick={() => onToggle(p.id)} color={p.color}>
              {p.name} <span className="ml-1 text-[10px] opacity-70">{p.units}</span>
            </Chip>
          ))}
        </div>
        <div className="inline-flex self-start rounded-xl border border-white/10 bg-white/[0.03] p-1" role="group" aria-label="Date range">
          {RANGES.map((r) => (
            <button
              key={r.id}
              onClick={() => onRange(r.id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60 ${
                range === r.id ? 'bg-sky-400/20 text-sky-100 shadow-inner ring-1 ring-sky-400/40' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>
    </header>
  )
}

function Chip({ active, onClick, children, color }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={`flex shrink-0 items-center whitespace-nowrap rounded-full px-3.5 py-1.5 text-xs font-medium transition focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60 ${
        active ? 'bg-white text-slate-900 shadow-lg shadow-white/10' : 'border border-white/10 bg-white/[0.03] text-slate-300 hover:border-white/25 hover:text-white'
      }`}
    >
      {color && <span className="mr-1.5 inline-block h-2 w-2 rounded-full" style={{ background: color }} />}
      {children}
    </button>
  )
}
