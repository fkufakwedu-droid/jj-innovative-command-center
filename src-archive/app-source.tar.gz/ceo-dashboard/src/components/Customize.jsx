import { useCallback, useState } from 'react'
import { ArrowDown, ArrowUp, RotateCcw, SlidersHorizontal } from 'lucide-react'
import { CLIENT } from '../data/portfolio'
import { Modal } from './ui'

export const CARDS = [
  { id: 'cash', label: 'Cash position & runway' },
  { id: 'occupancy', label: 'Physical vs economic occupancy' },
  { id: 'collections', label: 'Collections & delinquency' },
  { id: 'dscr', label: 'Debt service coverage (DSCR)' },
  { id: 'noi', label: 'T12 NOI & operating margin' },
  { id: 'turn', label: 'Average days to turn' },
  { id: 'funnel', label: 'Leasing funnel' },
  { id: 'workorders', label: 'Open work orders & aging' },
  { id: 'capex', label: 'CapEx budget vs actual' },
  { id: 'leases', label: 'Lease expirations' },
]
const KEY = `cc-layout:${CLIENT.name || 'default'}`
const DEFAULT = { order: CARDS.map((c) => c.id), hidden: CLIENT.hiddenCards || [] }

const load = () => {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) || 'null')
    if (v && Array.isArray(v.order)) {
      const known = v.order.filter((id) => CARDS.some((c) => c.id === id))
      CARDS.forEach((c) => { if (!known.includes(c.id)) known.push(c.id) })
      return { order: known, hidden: (v.hidden || []).filter((id) => CARDS.some((c) => c.id === id)) }
    }
  } catch { /* storage unavailable */ }
  return DEFAULT
}

/** Per-viewer card layout: which cards show, and in what order. Remembered in the browser. */
export function useLayout() {
  const [layout, setLayout] = useState(load)
  const save = useCallback((next) => {
    setLayout(next)
    try { localStorage.setItem(KEY, JSON.stringify(next)) } catch { /* storage unavailable */ }
  }, [])
  return [layout, save]
}

export function CustomizeButton({ layout, onChange }) {
  const [open, setOpen] = useState(false)
  const toggle = (id) => onChange({ ...layout, hidden: layout.hidden.includes(id) ? layout.hidden.filter((x) => x !== id) : [...layout.hidden, id] })
  const move = (id, dir) => {
    const o = [...layout.order]
    const i = o.indexOf(id)
    const j = i + dir
    if (j < 0 || j >= o.length) return
    ;[o[i], o[j]] = [o[j], o[i]]
    onChange({ ...layout, order: o })
  }
  const shown = layout.order.length - layout.hidden.length
  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className="inline-flex items-center gap-1.5 self-end rounded-lg border border-white/10 bg-white/[0.03] px-3 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-white/10 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60">
        <SlidersHorizontal className="h-3.5 w-3.5" /> Customize · {shown} of {layout.order.length} cards
      </button>
      {open && (
        <Modal title="Customize this dashboard" subtitle="Choose which cards show and the order they appear in. Saved in this browser." onClose={() => setOpen(false)} wide={false}>
          <ul className="space-y-1.5">
            {layout.order.map((id, i) => {
              const c = CARDS.find((x) => x.id === id)
              const on = !layout.hidden.includes(id)
              return (
                <li key={id} className="flex items-center gap-2 rounded-lg bg-white/[0.04] px-3 py-2 text-sm">
                  <label className="flex min-w-0 flex-1 cursor-pointer items-center gap-2.5">
                    <input type="checkbox" checked={on} onChange={() => toggle(id)} className="h-4 w-4 accent-sky-400" />
                    <span className={on ? 'text-slate-100' : 'text-slate-500'}>{c.label}</span>
                  </label>
                  <button type="button" aria-label={`Move ${c.label} up`} disabled={i === 0} onClick={() => move(id, -1)} className="rounded p-1 text-slate-400 hover:bg-white/10 disabled:opacity-30"><ArrowUp className="h-4 w-4" /></button>
                  <button type="button" aria-label={`Move ${c.label} down`} disabled={i === layout.order.length - 1} onClick={() => move(id, 1)} className="rounded p-1 text-slate-400 hover:bg-white/10 disabled:opacity-30"><ArrowDown className="h-4 w-4" /></button>
                </li>
              )
            })}
          </ul>
          <button type="button" onClick={() => onChange(DEFAULT)} className="mt-3 inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs text-slate-300 hover:bg-white/10">
            <RotateCcw className="h-3.5 w-3.5" /> Reset to default
          </button>
        </Modal>
      )}
    </>
  )
}
