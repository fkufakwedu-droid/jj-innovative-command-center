import { AlertTriangle, ChevronRight, Siren } from 'lucide-react'
import { TONES } from './ui'

export function AlertBanner({ alerts, onOpen }) {
  const urgent = alerts.filter((a) => a.tone !== 'green').length
  const loop = [...alerts, ...alerts]
  return (
    <div className="glass rise flex items-stretch overflow-hidden rounded-2xl" style={{ animationDelay: '60ms' }}>
      <div className="flex shrink-0 items-center gap-2 border-r border-white/10 bg-rose-500/10 px-3 py-3 sm:px-4">
        <span className="relative grid h-7 w-7 place-items-center rounded-lg bg-rose-500/20 ring-1 ring-rose-400/40">
          <Siren className="h-4 w-4 text-rose-300" />
        </span>
        <div className="hidden leading-tight sm:block">
          <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-rose-300">CEO action items</p>
          <p className="text-xs text-slate-300">{urgent} need attention</p>
        </div>
        <span className="text-xs font-semibold text-rose-200 sm:hidden">{urgent}</span>
      </div>
      <div className="marquee-wrap relative min-w-0 flex-1 overflow-hidden">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-8 bg-gradient-to-r from-[#0d1424] to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-8 bg-gradient-to-l from-[#0d1424] to-transparent" />
        <div className="marquee flex items-center gap-3 px-3 py-3">
          {loop.map((a, i) => (
            <button
              key={`${a.id}-${i}`}
              onClick={() => onOpen(a.modal)}
              className={`group flex shrink-0 items-center gap-2 rounded-full px-3.5 py-1.5 text-xs font-medium ring-1 transition hover:brightness-125 focus:outline-none focus-visible:ring-2 ${TONES[a.tone].bg} ${TONES[a.tone].text} ${TONES[a.tone].ring}`}
            >
              <AlertTriangle className="h-3.5 w-3.5" />
              {a.text}
              <ChevronRight className="h-3.5 w-3.5 opacity-60 transition group-hover:translate-x-0.5" />
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
