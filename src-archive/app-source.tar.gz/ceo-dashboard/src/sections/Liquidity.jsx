import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, ReferenceLine } from 'recharts'
import { Banknote, Percent, Receipt } from 'lucide-react'
import { Card, Delta, Num, Pill, ProgressBar, Sparkline, chartTooltipStyle } from '../components/ui'
import { money, pct } from '../lib/format'

/* 1 — Consolidated cash position & runway */
export function CashCard({ m, onOpen, delay }) {
  const c = m.cash
  const tone = c.runwayDays >= 60 ? 'green' : c.runwayDays >= 40 ? 'yellow' : 'red'
  const parts = [
    { k: 'Operating', v: c.operating, color: '#38bdf8' },
    { k: 'Reserve', v: c.reserve, color: '#a78bfa' },
    { k: 'Escrow', v: c.escrow, color: '#34d399' },
  ]
  return (
    <Card title="Cash Position & Runway" icon={Banknote} tone="blue" onOpen={() => onOpen('cash')} delay={delay} className="md:col-span-3 xl:col-span-4">
      <div className="flex items-end justify-between gap-3">
        <div>
          <Num value={c.total} format={(v) => money(v)} className="text-3xl font-semibold tracking-tight text-white sm:text-4xl" />
          <div className="mt-1 flex items-center gap-2 text-xs text-slate-400">
            <Delta value={c.deltaPct} />
            <span>{m.window.label}</span>
          </div>
        </div>
        <div className="text-right">
          <Pill tone={tone}>
            <Num value={c.runwayDays} format={(v) => `${Math.round(v)} days`} />
          </Pill>
          <p className="mt-1 text-[11px] text-slate-500">cash on hand</p>
        </div>
      </div>
      <div className="-mx-1 mt-3">
        <Sparkline data={c.series} color="#38bdf8" height={64} id="cash" />
      </div>
      <div className="mt-3 flex h-2 w-full overflow-hidden rounded-full bg-white/5">
        {parts.map((p) => (
          <div key={p.k} className="h-full transition-all duration-700" style={{ width: `${(p.v / c.total) * 100}%`, background: p.color }} title={`${p.k} ${money(p.v)}`} />
        ))}
      </div>
      <div className="mt-2.5 grid grid-cols-3 gap-2 text-xs">
        {parts.map((p) => (
          <div key={p.k}>
            <div className="flex items-center gap-1.5 text-slate-400">
              <span className="h-2 w-2 rounded-full" style={{ background: p.color }} />
              {p.k}
            </div>
            <div className="mt-0.5 font-medium text-slate-100">{money(p.v, { compact: true })}</div>
          </div>
        ))}
      </div>
    </Card>
  )
}

/* 2 — Physical vs economic occupancy */
export function OccupancyCard({ m, delay }) {
  const o = m.occupancy
  const gap = o.physical - o.economic
  return (
    <Card title="Physical vs Economic Occupancy" icon={Percent} tone="violet" delay={delay} className="md:col-span-3 xl:col-span-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-xl bg-white/[0.04] p-3 ring-1 ring-white/5">
          <p className="text-[11px] uppercase tracking-wider text-slate-400">Physical</p>
          <Num value={o.physical} format={(v) => pct(v)} className="mt-1 block text-2xl font-semibold text-white" />
          <p className="mt-0.5 text-[11px] text-slate-500">{o.occupied} of {o.units} units rented</p>
          <div className="mt-2"><ProgressBar value={o.physical} color="#a78bfa" /></div>
        </div>
        <div className="rounded-xl bg-white/[0.04] p-3 ring-1 ring-white/5">
          <p className="text-[11px] uppercase tracking-wider text-slate-400">Economic</p>
          <Num value={o.economic} format={(v) => pct(v)} className="mt-1 block text-2xl font-semibold text-white" />
          <p className="mt-0.5 text-[11px] text-slate-500">rent collected ÷ potential</p>
          <div className="mt-2"><ProgressBar value={o.economic} color="#38bdf8" /></div>
        </div>
      </div>
      <p className="mt-3 text-xs text-slate-400">
        Gap of <span className="font-semibold text-amber-300">{gap.toFixed(1)} pts</span> between the two:{' '}
        {money(o.vacancyLoss, { compact: true })} vacancy, {money(o.concessions, { compact: true })} concessions, {money(o.uncollected, { compact: true })} uncollected per month.
      </p>
      <div className="mt-2 h-[92px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={o.trend} margin={{ top: 6, right: 6, bottom: 0, left: 0 }}>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="label" tickLine={false} axisLine={false} interval="preserveStartEnd" minTickGap={28} />
            <YAxis domain={[(min) => Math.floor(min - 1), (max) => Math.ceil(max + 1)]} tickCount={3} allowDecimals={false} tickLine={false} axisLine={false} tickFormatter={(v) => `${Math.round(v)}%`} width={38} />
            <Tooltip {...chartTooltipStyle} formatter={(v, n) => [`${v.toFixed(1)}%`, n]} />
            <Line type="monotone" dataKey="physical" name="Physical" stroke="#a78bfa" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="economic" name="Economic" stroke="#38bdf8" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}

/* 3 — Collection rate & delinquency aging */
export function CollectionsCard({ m, onOpen, delay }) {
  const c = m.collections
  const tone = c.rate >= 97 ? 'green' : c.rate >= 94 ? 'yellow' : 'red'
  return (
    <Card title="Collections & Delinquency" icon={Receipt} tone="yellow" onOpen={() => onOpen('delinquency')} openLabel="Tenants" delay={delay} className="md:col-span-6 xl:col-span-4">
      <div className="flex items-end justify-between">
        <div>
          <Num value={c.rate} format={(v) => pct(v)} className="text-3xl font-semibold tracking-tight text-white sm:text-4xl" />
          <p className="mt-1 text-xs text-slate-400">collected of {money(c.netBilled, { compact: true })} billed · {m.window.label}</p>
        </div>
        <Pill tone={tone}>{tone === 'green' ? 'On target' : tone === 'yellow' ? 'Watch' : 'Below target'}</Pill>
      </div>
      <div className="mt-3 flex items-center justify-between text-xs">
        <span className="text-slate-400">Trailing delinquency</span>
        <span className="font-semibold text-rose-300">{money(c.delinquentTotal)} · {c.delinquentCount} tenants</span>
      </div>
      <div className="mt-1 h-[132px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={c.buckets} margin={{ top: 14, right: 4, bottom: 0, left: 0 }}>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="label" tickLine={false} axisLine={false} />
            <YAxis tickLine={false} axisLine={false} tickFormatter={(v) => `$${Math.round(v / 1000)}K`} width={46} tickCount={4} />
            <Tooltip {...chartTooltipStyle} formatter={(v, n, p) => [`${money(v)} · ${p.payload.count} tenants`, 'Balance']} />
            <Bar dataKey="amount" radius={[6, 6, 0, 0]} animationDuration={700}>
              {c.buckets.map((b) => (
                <Cell key={b.key} fill={b.color} />
              ))}
            </Bar>
            <ReferenceLine y={0} stroke="rgba(148,163,184,0.2)" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}
