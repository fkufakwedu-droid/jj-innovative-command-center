import { Area, Bar, CartesianGrid, ComposedChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis, ReferenceLine, ReferenceArea } from 'recharts'
import { Gauge, LineChart as LineIcon, ShieldCheck } from 'lucide-react'
import { Card, ContactLink, Delta, Dot, Num, Pill, TONES, chartTooltipStyle } from '../components/ui'
import { Hit } from '../components/Src'
import { lenderContactId } from '../data/contacts'
import { DSCR_GREEN, DSCR_YELLOW } from '../data/metrics'
import { money, pct } from '../lib/format'

/* 4 — Debt service coverage */
export function DscrCard({ m, onOpen, delay }) {
  const d = m.dscr
  const t = TONES[d.status]
  // gauge position: 0.9x → 1.6x
  const pos = Math.max(0, Math.min(100, ((d.value - 0.9) / 0.7) * 100))
  const label = { green: 'Healthy', yellow: 'Watch', red: 'Below covenant' }[d.status]
  return (
    <Card title="Debt Service Coverage (DSCR)" icon={ShieldCheck} tone={d.status} source="dscr" onOpen={() => onOpen('dscr')} delay={delay} className="md:col-span-3 xl:col-span-5">
      <Hit to={{ src: 'dscr' }} className="-m-1 flex items-end justify-between gap-3 rounded-lg p-1">
        <div>
          <Num value={d.value} format={(v) => `${v.toFixed(2)}x`} className={`text-3xl font-semibold tracking-tight sm:text-4xl ${t.text}`} />
          <p className="mt-1 text-xs text-slate-400">{d.basis} ÷ {money(d.monthlyDS, { compact: true })}/mo debt service</p>
        </div>
        <Pill tone={d.status}><Dot tone={d.status} pulse={d.status === 'red'} /> {label}</Pill>
      </Hit>
      <Hit to={{ src: 'dscr' }} className="mt-4 rounded-lg p-1">
        <div className="relative h-2.5 w-full overflow-hidden rounded-full">
          <div className="absolute inset-0 flex">
            <div className="bg-rose-500/70" style={{ width: `${((DSCR_YELLOW - 0.9) / 0.7) * 100}%` }} />
            <div className="bg-amber-400/70" style={{ width: `${((DSCR_GREEN - DSCR_YELLOW) / 0.7) * 100}%` }} />
            <div className="flex-1 bg-emerald-400/70" />
          </div>
        </div>
        <div className="relative h-4">
          <div className="absolute top-0 -translate-x-1/2 transition-all duration-700" style={{ left: `${pos}%` }}>
            <div className="mx-auto h-2 w-0.5 bg-white" />
            <div className="h-2 w-2 -translate-y-px rotate-45 bg-white" style={{ marginLeft: -3 }} />
          </div>
        </div>
        <div className="flex justify-between text-[10px] text-slate-500">
          <span>0.90x</span>
          <span>1.15x</span>
          <span>1.25x</span>
          <span>1.60x</span>
        </div>
      </Hit>
      <ul className="mt-3 space-y-1.5">
        {d.loans.map((l) => (
          <Hit as="li" key={l.id} to={{ src: 'dscr', params: { id: l.id } }} focusable={false} className="flex items-center justify-between gap-2 rounded-lg bg-white/[0.03] px-2.5 py-1.5 text-xs">
            <span className="flex min-w-0 items-center gap-2">
              <Dot tone={l.status} />
              <span className="truncate text-slate-200">{l.property}</span>
              <span className="min-w-0 max-w-[55%] truncate text-[11px] text-slate-500">· <ContactLink id={lenderContactId(l.lender)} className="text-[11px]">{l.lender}</ContactLink></span>
            </span>
            <span className={`font-semibold ${TONES[l.status].text}`}>{l.dscr.toFixed(2)}x</span>
          </Hit>
        ))}
      </ul>
    </Card>
  )
}

/* 6 — T12 NOI & operating margin */
export function NoiCard({ m, delay }) {
  const n = m.noi
  const good = n.opexRatio <= 46
  return (
    <Card
      title="T12 NOI & Operating Margin"
      icon={LineIcon}
      tone="green"
      source="noi"
      delay={delay}
      className="md:col-span-3 xl:col-span-7"
      right={<Pill tone={good ? 'green' : 'yellow'}>OpEx ratio {pct(n.opexRatio)}</Pill>}
    >
      <div className="grid grid-cols-3 gap-3">
        <Metric label="T12 NOI" value={<Num value={n.t12Noi} format={(v) => money(v, { compact: true })} />} sub={<Delta value={n.yoyHalf} suffix="% H/H" />} />
        <Metric label={`NOI · ${m.window.label}`} value={<Num value={n.windowNoi} format={(v) => money(v, { compact: true })} />} sub={<span className="text-slate-500">{money(n.windowRev, { compact: true })} revenue</span>} />
        <Metric label="Operating margin" value={<Num value={n.margin} format={(v) => pct(v)} />} sub={<Delta value={n.momChange} suffix="% MoM" />} />
      </div>
      <div className="mt-3 h-[190px]">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={n.months} margin={{ top: 8, right: 0, bottom: 0, left: 0 }}>
            <defs>
              <linearGradient id="noiFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#34d399" stopOpacity={0.5} />
                <stop offset="100%" stopColor="#34d399" stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="label" tickLine={false} axisLine={false} />
            <YAxis yAxisId="l" tickLine={false} axisLine={false} tickFormatter={(v) => `$${Math.round(v / 1000)}K`} width={48} />
            <YAxis yAxisId="r" orientation="right" domain={[36, 56]} tickLine={false} axisLine={false} tickFormatter={(v) => `${v}%`} width={38} />
            <Tooltip {...chartTooltipStyle} formatter={(v, name) => (name === 'OpEx ratio' ? [`${v.toFixed(1)}%`, name] : [money(v), name])} />
            <Bar yAxisId="l" dataKey="opex" name="OpEx" fill="rgba(148,163,184,0.28)" radius={[4, 4, 0, 0]} barSize={14} animationDuration={700} />
            <Area yAxisId="l" type="monotone" dataKey="noi" name="NOI" stroke="#34d399" strokeWidth={2.5} fill="url(#noiFill)" animationDuration={800} />
            <Line yAxisId="r" type="monotone" dataKey="ratio" name="OpEx ratio" stroke="#fbbf24" strokeWidth={2} strokeDasharray="4 3" dot={{ r: 2.5, fill: '#fbbf24' }} animationDuration={800} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-slate-400">
        <Legend color="#34d399" label="NOI" />
        <Legend color="rgba(148,163,184,0.6)" label="Operating expenses" />
        <Legend color="#fbbf24" label="OpEx ratio (OpEx ÷ gross revenue)" dashed />
      </div>
    </Card>
  )
}

function Metric({ label, value, sub }) {
  return (
    <Hit to={{ src: 'noi' }} className="rounded-xl bg-white/[0.04] p-3 ring-1 ring-white/5">
      <p className="truncate text-[11px] uppercase tracking-wider text-slate-400">{label}</p>
      <p className="mt-1 text-xl font-semibold text-white sm:text-2xl">{value}</p>
      <div className="mt-0.5 text-[11px]">{sub}</div>
    </Hit>
  )
}

function Legend({ color, label, dashed }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="inline-block h-0.5 w-4" style={{ background: dashed ? 'transparent' : color, borderTop: dashed ? `2px dashed ${color}` : 'none' }} />
      {label}
    </span>
  )
}
