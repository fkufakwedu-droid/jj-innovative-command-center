import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Clock, Filter, Wrench } from 'lucide-react'
import { Card, Num, Pill, ProgressBar, TONES, chartTooltipStyle } from '../components/ui'
import { Hit, useOpen } from '../components/Src'
import { pct } from '../lib/format'

/* 5 — Average days to turn */
export function TurnCard({ m, onOpen, delay }) {
  const t = m.turns
  const over = t.avg - t.target
  const tone = t.avg <= t.target ? 'green' : t.avg <= t.target * 1.25 ? 'yellow' : 'red'
  return (
    <Card title="Average Days to Turn" icon={Clock} tone={tone} source="turn" onOpen={() => onOpen('turns')} openLabel="Vacant units" delay={delay} className="md:col-span-3 xl:col-span-4">
      <Hit to={{ src: 'turn' }} className="-m-1 flex items-end justify-between rounded-lg p-1">
        <div>
          <Num value={t.avg} format={(v) => v.toFixed(1)} className={`text-3xl font-semibold tracking-tight sm:text-4xl ${TONES[tone].text}`} />
          <span className="ml-1 text-sm text-slate-400">days</span>
          <p className="mt-1 text-xs text-slate-400">target &lt; {t.target} days · {t.completed} turns completed</p>
        </div>
        <Pill tone={tone}>{over <= 0 ? 'On target' : `+${over.toFixed(1)}d over`}</Pill>
      </Hit>
      <div className="mt-3 h-[96px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={t.trend} margin={{ top: 6, right: 4, bottom: 0, left: 0 }}>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="label" tickLine={false} axisLine={false} interval={1} />
            <YAxis domain={[6, (max) => Math.ceil(max + 2)]} tickCount={4} allowDecimals={false} tickLine={false} axisLine={false} width={30} />
            <Tooltip {...chartTooltipStyle} formatter={(v) => [`${v.toFixed(1)} days`, 'Avg turn']} />
            <ReferenceLine y={t.target} stroke="#34d399" strokeDasharray="4 4" />
            <Line type="monotone" dataKey="avg" stroke={TONES[tone].hex} strokeWidth={2.5} dot={false} animationDuration={800} />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-2 space-y-1.5">
        {t.byProperty.map((p) => (
          <Hit key={p.name} to={{ src: 'turn', params: { property: p.id } }} className="flex items-center gap-2 rounded-md px-1 py-0.5 text-xs">
            <span className="w-28 shrink-0 truncate text-slate-400 sm:w-32">{p.name}</span>
            <div className="flex-1"><ProgressBar value={p.avg} max={22} marker={t.target} color={p.avg <= t.target ? '#34d399' : p.avg <= t.target * 1.3 ? '#fbbf24' : '#fb7185'} height={6} /></div>
            <span className="w-9 text-right font-medium text-slate-200">{p.avg.toFixed(1)}</span>
          </Hit>
        ))}
      </div>
    </Card>
  )
}

/* 7 — Leasing funnel */
export function FunnelCard({ m, delay }) {
  const stages = m.funnel.stages
  const top = stages[0].value || 1
  const colors = ['#38bdf8', '#60a5fa', '#818cf8', '#a78bfa', '#c084fc']
  return (
    <Card title={`Leasing Funnel · ${m.funnel.scaleLabel}`} icon={Filter} tone="violet" source="funnel" delay={delay} className="md:col-span-3 xl:col-span-4">
      <div className="space-y-2.5">
        {stages.map((s, i) => (
          <Hit key={s.key} to={{ src: 'funnel', params: { stage: s.key } }} className="group rounded-md px-1 py-0.5">
            <div className="mb-1 flex items-baseline justify-between text-xs">
              <span className="text-slate-300">{s.label}</span>
              <span className="text-slate-400">
                <span className="mr-2 text-sm font-semibold text-white">{s.value.toLocaleString()}</span>
                {i > 0 && <span className="text-slate-500">{pct(s.rate, 0)} of prior</span>}
              </span>
            </div>
            <div className="mx-auto transition-all duration-700 ease-out" style={{ width: `${Math.max(10, (s.value / top) * 100)}%` }}>
              <div className="h-7 rounded-lg shadow-lg transition group-hover:brightness-125" style={{ background: `linear-gradient(90deg, ${colors[i]}cc, ${colors[i]}66)`, boxShadow: `0 6px 18px -8px ${colors[i]}` }} />
            </div>
          </Hit>
        ))}
      </div>
      <Hit to={{ src: 'funnel' }} className="mt-3 flex items-center justify-between rounded-xl bg-white/[0.04] px-3 py-2 text-xs ring-1 ring-white/5">
        <span className="text-slate-400">Inquiry → lease conversion</span>
        <span className="font-semibold text-violet-200">{pct(stages[4].overall)}</span>
      </Hit>
    </Card>
  )
}

/* 8 — Open work orders & aging */
export function WorkOrderCard({ m, onOpen, delay }) {
  const w = m.workOrders
  const openTarget = useOpen()
  const tones = { Emergency: 'red', Urgent: 'yellow', Routine: 'blue' }
  const fmtRes = (h) => (h < 24 ? `${h.toFixed(1)} h` : `${(h / 24).toFixed(1)} d`)
  return (
    <Card title="Open Work Orders & Aging" icon={Wrench} tone="yellow" source="workorders" onOpen={() => onOpen('workorders')} delay={delay} className="md:col-span-6 xl:col-span-4">
      <div className="flex items-end justify-between">
        <Hit to={{ src: 'workorders' }} className="-m-1 rounded-lg p-1">
          <Num value={w.open} format={(v) => Math.round(v)} className="text-3xl font-semibold tracking-tight text-white sm:text-4xl" />
          <span className="ml-1 text-sm text-slate-400">open</span>
          <p className="mt-1 text-xs text-slate-400">avg resolution {fmtRes(w.avgResolutionHrs)}</p>
        </Hit>
        <button onClick={() => onOpen('workorders')} className="rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-400/60">
          <Pill tone={w.aged.length > 8 ? 'red' : 'yellow'}>{w.aged.length} aged &gt; 7 days</Pill>
        </button>
      </div>
      <div className="src-chart mt-3 h-[84px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={w.byPriority} layout="vertical" margin={{ top: 0, right: 12, bottom: 0, left: 8 }} barCategoryGap={6}>
            <XAxis type="number" hide />
            <YAxis type="category" dataKey="key" tickLine={false} axisLine={false} width={64} />
            <Tooltip {...chartTooltipStyle} />
            <Bar dataKey="count" name="Open" radius={4} animationDuration={700} stackId="a" onClick={(d, i, e) => openTarget({ src: 'workorders', params: { priority: d?.payload?.key ?? w.byPriority[i]?.key } }, e)}>
              {w.byPriority.map((p) => (
                <Cell key={p.key} fill={TONES[tones[p.key]].hex} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-2 overflow-hidden rounded-xl border border-white/10 text-xs">
        <div className="grid grid-cols-4 bg-white/[0.04] px-3 py-1.5 text-[10px] uppercase tracking-wider text-slate-400">
          <span>Priority</span>
          <span className="text-right">Open</span>
          <span className="text-right">Aged &gt;7d</span>
          <span className="text-right">Avg fix</span>
        </div>
        {w.byPriority.map((p) => (
          <Hit key={p.key} to={{ src: 'workorders', params: { priority: p.key } }} className="grid grid-cols-4 items-center rounded-none border-t border-white/5 px-3 py-1.5">
            <span className={`font-medium ${TONES[tones[p.key]].text}`}>{p.key}</span>
            <span className="text-right text-slate-200">{p.count}</span>
            <span className={`text-right ${p.aged ? 'font-semibold text-rose-300' : 'text-slate-500'}`}>{p.aged}</span>
            <span className="text-right text-slate-300">{fmtRes(p.resolutionHrs)}</span>
          </Hit>
        ))}
      </div>
    </Card>
  )
}
