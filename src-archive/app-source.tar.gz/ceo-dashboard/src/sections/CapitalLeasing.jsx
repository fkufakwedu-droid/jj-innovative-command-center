import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { CalendarClock, HardHat } from 'lucide-react'
import { Card, ContactLink, Num, Pill, ProgressBar, TONES, TenantLink, UnitLink, chartTooltipStyle } from '../components/ui'
import { Hit, useOpen } from '../components/Src'
import { contractorFor } from '../data/contacts'
import { money, pct } from '../lib/format'

/* 9 — CapEx budget vs actual */
export function CapexCard({ m, onOpen, delay }) {
  const c = m.capex
  const tone = c.variance > c.budget * 0.03 ? 'red' : c.variance > 0 ? 'yellow' : 'green'
  return (
    <Card title="CapEx · Budget vs Actual" icon={HardHat} tone="blue" source="capex" onOpen={() => onOpen('capex')} delay={delay} className="md:col-span-3 xl:col-span-7">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Kpi label="Budget" value={<Num value={c.budget} format={(v) => money(v, { compact: true })} />} />
        <Kpi label="Spent to date" value={<Num value={c.actual} format={(v) => money(v, { compact: true })} />} sub={`${pct((c.actual / c.budget) * 100, 0)} of budget`} />
        <Kpi label="Forecast at completion" value={<Num value={c.forecast} format={(v) => money(v, { compact: true })} />} />
        <Kpi
          label="Projected variance"
          tone={tone}
          value={<Num value={c.variance} format={(v) => `${v > 0 ? '+' : ''}${money(v, { compact: true })}`} />}
          sub={c.variance > 0 ? 'over budget' : 'under budget'}
        />
      </div>
      <div className="mt-4 space-y-3">
        {c.projects.map((p) => {
          const vTone = p.variance > p.budget * 0.03 ? 'red' : p.variance > 0 ? 'yellow' : 'green'
          return (
            <Hit key={p.id} to={{ src: 'capex', params: { id: p.id } }} focusable={false} className="rounded-xl bg-white/[0.03] p-3 ring-1 ring-white/5 transition hover:bg-white/[0.06]">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-slate-100">{p.name}</p>
                  <p className="text-[11px] text-slate-500">{p.property} · {p.complete}% complete · <ContactLink id={contractorFor(p).id} className="text-[11px]">{contractorFor(p).name}</ContactLink></p>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-400">
                    {money(p.actual, { compact: true })} / {money(p.budget, { compact: true })}
                  </span>
                  <Pill tone={vTone}>
                    {p.variance > 0 ? '+' : ''}
                    {money(p.variance, { compact: true })}
                  </Pill>
                </div>
              </div>
              <div className="relative mt-2">
                <ProgressBar value={p.actual} max={Math.max(p.budget, p.forecast) * 1.05} marker={p.budget} color={p.actual > p.budget ? '#fb7185' : p.color} height={8} />
                <div className="mt-1 flex justify-between text-[10px] text-slate-500">
                  <span>Spent {pct(p.spentPct, 0)} of budget</span>
                  <span>white tick = budget</span>
                </div>
              </div>
            </Hit>
          )
        })}
      </div>
    </Card>
  )
}

function Kpi({ label, value, sub, tone }) {
  return (
    <Hit to={{ src: 'capex' }} className="rounded-xl bg-white/[0.04] p-3 ring-1 ring-white/5">
      <p className="truncate text-[11px] uppercase tracking-wider text-slate-400">{label}</p>
      <p className={`mt-1 text-xl font-semibold sm:text-2xl ${tone ? TONES[tone].text : 'text-white'}`}>{value}</p>
      {sub && <p className="text-[11px] text-slate-500">{sub}</p>}
    </Hit>
  )
}

/* 10 — Lease expirations, rolling 90 days */
export function LeaseCard({ m, onOpen, delay }) {
  const l = m.leases
  const openTarget = useOpen()
  const colors = { Renewed: '#34d399', 'Offer sent': '#38bdf8', 'No response': '#fbbf24', 'Notice to vacate': '#fb7185' }
  return (
    <Card title="Lease Expirations · Next 90 Days" icon={CalendarClock} tone="violet" source="leases" onOpen={() => onOpen('leases')} delay={delay} className="md:col-span-3 xl:col-span-5">
      <div className="flex items-end justify-between">
        <Hit to={{ src: 'leases' }} className="-m-1 rounded-lg p-1">
          <Num value={l.total} format={(v) => Math.round(v)} className="text-3xl font-semibold tracking-tight text-white sm:text-4xl" />
          <span className="ml-1 text-sm text-slate-400">leases expiring</span>
          <p className="mt-1 text-xs text-slate-400">{pct(l.renewalRate, 0)} already renewed</p>
        </Hit>
        <Hit to={{ src: 'leases', params: { bucket: '30' } }} className="-m-1 rounded-lg p-1">
          <Pill tone={l.atRisk.length > 5 ? 'red' : 'yellow'}>{l.atRisk.length} at risk &lt; 30d</Pill>
        </Hit>
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2">
        {l.buckets.map((b) => (
          <button
            key={b.key}
            onClick={() => onOpen('leases', b.key)}
            className="rounded-xl bg-white/[0.04] p-2.5 text-left ring-1 ring-white/5 transition hover:bg-white/[0.08] focus:outline-none focus-visible:ring-2 focus-visible:ring-violet-400/60"
          >
            <p className="text-[10px] uppercase tracking-wider text-slate-400">{b.label}</p>
            <p className="mt-0.5 text-xl font-semibold text-white">{b.count}</p>
          </button>
        ))}
      </div>
      <div className="src-chart mt-3 h-[170px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={l.buckets} margin={{ top: 6, right: 4, bottom: 0, left: 0 }}>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="label" tickLine={false} axisLine={false} />
            <YAxis tickLine={false} axisLine={false} allowDecimals={false} width={30} />
            <Tooltip {...chartTooltipStyle} />
            {Object.keys(colors).map((k, i, a) => (
              <Bar key={k} dataKey={k} stackId="s" fill={colors[k]} radius={i === a.length - 1 ? [5, 5, 0, 0] : 0} animationDuration={700} onClick={(d, idx, e) => openTarget({ src: 'leases', params: { bucket: d?.payload?.key ?? l.buckets[idx]?.key } }, e)} />
            ))}
            <Legend iconType="circle" iconSize={7} wrapperStyle={{ fontSize: 11, color: '#94a3b8', paddingTop: 6 }} />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-3">
        <div className="mb-1.5 flex items-center justify-between">
          <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Needs action · next 30 days</p>
          <button onClick={() => onOpen('leases', '30')} className="text-[11px] text-sky-300 hover:underline">See all</button>
        </div>
        <ul className="space-y-1.5">
          {l.atRisk.slice(0, 5).map((r) => (
            <Hit as="li" key={r.id} to={{ route: { type: 'unit', id: r.unitId }, label: 'Unit dashboard' }} focusable={false} className="flex items-center justify-between gap-2 rounded-lg bg-white/[0.03] px-2.5 py-1.5 text-xs">
              <span className="flex min-w-0 items-center gap-1.5 truncate text-slate-200"><TenantLink id={r.unitId}>{r.tenant}</TenantLink> <UnitLink id={r.unitId}>{r.property} · {r.unit}</UnitLink></span>
              <span className="flex shrink-0 items-center gap-2">
                <span className="text-slate-400">{r.daysOut}d</span>
                <Pill tone={r.status === 'Notice to vacate' ? 'red' : 'yellow'}>{r.status}</Pill>
              </span>
            </Hit>
          ))}
          {!l.atRisk.length && <li className="py-2 text-center text-xs text-slate-500">No at-risk expirations in the next 30 days</li>}
        </ul>
      </div>
    </Card>
  )
}
