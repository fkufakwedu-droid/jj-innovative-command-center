import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { CLIENT, DATA } from './data/portfolio'
import { computeMetrics } from './data/metrics'
import { Header } from './components/Header'
import { AlertBanner } from './components/AlertBanner'
import { DrillModal } from './components/DrillModal'
import { Nav } from './components/ui'
import { useVersion } from './data/store'
import { UnitDashboard } from './views/UnitDashboard'
import { TenantDashboard } from './views/TenantDashboard'
import { WorkOrderDetail } from './views/WorkOrderDetail'
import { CashCard, CollectionsCard, OccupancyCard } from './sections/Liquidity'
import { DscrCard, NoiCard } from './sections/Performance'
import { FunnelCard, TurnCard, WorkOrderCard } from './sections/Operations'
import { CapexCard, LeaseCard } from './sections/CapitalLeasing'

const routeFromHash = () => {
  try {
    const h = decodeURIComponent(window.location.hash.replace('#', ''))
    if (h.startsWith('unit-')) return { type: 'unit', id: h.slice(5) }
    if (h.startsWith('tenant-')) return { type: 'tenant', id: h.slice(7) }
    if (h.startsWith('wo-')) return { type: 'wo', id: h.slice(3) }
  } catch { /* hash not available */ }
  return null
}
const hashFor = (r) => (r ? `${r.type}-${r.id}` : '')

export default function App() {
  useEffect(() => { if (CLIENT.name) document.title = `${CLIENT.name} · Command Center` }, [])
  const [selected, setSelected] = useState([])
  const [range, setRange] = useState('mtd')
  const [modal, setModal] = useState(null)
  const [route, setRoute] = useState(routeFromHash)
  const stack = useRef([])
  const scrollBack = useRef(0)
  const version = useVersion()

  // Deep links: #unit-<id>, #tenant-<unitId>, #wo-<WO-id>
  useEffect(() => {
    const onHash = () => setRoute(routeFromHash())
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])

  const go = useCallback((r) => {
    setModal(null)
    setRoute((cur) => {
      if (!cur) scrollBack.current = window.scrollY
      else stack.current.push(cur)
      return r
    })
    try { window.location.hash = hashFor(r) } catch { /* hash not available */ }
    window.scrollTo(0, 0)
  }, [])
  const openUnit = useCallback((id) => go({ type: 'unit', id }), [go])
  const openTenant = useCallback((id) => go({ type: 'tenant', id }), [go])
  const openWorkOrder = useCallback((id) => go({ type: 'wo', id }), [go])
  const nav = useMemo(() => ({ openUnit, openTenant, openWorkOrder }), [openUnit, openTenant, openWorkOrder])

  const back = useCallback(() => {
    const prev = stack.current.pop() || null
    setRoute(prev)
    try { window.location.hash = hashFor(prev) } catch { /* hash not available */ }
    if (prev) window.scrollTo(0, 0)
    else requestAnimationFrame(() => window.scrollTo(0, scrollBack.current))
  }, [])

  const openProperty = useCallback((id) => {
    setSelected([id])
    stack.current = []
    setRoute(null)
    try { window.location.hash = '' } catch { /* hash not available */ }
  }, [])

  const m = useMemo(() => computeMetrics(DATA, selected, range), [selected, range, version])

  const toggle = useCallback((id) => setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id])), [])
  const open = useCallback((type, arg) => setModal({ type, arg }), [])
  const close = useCallback(() => setModal(null), [])

  return (
    <Nav.Provider value={nav}>
    <div className="app-bg min-h-screen">
      <main className="mx-auto flex max-w-[1500px] flex-col gap-4 px-3 py-4 sm:gap-5 sm:px-6 sm:py-6">
        {route?.type === 'unit' ? (
          <UnitDashboard unitId={route.id} version={version} onBack={back} onProperty={openProperty} />
        ) : route?.type === 'tenant' ? (
          <TenantDashboard tenantId={route.id} version={version} onBack={back} />
        ) : route?.type === 'wo' ? (
          <WorkOrderDetail woId={route.id} version={version} onBack={back} />
        ) : (
        <>
        <Header selected={selected} onToggle={toggle} onClear={() => setSelected([])} range={range} onRange={setRange} />
        <AlertBanner alerts={m.alerts} onOpen={open} />

        <div className="grid grid-cols-1 gap-4 md:grid-cols-6 xl:grid-cols-12">
          <CashCard m={m} onOpen={open} delay={80} />
          <OccupancyCard m={m} delay={120} />
          <CollectionsCard m={m} onOpen={open} delay={160} />

          <DscrCard m={m} onOpen={open} delay={200} />
          <NoiCard m={m} delay={240} />

          <TurnCard m={m} onOpen={open} delay={280} />
          <FunnelCard m={m} delay={320} />
          <WorkOrderCard m={m} onOpen={open} delay={360} />

          <CapexCard m={m} onOpen={open} delay={400} />
          <LeaseCard m={m} onOpen={open} delay={440} />
        </div>

        <footer className="pb-4 pt-2 text-center text-[11px] text-slate-500">
          {CLIENT.name ? `${CLIENT.name} · ` : ''}Illustrative mock data · {m.scope} · {m.units} doors in view · swap <code className="rounded bg-white/5 px-1">src/data/portfolio.js</code> for your PMS / accounting feed
        </footer>
        </>
        )}
      </main>
      <DrillModal modal={modal} m={m} onClose={close} />
    </div>
    </Nav.Provider>
  )
}
