import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { CLIENT, DATA } from './data/portfolio'
import { computeMetrics } from './data/metrics'
import { Header } from './components/Header'
import { AlertBanner } from './components/AlertBanner'
import { DrillModal } from './components/DrillModal'
import { Nav } from './components/ui'
import { CustomizeButton, useLayout } from './components/Customize'
import { useVersion } from './data/store'
import { formatHash, parseHash, sameRoute, urlFor } from './lib/route'
import { UnitDashboard } from './views/UnitDashboard'
import { TenantDashboard } from './views/TenantDashboard'
import { WorkOrderDetail } from './views/WorkOrderDetail'
import { ContactPage } from './views/ContactPage'
import { SourcePage } from './views/SourcePages'
import { CashCard, CollectionsCard, OccupancyCard } from './sections/Liquidity'
import { DscrCard, NoiCard } from './sections/Performance'
import { FunnelCard, TurnCard, WorkOrderCard } from './sections/Operations'
import { CapexCard, LeaseCard } from './sections/CapitalLeasing'

const routeFromHash = () => parseHash(window.location.hash)
const histDepth = () => {
  try { return window.history.state?.ccDepth || 0 } catch { return 0 }
}

export default function App() {
  useEffect(() => { if (CLIENT.name) document.title = `${CLIENT.name} · Command Center` }, [])
  const [selected, setSelected] = useState([])
  const [range, setRange] = useState('mtd')
  const [modal, setModal] = useState(null)
  const [route, setRoute] = useState(routeFromHash)
  const routeRef = useRef(route)
  const depth = useRef(histDepth())
  const scrollAt = useRef(new Map()) // scroll position per screen, so Back lands where you were
  const version = useVersion()
  const [layout, setLayout] = useLayout()

  const restoreScroll = useCallback((r) => {
    const y = scrollAt.current.get(formatHash(r)) || 0
    const apply = () => window.scrollTo(0, y)
    requestAnimationFrame(() => { apply(); requestAnimationFrame(apply) })
    setTimeout(apply, 120)
  }, [])

  // Deep links and the browser's own Back / Forward: #unit-<id>, #tenant-<unitId>, #wo-<WO-id>, #contact-<id>, #page-<name>
  useEffect(() => {
    try { window.history.scrollRestoration = 'manual' } catch { /* not available */ }
    const sync = () => {
      const next = routeFromHash()
      if (sameRoute(routeRef.current, next)) return
      scrollAt.current.set(formatHash(routeRef.current), window.scrollY)
      depth.current = histDepth()
      routeRef.current = next
      setRoute(next)
      setModal(null)
      restoreScroll(next)
    }
    window.addEventListener('popstate', sync)
    window.addEventListener('hashchange', sync)
    return () => {
      window.removeEventListener('popstate', sync)
      window.removeEventListener('hashchange', sync)
    }
  }, [restoreScroll])

  const go = useCallback((r) => {
    const cur = routeRef.current
    setModal(null)
    if (sameRoute(cur, r)) return
    scrollAt.current.set(formatHash(cur), window.scrollY)
    depth.current += 1
    try { window.history.pushState({ ccDepth: depth.current }, '', urlFor(r)) } catch { window.location.hash = formatHash(r) }
    routeRef.current = r
    setRoute(r)
    window.scrollTo(0, 0)
  }, [])

  const back = useCallback(() => {
    if (depth.current > 0) {
      window.history.back() // popstate restores the previous screen and its scroll position
      return
    }
    // Opened straight from a link: Back goes to the dashboard home
    routeRef.current = null
    try { window.history.replaceState({ ccDepth: 0 }, '', urlFor(null)) } catch { window.location.hash = '' }
    setRoute(null)
    setModal(null)
    restoreScroll(null)
  }, [restoreScroll])

  const nav = useMemo(() => {
    const pageRoute = (page, params = {}) => {
      const p = { ...params }
      if (selected.length && !p.property) p.property = selected.join(',')
      return { type: 'page', id: page, params: p }
    }
    return {
      go,
      pageRoute,
      openUnit: (id) => go({ type: 'unit', id }),
      openTenant: (id) => go({ type: 'tenant', id }),
      openWorkOrder: (id) => go({ type: 'wo', id }),
      openContact: (id) => go({ type: 'contact', id }),
      openPage: (page, params) => go(pageRoute(page, params)),
    }
  }, [go, selected])

  const openProperty = useCallback((id) => {
    setSelected([id])
    go(null)
  }, [go])

  const m = useMemo(() => computeMetrics(DATA, selected, range), [selected, range, version])

  const toggle = useCallback((id) => setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id])), [])
  const open = useCallback((type, arg) => setModal({ type, arg }), [])
  const close = useCallback(() => setModal(null), [])

  return (
    <Nav.Provider value={nav}>
    <div className="app-bg min-h-screen">
      <main className="mx-auto flex max-w-[1500px] flex-col gap-4 px-3 py-4 sm:gap-5 sm:px-6 sm:py-6">
        {route?.type === 'unit' ? (
          <UnitDashboard unitId={route.id} version={version} onBack={back} onProperty={openProperty} />
        ) : route?.type === 'tenant' ? (
          <TenantDashboard tenantId={route.id} version={version} onBack={back} />
        ) : route?.type === 'wo' ? (
          <WorkOrderDetail woId={route.id} version={version} onBack={back} />
        ) : route?.type === 'contact' ? (
          <ContactPage contactId={route.id} version={version} onBack={back} />
        ) : route?.type === 'page' ? (
          <SourcePage key={formatHash(route)} page={route.id} params={route.params} range={range} version={version} onBack={back} />
        ) : (
        <>
        <Header selected={selected} onToggle={toggle} onClear={() => setSelected([])} range={range} onRange={setRange} />
        <AlertBanner alerts={m.alerts} onOpen={open} />

        <div className="flex justify-end"><CustomizeButton layout={layout} onChange={setLayout} /></div>
        <div className="grid grid-flow-dense grid-cols-1 gap-4 md:grid-cols-6 xl:grid-cols-12">
          {layout.order.filter((id) => !layout.hidden.includes(id)).map((id, i) => {
            const delay = 80 + i * 40
            const C = {
              cash: <CashCard m={m} onOpen={open} delay={delay} />,
              occupancy: <OccupancyCard m={m} delay={delay} />,
              collections: <CollectionsCard m={m} onOpen={open} delay={delay} />,
              dscr: <DscrCard m={m} onOpen={open} delay={delay} />,
              noi: <NoiCard m={m} delay={delay} />,
              turn: <TurnCard m={m} onOpen={open} delay={delay} />,
              funnel: <FunnelCard m={m} delay={delay} />,
              workorders: <WorkOrderCard m={m} onOpen={open} delay={delay} />,
              capex: <CapexCard m={m} onOpen={open} delay={delay} />,
              leases: <LeaseCard m={m} onOpen={open} delay={delay} />,
            }[id]
            return <Fragment key={id}>{C}</Fragment>
          })}
          {layout.hidden.length === layout.order.length && <p className="col-span-full py-12 text-center text-sm text-slate-400">All cards are hidden. Use Customize to bring some back.</p>}
        </div>

        <footer className="pb-4 pt-2 text-center text-[11px] text-slate-500">
          {CLIENT.name ? `${CLIENT.name} · ` : ''}Illustrative mock data · {m.scope} · {m.units} doors in view · swap <code className="rounded bg-white/5 px-1">src/data/portfolio.js</code> for your PMS / accounting feed
        </footer>
        </>
        )}
      </main>
      <DrillModal modal={modal} m={m} onClose={close} />
    </div>
    </Nav.Provider>
  )
}
