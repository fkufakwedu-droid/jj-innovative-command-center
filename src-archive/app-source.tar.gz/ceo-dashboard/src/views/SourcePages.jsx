import { useMemo, useState } from 'react'
import { ArrowLeft, ExternalLink, Mail, Mailbox, MessageSquare, Phone, Wrench } from 'lucide-react'
import { DATA, NOW } from '../data/portfolio'
import { computeMetrics } from '../data/metrics'
import { ageDays } from '../data/store'
import { assigneeContactId, contractorFor, lenderContactId, realtorForUnit, recentActivity, TYPE_LABEL } from '../data/contacts'
import { ContactLink, DataTable, Dot, Pill, ProgressBar, Tabs, TenantLink, TONES, UnitLink, WorkOrderLink } from '../components/ui'
import { dashboardLink, PAGES } from '../lib/sources'
import { money, pct, shortDate } from '../lib/format'

/*
 * Source pages: the tables that hold the data behind each card. Cards, tiles, chart bars and rows deep-link here
 * (#page-<name>?filters) and every row links on to its unit, tenant, work order or contact page.
 */
const DAY = 86400000
const prioTone = { Emergency: 'red', Urgent: 'yellow', Routine: 'blue' }
const ACTIVITY_ICON = { text: MessageSquare, email: Mail, call: Phone, mail: Mailbox, wo: Wrench }
const ACTIVITY_LABEL = { ...TYPE_LABEL, wo: 'Work order' }

const TITLES = {
  units: ['Units', 'Every unit with its tenant, rent, lease and vacancy status'],
  arrears: ['Rent arrears', 'Delinquent tenants and balances by days late'],
  loans: ['Loans', 'Debt by property: lender, balance, debt service and DSCR'],
  projects: ['Projects', 'CapEx projects: budget, spend, forecast and contractor'],
  tickets: ['Tickets', 'Maintenance work orders, open and closed'],
  buildings: ['Buildings', 'Cash, NOI, occupancy and DSCR by property'],
  leasing: ['Leasing pipeline', 'Inquiries to signed leases by property'],
  activity: ['Activity log', 'Recent communications and work-order activity'],
}

const idsFrom = (params) => (params.property ? params.property.split(',').filter((id) => DATA.properties.some((p) => p.id === id)) : [])
const inIds = (ids, id) => !ids.length || ids.includes(id)

export function SourcePage({ page, params = {}, range, version, onBack }) {
  const known = TITLES[page]
  const [ids, setIds] = useState(() => idsFrom(params))
  if (!known) {
    return (
      <div className="glass rounded-2xl p-8 text-center">
        <p className="text-slate-300">Page “{page}” was not found.</p>
        <button onClick={onBack} className="mt-4 rounded-lg bg-white/10 px-4 py-2 text-sm text-white hover:bg-white/15">Back</button>
      </div>
    )
  }
  const [title, subtitle] = known
  const toggle = (id) => setIds((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]))
  const dash = dashboardLink(page)
  const props = { ids, range, params, version }
  const showProps = page !== 'activity'

  return (
    <div className="flex flex-col gap-4 sm:gap-5" data-page={page}>
      <header className="rise flex flex-col gap-3">
        <nav className="flex flex-wrap items-center gap-1.5 text-xs text-slate-400" aria-label="Breadcrumb">
          <button onClick={onBack} className="inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-sky-300 transition hover:bg-white/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60">
            <ArrowLeft className="h-3.5 w-3.5" /> Back
          </button>
          <span>/</span><span>Source</span><span>/</span>
          <span className="text-slate-200">{title}</span>
        </nav>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-xl font-semibold leading-tight tracking-tight text-white sm:text-2xl" data-testid="page-title">{title}</h1>
            <p className="text-sm text-slate-400">{subtitle}</p>
          </div>
          {dash && (
            <a href={dash} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.03] px-3 py-1.5 text-xs font-medium text-slate-200 transition hover:bg-white/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60">
              Open in dashboard <ExternalLink className="h-3.5 w-3.5" />
            </a>
          )}
        </div>
        {showProps && (
          <div className="scroll-thin -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1" role="group" aria-label="Property filter">
            <Chip active={!ids.length} onClick={() => setIds([])}>All properties</Chip>
            {DATA.properties.map((p) => (
              <Chip key={p.id} active={ids.includes(p.id)} onClick={() => toggle(p.id)} color={p.color}>{p.name}</Chip>
            ))}
          </div>
        )}
      </header>
      {page === 'units' && <UnitsPage {...props} />}
      {page === 'arrears' && <ArrearsPage {...props} />}
      {page === 'loans' && <LoansPage {...props} />}
      {page === 'projects' && <ProjectsPage {...props} />}
      {page === 'tickets' && <TicketsPage {...props} />}
      {page === 'buildings' && <BuildingsPage {...props} />}
      {page === 'leasing' && <LeasingPage {...props} />}
      {page === 'activity' && <ActivityPage {...props} />}
    </div>
  )
}

function Chip({ active, onClick, children, color }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={`flex shrink-0 items-center whitespace-nowrap rounded-full px-3.5 py-1.5 text-xs font-medium transition focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60 ${
        active ? 'bg-white text-slate-900 shadow-lg shadow-white/10' : 'border border-white/10 bg-white/[0.03] text-slate-300 hover:border-white/25 hover:text-white'
      }`}
    >
      {color && <span className="mr-1.5 inline-block h-2 w-2 rounded-full" style={{ background: color }} />}
      {children}
    </button>
  )
}

const Panel = ({ children }) => <div className="glass rise rounded-2xl p-3 sm:p-4">{children}</div>
const Summary = ({ children }) => <p className="mb-3 text-xs text-slate-400">{children}</p>
const pageRoute = (id, params) => ({ type: 'page', id, params })

/* ---------------- Units ---------------- */
const BUCKETS = { 30: [0, 30], 60: [31, 60], 90: [61, 90] }

function UnitsPage({ ids, params }) {
  const [status, setStatus] = useState(['all', 'occupied', 'vacant', 'expiring'].includes(params.status) ? params.status : 'all')
  const [bucket, setBucket] = useState(BUCKETS[params.bucket] ? params.bucket : 'all')
  const scoped = DATA.units.filter((u) => inIds(ids, u.propertyId))
  const daysOut = (u) => Math.round((u.leaseEnd - NOW) / DAY)
  const expiring = scoped.filter((u) => !u.vacant && u.renewal)
  const counts = { all: scoped.length, occupied: scoped.filter((u) => !u.vacant).length, vacant: scoped.filter((u) => u.vacant).length, expiring: expiring.length }
  const rows = useMemo(() => {
    let r = status === 'occupied' ? scoped.filter((u) => !u.vacant) : status === 'vacant' ? scoped.filter((u) => u.vacant) : status === 'expiring' ? expiring : scoped
    if (status === 'expiring' && bucket !== 'all') r = r.filter((u) => daysOut(u) >= BUCKETS[bucket][0] && daysOut(u) <= BUCKETS[bucket][1])
    return [...r].sort((a, b) => (status === 'vacant' ? b.vacantDays - a.vacantDays : status === 'expiring' ? a.leaseEnd - b.leaseEnd : 0))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, bucket, ids.join(',')])
  const renewTone = { Renewed: 'green', 'Offer sent': 'blue', 'No response': 'yellow', 'Notice to vacate': 'red' }
  return (
    <Panel>
      <Tabs value={status} onChange={setStatus} tabs={[{ key: 'all', label: 'All units', count: counts.all }, { key: 'occupied', label: 'Occupied', count: counts.occupied }, { key: 'vacant', label: 'Vacant', count: counts.vacant }, { key: 'expiring', label: 'Leases expiring · 90 days', count: counts.expiring }]} />
      {status === 'expiring' && (
        <Tabs value={bucket} onChange={setBucket} tabs={[{ key: 'all', label: 'All 90 days' }, { key: '30', label: 'Next 30 days' }, { key: '60', label: '31–60 days' }, { key: '90', label: '61–90 days' }]} />
      )}
      <Summary>{rows.length} unit{rows.length === 1 ? '' : 's'} shown. Click a row for the unit dashboard.</Summary>
      <DataTable
        maxHeight="68vh"
        rows={rows}
        rowTo={(r) => ({ route: { type: 'unit', id: r.id }, label: 'Unit dashboard' })}
        columns={[
          { key: 'number', label: 'Unit', render: (r) => <UnitLink id={r.id}>{r.number}</UnitLink> },
          { key: 'property', label: 'Property' },
          { key: 'type', label: 'Type', render: (r) => `${r.beds === 0 ? 'Studio' : `${r.beds} bd`} · ${r.baths} ba · ${r.sqft} sf` },
          { key: 'status', label: 'Status', render: (r) => <Pill tone={r.vacant ? 'yellow' : 'green'}>{r.vacant ? r.vacantStatus : 'Occupied'}</Pill> },
          {
            key: 'tenant',
            label: 'Tenant / agent',
            render: (r) => {
              if (!r.vacant) return <TenantLink id={r.id}>{r.tenant}</TenantLink>
              const a = realtorForUnit(r)
              return a ? <ContactLink id={a.id}>{a.name}</ContactLink> : <span className="text-slate-500">—</span>
            },
          },
          { key: 'rent', label: 'Rent / ask', align: 'right', render: (r) => money(r.vacant ? r.askRent : r.rent) },
          { key: 'lease', label: 'Lease end · vacancy', render: (r) => (r.vacant ? `${r.vacantDays} days vacant` : `${shortDate(r.leaseEnd)} ${r.leaseEnd.getFullYear()}${r.renewal ? ` (${daysOut(r)}d)` : ''}`) },
          { key: 'renewal', label: 'Renewal', render: (r) => (r.renewal ? <Pill tone={renewTone[r.renewal]}>{r.renewal}</Pill> : <span className="text-slate-500">—</span>) },
        ]}
      />
    </Panel>
  )
}

/* ---------------- Rent arrears ---------------- */
function ArrearsPage({ ids, range, params }) {
  const m = useMemo(() => computeMetrics(DATA, ids, range), [ids.join(','), range]) // eslint-disable-line react-hooks/exhaustive-deps
  const c = m.collections
  const [tab, setTab] = useState(c.buckets.some((b) => b.key === params.bucket) ? params.bucket : 'all')
  const b = c.buckets.find((x) => x.key === tab)
  const rows = b ? c.rows.filter((r) => r.days >= b.min && r.days <= b.max) : c.rows
  return (
    <Panel>
      <Tabs value={tab} onChange={setTab} tabs={[{ key: 'all', label: 'All', count: c.delinquentCount }, ...c.buckets.map((x) => ({ key: x.key, label: x.label, count: x.count }))]} />
      <Summary>{m.scope} · {money(c.delinquentTotal)} owed across {c.delinquentCount} tenants · collection rate {pct(c.rate)}. Click a row for the tenant dashboard.</Summary>
      <DataTable
        maxHeight="68vh"
        rows={rows}
        rowTo={(r) => ({ route: { type: 'tenant', id: r.unitId }, label: 'Tenant dashboard' })}
        columns={[
          { key: 'tenant', label: 'Tenant', render: (r) => <TenantLink id={r.unitId}>{r.tenant}</TenantLink> },
          { key: 'property', label: 'Property' },
          { key: 'unit', label: 'Unit', render: (r) => <UnitLink id={r.unitId}>{r.unit}</UnitLink> },
          { key: 'days', label: 'Days late', align: 'right', render: (r) => <span className={r.days > 60 ? 'font-semibold text-rose-300' : r.days > 30 ? 'text-orange-300' : 'text-amber-300'}>{r.days}</span> },
          { key: 'balance', label: 'Balance', align: 'right', render: (r) => money(r.balance) },
          { key: 'status', label: 'Status', render: (r) => <Pill tone={r.status === 'Eviction filed' ? 'red' : r.status === 'Payment plan' ? 'green' : 'slate'}>{r.status}</Pill> },
        ]}
      />
    </Panel>
  )
}

/* ---------------- Loans ---------------- */
function LoansPage({ ids, range, params }) {
  const m = useMemo(() => computeMetrics(DATA, ids, range), [ids.join(','), range]) // eslint-disable-line react-hooks/exhaustive-deps
  const d = m.dscr
  const rows = [...d.loans].sort((a, b) => a.dscr - b.dscr)
  return (
    <Panel>
      <Summary>{m.scope} · portfolio DSCR {d.value.toFixed(2)}x ({d.basis}) · {money(d.balance, { compact: true })} outstanding. Green ≥ 1.25x, yellow 1.15–1.24x, red below 1.15x.</Summary>
      <DataTable
        maxHeight="68vh"
        highlight={params.id}
        rows={rows}
        rowTo={(r) => ({ route: pageRoute('buildings', { property: r.propertyId, focus: 'noi' }), label: 'Building' })}
        columns={[
          { key: 'property', label: 'Property', render: (r) => <span className="flex items-center gap-2"><Dot tone={r.status} />{r.property}</span> },
          { key: 'lender', label: 'Lender', render: (r) => <ContactLink id={lenderContactId(r.lender)}>{r.lender}</ContactLink> },
          { key: 'rate', label: 'Rate', align: 'right', render: (r) => pct(r.rate, 2) },
          { key: 'balance', label: 'Balance', align: 'right', render: (r) => money(r.balance, { compact: true }) },
          { key: 'ds', label: 'Debt service / mo', align: 'right', render: (r) => money(r.monthlyDS) },
          { key: 'noi', label: 'NOI (annualized)', align: 'right', render: (r) => money(r.noi, { compact: true }) },
          { key: 'dscr', label: 'DSCR', align: 'right', render: (r) => <span className={`font-semibold ${TONES[r.status].text}`}>{r.dscr.toFixed(2)}x</span> },
        ]}
      />
    </Panel>
  )
}

/* ---------------- Projects ---------------- */
function ProjectsPage({ ids, range, params }) {
  const m = useMemo(() => computeMetrics(DATA, ids, range), [ids.join(','), range]) // eslint-disable-line react-hooks/exhaustive-deps
  const c = m.capex
  return (
    <Panel>
      <Summary>{m.scope} · {money(c.actual, { compact: true })} spent of {money(c.budget, { compact: true })} budget · forecast {money(c.forecast, { compact: true })}.</Summary>
      <DataTable
        maxHeight="68vh"
        highlight={params.id}
        rows={c.projects}
        rowTo={(r) => ({ route: pageRoute('buildings', { property: r.propertyId }), label: 'Building' })}
        columns={[
          { key: 'name', label: 'Project', render: (r) => <div><div>{r.name}</div><div className="text-[11px] text-slate-500">{r.category}</div></div> },
          { key: 'property', label: 'Property' },
          { key: 'contractor', label: 'Contractor', render: (r) => { const k = contractorFor(r); return <ContactLink id={k.id}>{k.name}</ContactLink> } },
          { key: 'budget', label: 'Budget', align: 'right', render: (r) => money(r.budget) },
          { key: 'actual', label: 'Actual', align: 'right', render: (r) => money(r.actual) },
          { key: 'forecast', label: 'Forecast', align: 'right', render: (r) => money(r.forecast) },
          { key: 'variance', label: 'Variance', align: 'right', render: (r) => <span className={r.variance > 0 ? 'font-semibold text-rose-300' : 'text-emerald-300'}>{r.variance > 0 ? '+' : ''}{money(r.variance)} ({pct(r.variancePct)})</span> },
          { key: 'complete', label: '% done', render: (r) => <div className="flex min-w-[88px] items-center gap-2"><div className="flex-1"><ProgressBar value={r.complete} color={r.color} height={6} /></div><span className="w-9 text-right text-xs">{r.complete}%</span></div> },
        ]}
      />
    </Panel>
  )
}

/* ---------------- Tickets ---------------- */
function TicketsPage({ ids, params, version }) {
  const initial = ['Emergency', 'Urgent', 'Routine'].includes(params.priority) ? params.priority : params.status === 'closed' ? 'closed' : params.status === 'all' ? 'all' : params.aged ? 'aged' : 'open'
  const [tab, setTab] = useState(initial)
  const all = DATA.workOrders.filter((w) => inIds(ids, w.propertyId))
  const open = all.filter((w) => w.status !== 'Closed')
  const isAged = (w) => ageDays(w) > 7
  const counts = { open: open.length, aged: open.filter(isAged).length, Emergency: open.filter((w) => w.priority === 'Emergency').length, Urgent: open.filter((w) => w.priority === 'Urgent').length, Routine: open.filter((w) => w.priority === 'Routine').length, closed: all.length - open.length, all: all.length }
  const rows = useMemo(() => {
    const byAge = (a, b) => ageDays(b) - ageDays(a)
    if (tab === 'open') return [...open].sort(byAge)
    if (tab === 'aged') return open.filter(isAged).sort(byAge)
    if (tab === 'closed') return all.filter((w) => w.status === 'Closed').sort((a, b) => b.closedAt - a.closedAt)
    if (tab === 'all') return [...all].sort((a, b) => (a.status === 'Closed') - (b.status === 'Closed') || byAge(a, b))
    return open.filter((w) => w.priority === tab).sort(byAge)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, ids.join(','), version])
  return (
    <Panel>
      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { key: 'open', label: 'All open', count: counts.open },
          { key: 'aged', label: 'Aged > 7 days', count: counts.aged },
          { key: 'Emergency', label: 'Emergency', count: counts.Emergency },
          { key: 'Urgent', label: 'Urgent', count: counts.Urgent },
          { key: 'Routine', label: 'Routine', count: counts.Routine },
          { key: 'closed', label: 'Closed', count: counts.closed },
          { key: 'all', label: 'Everything', count: counts.all },
        ]}
      />
      <Summary>{rows.length} ticket{rows.length === 1 ? '' : 's'} shown. Click a row to open the work order.</Summary>
      <DataTable
        maxHeight="68vh"
        rows={rows}
        rowTo={(r) => ({ route: { type: 'wo', id: r.id }, label: 'Work order' })}
        columns={[
          { key: 'id', label: 'Ticket', render: (r) => <WorkOrderLink id={r.id}>{r.id}</WorkOrderLink> },
          { key: 'title', label: 'Issue', render: (r) => <div><div>{r.title}</div><div className="text-[11px] text-slate-500">{r.category}</div></div> },
          { key: 'property', label: 'Property · Unit', render: (r) => <UnitLink id={r.unitId}>{`${r.property} · ${r.unit}`}</UnitLink> },
          { key: 'reporter', label: 'Reported by', render: (r) => (r.tenantId ? <TenantLink id={r.tenantId}>{r.tenant}</TenantLink> : <span className="text-slate-500">Staff</span>) },
          { key: 'priority', label: 'Priority', render: (r) => <Pill tone={prioTone[r.priority]}>{r.priority}</Pill> },
          { key: 'age', label: 'Age', align: 'right', render: (r) => (r.status === 'Closed' ? <span className="text-slate-400">{r.hours} h</span> : <span className={ageDays(r) > 7 ? 'font-semibold text-rose-300' : ''}>{ageDays(r)}d</span>) },
          { key: 'assignee', label: 'Assigned', render: (r) => <ContactLink id={assigneeContactId(r.assignee)}>{r.assignee}</ContactLink> },
          { key: 'status', label: 'Status' },
        ]}
      />
    </Panel>
  )
}

/* ---------------- Buildings ---------------- */
function BuildingsPage({ ids, range, params }) {
  const props = DATA.properties.filter((p) => inIds(ids, p.id))
  const rows = useMemo(
    () =>
      props.map((p) => {
        const m = computeMetrics(DATA, [p.id], range)
        return { id: p.id, name: p.name, color: p.color, units: p.units, occ: m.occupancy, noi: m.noi, cash: m.cash, dscr: m.dscr, turn: m.turns.avg, open: m.workOrders.open }
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [ids.join(','), range],
  )
  const col = {
    occ: { key: 'occ', label: 'Physical occ.', align: 'right', render: (r) => pct(r.occ.physical) },
    econ: { key: 'econ', label: 'Economic occ.', align: 'right', render: (r) => pct(r.occ.economic) },
    noi: { key: 'noi', label: 'T12 NOI', align: 'right', render: (r) => money(r.noi.t12Noi, { compact: true }) },
    margin: { key: 'margin', label: 'Op. margin', align: 'right', render: (r) => pct(r.noi.margin) },
    cash: { key: 'cash', label: 'Cash on hand', align: 'right', render: (r) => <span className="font-semibold">{money(r.cash.total, { compact: true })}</span> },
    parts: { key: 'parts', label: 'Operating / reserve / escrow', align: 'right', render: (r) => `${money(r.cash.operating, { compact: true })} / ${money(r.cash.reserve, { compact: true })} / ${money(r.cash.escrow, { compact: true })}` },
    runway: { key: 'runway', label: 'Runway', align: 'right', render: (r) => <span className={r.cash.runwayDays < 35 ? 'font-semibold text-rose-300' : r.cash.runwayDays < 45 ? 'text-amber-300' : 'text-emerald-300'}>{Math.round(r.cash.runwayDays)} days</span> },
    dscr: { key: 'dscr', label: 'DSCR', align: 'right', render: (r) => <span className={`font-semibold ${TONES[r.dscr.status].text}`}>{r.dscr.value.toFixed(2)}x</span> },
    turn: { key: 'turn', label: 'Avg turn', align: 'right', render: (r) => `${r.turn.toFixed(1)} d` },
    open: { key: 'open', label: 'Open tickets', align: 'right', render: (r) => r.open },
  }
  const focus = params.focus
  const order =
    ['cash', 'operating', 'reserve', 'escrow'].includes(focus) ? ['cash', 'parts', 'runway', 'occ', 'econ', 'noi', 'margin', 'dscr', 'turn', 'open']
    : focus === 'econ' ? ['econ', 'occ', 'noi', 'margin', 'cash', 'parts', 'runway', 'dscr', 'turn', 'open']
    : focus === 'noi' ? ['noi', 'margin', 'dscr', 'occ', 'econ', 'cash', 'parts', 'runway', 'turn', 'open']
    : ['occ', 'econ', 'noi', 'margin', 'cash', 'parts', 'runway', 'dscr', 'turn', 'open']
  return (
    <Panel>
      <Summary>{props.length} propert{props.length === 1 ? 'y' : 'ies'} · {props.reduce((a, p) => a + p.units, 0)} doors. Click a row to see that building&apos;s units.</Summary>
      <DataTable
        maxHeight="68vh"
        rows={rows}
        rowTo={(r) => ({ route: pageRoute('units', { property: r.id }), label: 'Units' })}
        columns={[
          { key: 'name', label: 'Building', render: (r) => <span className="flex items-center gap-2"><span className="h-2 w-2 rounded-full" style={{ background: r.color }} />{r.name}</span> },
          { key: 'units', label: 'Units', align: 'right', render: (r) => r.units },
          ...order.map((k) => col[k]),
        ]}
      />
    </Panel>
  )
}

/* ---------------- Leasing pipeline ---------------- */
function LeasingPage({ ids, range, params }) {
  const m = useMemo(() => computeMetrics(DATA, ids, range), [ids.join(','), range]) // eslint-disable-line react-hooks/exhaustive-deps
  const scale = m.window.funnelScale
  const stages = m.funnel.stages
  const hi = params.stage
  const rows = DATA.funnelWeek
    .filter((f) => inIds(ids, f.propertyId))
    .map((f) => ({ id: f.propertyId, name: DATA.properties.find((p) => p.id === f.propertyId).name, ...Object.fromEntries(stages.map((s) => [s.key, Math.round(f[s.key] * scale)])) }))
  const total = { id: 'total', name: 'Portfolio total', ...Object.fromEntries(stages.map((s) => [s.key, s.value])) }
  return (
    <Panel>
      <Summary>{m.funnel.scaleLabel} · inquiry → lease conversion {pct(stages[4].overall)}. Per-property counts are rounded individually, so they may differ from the total by a few.</Summary>
      <DataTable
        maxHeight="68vh"
        rows={[...rows, total]}
        rowTo={(r) => (r.id === 'total' ? null : { route: pageRoute('units', { property: r.id, status: 'vacant' }), label: 'Vacant units' })}
        columns={[
          { key: 'name', label: 'Property', render: (r) => <span className={r.id === 'total' ? 'font-semibold text-white' : ''}>{r.name}</span> },
          ...stages.map((s) => ({ key: s.key, label: s.label, align: 'right', render: (r) => <span className={`${hi === s.key ? 'font-semibold text-violet-200' : ''} ${r.id === 'total' ? 'font-semibold text-white' : ''}`}>{r[s.key].toLocaleString()}</span> })),
        ]}
      />
    </Panel>
  )
}

/* ---------------- Activity log ---------------- */
function ActivityPage({ version }) {
  const [tab, setTab] = useState('all')
  const all = useMemo(() => recentActivity(45), [version])
  const counts = Object.fromEntries(['text', 'email', 'call', 'mail', 'wo'].map((t) => [t, all.filter((r) => r.type === t).length]))
  const rows = (tab === 'all' ? all : all.filter((r) => r.type === tab)).slice(0, 250)
  return (
    <Panel>
      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[{ key: 'all', label: 'All', count: all.length }, ...['text', 'email', 'call', 'mail', 'wo'].map((t) => ({ key: t, label: ACTIVITY_LABEL[t], count: counts[t] }))]}
      />
      <Summary>Last 45 days{rows.length === 250 ? ' · showing the newest 250' : ''}. Click a row for the record it refers to, or a name for the contact page.</Summary>
      <DataTable
        maxHeight="68vh"
        rows={rows}
        rowTo={(r) => ({ route: r.ref ? (r.ref.type === 'page' ? pageRoute(r.ref.id, r.ref.params) : { type: r.ref.type, id: r.ref.id }) : { type: 'contact', id: r.contact.id }, label: r.ref ? 'Record' : 'Contact' })}
        columns={[
          { key: 'at', label: 'When', render: (r) => <span className="whitespace-nowrap text-slate-300">{shortDate(r.at)} {r.at.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}</span> },
          { key: 'type', label: 'Type', render: (r) => { const I = ACTIVITY_ICON[r.type]; return <span className="inline-flex items-center gap-1.5 text-slate-300"><I className="h-3.5 w-3.5 text-sky-300" />{ACTIVITY_LABEL[r.type]}</span> } },
          { key: 'contact', label: 'Contact', render: (r) => <ContactLink id={r.contact.id}>{r.contact.name}</ContactLink> },
          { key: 'subject', label: 'Subject', render: (r) => <div><div>{r.subject}</div><div className="text-[11px] text-slate-500">{r.summary}</div></div> },
        ]}
      />
    </Panel>
  )
}
