import { useRef, useState } from 'react'
import { AlertTriangle, ArrowLeft, Camera, CheckCircle2, Circle, ClipboardCheck, Clock, ImagePlus, Lock, Play, RotateCcw, Trash2, Wrench } from 'lucide-react'
import { addPhoto, ageDays, closeBlockers, closeWorkOrder, demoPhotoSrc, fileToPhoto, findWorkOrder, removePhoto, reopenWorkOrder, setStatus } from '../data/store'
import { Card, Dot, Pill, TenantLink, UnitLink } from '../components/ui'
import { money, shortDate } from '../lib/format'

const prioTone = { Emergency: 'red', Urgent: 'yellow', Routine: 'blue' }
const fmt = (d) => `${shortDate(d)} ${d.getFullYear()} · ${d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}`

export function WorkOrderDetail({ woId, onBack, version }) {
  const w = findWorkOrder(woId)
  const [error, setError] = useState('')
  void version
  if (!w) {
    return (
      <div className="glass rounded-2xl p-8 text-center">
        <p className="text-slate-300">Work order “{woId}” was not found.</p>
        <button onClick={onBack} className="mt-4 rounded-lg bg-white/10 px-4 py-2 text-sm text-white hover:bg-white/15">Back</button>
      </div>
    )
  }
  const closed = w.status === 'Closed'
  const missing = closeBlockers(w)
  const canClose = !closed && missing.length === 0
  const age = ageDays(w)
  const tryClose = () => {
    const r = closeWorkOrder(w.id)
    setError(r.ok ? '' : r.error)
  }

  return (
    <div className="flex flex-col gap-4 sm:gap-5">
      <header className="rise flex flex-col gap-3">
        <nav className="flex flex-wrap items-center gap-1.5 text-xs text-slate-400" aria-label="Breadcrumb">
          <button onClick={onBack} className="inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-sky-300 transition hover:bg-white/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60">
            <ArrowLeft className="h-3.5 w-3.5" /> Back
          </button>
          <span>/</span><span>Work orders</span><span>/</span>
          <span className="text-slate-200">{w.id}</span>
        </nav>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 shadow-lg shadow-amber-500/20">
              <Wrench className="h-6 w-6 text-white" />
            </span>
            <div>
              <h1 className="text-xl font-semibold leading-tight tracking-tight text-white sm:text-2xl">{w.id} · {w.title}</h1>
              <p className="text-sm text-slate-400">{w.category} · opened {fmt(w.openedAt)}</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Pill tone={prioTone[w.priority]} className="px-3 py-1 text-xs">{w.priority}</Pill>
            <Pill tone={closed ? 'green' : w.status === 'Awaiting inspection' ? 'yellow' : 'blue'} className="px-3 py-1 text-xs">
              <Dot tone={closed ? 'green' : 'blue'} /> {w.status}
            </Pill>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-6 xl:grid-cols-12">
        <Card title="Details" icon={ClipboardCheck} tone="blue" className="md:col-span-3 xl:col-span-5">
          <p className="text-sm text-slate-200">{w.description}</p>
          <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
            <Fact label="Property" value={w.property} />
            <Fact label="Unit" value={<UnitLink id={w.unitId}>{w.unit}</UnitLink>} />
            <Fact label="Reported by" value={w.tenantId ? <TenantLink id={w.tenantId}>{w.tenant}</TenantLink> : 'Staff · vacant unit'} />
            <Fact label="Assigned to" value={w.assignee} />
            <Fact label={closed ? 'Resolved in' : 'Age'} value={closed ? `${w.hours} hours` : `${age} days`} tone={!closed && age > 7 ? 'text-rose-300' : ''} />
            <Fact label={closed ? 'Actual cost' : 'Estimate'} value={money(closed ? w.actual : w.estimate)} />
          </dl>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Pill tone={w.inspectionRequired ? 'yellow' : 'slate'}>{w.inspectionRequired ? 'Inspection required' : 'No inspection required'}</Pill>
            {closed && w.closedAt && <span className="text-xs text-slate-400">Closed {fmt(w.closedAt)}</span>}
          </div>
        </Card>

        <Card title="Close-out" icon={Lock} tone={canClose || closed ? 'green' : 'yellow'} className="md:col-span-3 xl:col-span-7">
          {w.inspectionRequired ? (
            <ul className="space-y-1.5 text-sm">
              <Req ok={w.photos.before.length > 0} text="Before photo uploaded" />
              <Req ok={w.photos.after.length > 0} text="After photo uploaded" />
            </ul>
          ) : (
            <p className="text-sm text-slate-300">This job does not need an inspection, so photos are optional and the order can be closed any time.</p>
          )}
          {w.inspectionRequired && !closed && !canClose && (
            <p className="mt-3 flex items-start gap-2 rounded-xl bg-amber-400/10 p-3 text-xs text-amber-200 ring-1 ring-amber-400/30">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /> This work needs inspection. Upload {missing.join(' and ').toLowerCase()} before it can be closed.
            </p>
          )}
          {error && <p role="alert" className="mt-2 text-xs text-rose-300">{error}</p>}
          <div className="mt-4 flex flex-wrap gap-2">
            {!closed && w.status !== 'In progress' && <Btn icon={Play} onClick={() => setStatus(w.id, 'In progress')}>Start work</Btn>}
            {!closed && w.inspectionRequired && w.status !== 'Awaiting inspection' && <Btn icon={ClipboardCheck} onClick={() => setStatus(w.id, 'Awaiting inspection')}>Mark awaiting inspection</Btn>}
            {!closed && (
              <button
                type="button"
                data-testid="close-wo"
                aria-disabled={!canClose}
                disabled={!canClose}
                onClick={tryClose}
                title={canClose ? 'Close work order' : `Needs: ${missing.join(', ')}`}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-sm font-medium transition focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/60 ${canClose ? 'bg-emerald-500 text-white hover:bg-emerald-400' : 'cursor-not-allowed bg-white/5 text-slate-500'}`}
              >
                {canClose ? <CheckCircle2 className="h-4 w-4" /> : <Lock className="h-4 w-4" />} Close work order
              </button>
            )}
            {closed && <Btn icon={RotateCcw} onClick={() => reopenWorkOrder(w.id)}>Reopen</Btn>}
          </div>
        </Card>

        <Card title="Before photos" icon={Camera} tone="slate" className="md:col-span-3 xl:col-span-6">
          <PhotoSlot w={w} kind="before" locked={closed} />
        </Card>
        <Card title="After photos" icon={Camera} tone="slate" className="md:col-span-3 xl:col-span-6">
          <PhotoSlot w={w} kind="after" locked={closed} />
        </Card>

        <Card title="History" icon={Clock} tone="slate" className="md:col-span-6 xl:col-span-12">
          <ol className="relative ml-2 space-y-3 border-l border-white/10 pl-4">
            {[...w.log].sort((a, b) => b.at - a.at).map((e, i) => (
              <li key={i} className="relative">
                <span className="absolute -left-[21px] top-1.5 h-2.5 w-2.5 rounded-full bg-sky-400 ring-4 ring-[#0d1424]" />
                <p className="text-sm text-slate-200">{e.text}</p>
                <p className="text-[11px] text-slate-500">{fmt(e.at)}</p>
              </li>
            ))}
          </ol>
        </Card>
      </div>
    </div>
  )
}

function PhotoSlot({ w, kind, locked }) {
  const input = useRef(null)
  const [err, setErr] = useState('')
  const photos = w.photos[kind]
  const onFile = async (e) => {
    const f = e.target.files?.[0]
    e.target.value = ''
    if (!f) return
    try {
      addPhoto(w.id, kind, await fileToPhoto(f, kind))
      setErr('')
    } catch (x) {
      setErr(x.message)
    }
  }
  return (
    <div>
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
        {photos.map((p) => (
          <figure key={p.id} className="group relative overflow-hidden rounded-xl ring-1 ring-white/10">
            <img src={demoPhotoSrc(p, w)} alt={`${kind} photo for ${w.id}`} className="aspect-[4/3] w-full object-cover" />
            {!locked && (
              <button type="button" aria-label="Remove photo" onClick={() => removePhoto(w.id, kind, p.id)} className="absolute right-1.5 top-1.5 rounded-md bg-black/60 p-1.5 text-slate-200 opacity-0 transition hover:bg-rose-500/80 group-hover:opacity-100 focus:opacity-100">
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            )}
          </figure>
        ))}
        {!photos.length && (
          <div className="col-span-full grid place-items-center rounded-xl border border-dashed border-white/15 px-4 py-8 text-center text-sm text-slate-400">
            <Camera className="mb-2 h-6 w-6 opacity-60" />
            No {kind} photo yet
          </div>
        )}
      </div>
      {!locked && (
        <div className="mt-3 flex flex-wrap gap-2">
          <input ref={input} type="file" accept="image/*" capture="environment" className="hidden" onChange={onFile} data-testid={`upload-${kind}`} />
          <Btn icon={ImagePlus} onClick={() => input.current?.click()}>Upload {kind} photo</Btn>
          <Btn icon={Camera} subtle onClick={() => addPhoto(w.id, kind, { id: `demo-${Date.now()}-${Math.floor(Math.random() * 1e4)}`, demo: true, kind })}>Add demo sample</Btn>
        </div>
      )}
      {err && <p role="alert" className="mt-2 text-xs text-rose-300">{err}</p>}
    </div>
  )
}

function Req({ ok, text }) {
  return (
    <li className="flex items-center gap-2.5 rounded-lg bg-white/[0.03] px-3 py-2">
      {ok ? <CheckCircle2 className="h-4 w-4 text-emerald-400" /> : <Circle className="h-4 w-4 text-slate-500" />}
      <span className={ok ? 'text-slate-300' : 'text-slate-100'}>{text}</span>
    </li>
  )
}
function Btn({ icon: Icon, children, onClick, subtle }) {
  return (
    <button type="button" onClick={onClick} className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60 ${subtle ? 'text-slate-300 hover:bg-white/5' : 'bg-white/10 text-white hover:bg-white/15'}`}>
      <Icon className="h-4 w-4" /> {children}
    </button>
  )
}
function Fact({ label, value, tone = '' }) {
  return (
    <div className="rounded-lg bg-white/[0.04] px-3 py-2 ring-1 ring-white/5">
      <dt className="text-[10px] uppercase tracking-wider text-slate-400">{label}</dt>
      <dd className={`mt-0.5 text-slate-100 ${tone}`}>{value}</dd>
    </div>
  )
}
