import { useMemo } from 'react'
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { ArrowLeft, CalendarClock, Clock, Mail, MessageSquare, Phone, Receipt, User, Wrench } from 'lucide-react'
import { DATA } from '../data/portfolio'
import { buildTenantDetail } from '../data/tenantDetail'
import { Card, DataTable, Dot, Pill, UnitLink, WorkOrderLink, chartTooltipStyle } from '../components/ui'
import { Timeline } from '../components/Timeline'
import { money, shortDate } from '../lib/format'

const prioTone = { Emergency: 'red', Urgent: 'yellow', Routine: 'blue' }
const chan = { Email: Mail, Call: Phone, Text: MessageSquare }

export function TenantDashboard({ tenantId, version, onBack }) {
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const d = useMemo(() => buildTenantDetail(DATA, tenantId), [tenantId, version])
  if (!d) {
    return (
      <div className="glass rounded-2xl p-8 text-center">
        <p className="text-slate-300">Tenant “{tenantId}” was not found.</p>
        <button onClick={onBack} className="mt-4 rounded-lg bg-white/10 px-4 py-2 text-sm text-white hover:bg-white/15">Back</button>
      </div>
    )
  }
  const { unit, prop, delinquency, lease, open, closed, ledger, comms, events } = d
  const status = delinquency
    ? { label: `${delinquency.days} days late · ${money(delinquency.balance)} due`, tone: delinquency.days > 60 ? 'red' : 'yellow' }
    : { label: 'Current on rent', tone: 'green' }
  const daysToEnd = Math.round((unit.leaseEnd - DATA.asOf) / 86400000)

  return (
    <div className="flex flex-col gap-4 sm:gap-5">
      <header className="rise flex flex-col gap-3">
        <nav className="flex flex-wrap items-center gap-1.5 text-xs text-slate-400" aria-label="Breadcrumb">
          <button onClick={onBack} className="inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-sky-300 transition hover:bg-white/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60">
            <ArrowLeft className="h-3.5 w-3.5" /> Back
          </button>
          <span>/</span><span>Tenants</span><span>/</span>
          <span className="text-slate-200">{unit.tenant}</span>
        </nav>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-violet-400 to-fuchsia-500 text-lg font-semibold text-white shadow-lg shadow-violet-500/20">
              {unit.tenant.split(' ').map((x) => x[0]).join('')}
            </span>
            <div>
              <h1 className="text-xl font-semibold leading-tight tracking-tight text-white sm:text-2xl">{unit.tenant}</h1>
              <p className="text-sm text-slate-400">Tenant · {prop.name} · <UnitLink id={unit.id}>Unit {unit.number}</UnitLink></p>
            </div>
          </div>
          <Pill tone={status.tone} className="px-3 py-1 text-xs"><Dot tone={status.tone} pulse={status.tone === 'red'} /> {status.label}</Pill>
        </div>
      </header>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Kpi icon={Receipt} label="Monthly rent" value={money(unit.rent)} sub="per month" />
        <Kpi icon={Clock} label="On-time payments" value={`${unit.onTime}%`} sub="last 12 months" tone={unit.onTime < 70 ? 'red' : unit.onTime < 90 ? 'yellow' : 'green'} />
        <Kpi icon={CalendarClock} label="Lease ends" value={shortDate(unit.leaseEnd)} sub={`in ${daysToEnd} days`} tone={daysToEnd <= 30 ? 'yellow' : 'slate'} />
        <Kpi icon={Wrench} label="Open requests" value={open.length} sub={`${closed.length} closed to date`} tone={open.length ? 'yellow' : 'slate'} />
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-6 xl:grid-cols-12">
        <Card title="Contact & Lease" icon={User} tone="violet" className="md:col-span-3 xl:col-span-5">
          <dl className="grid grid-cols-2 gap-2 text-sm">
            <Fact label="Email" value={<span className="break-all">{unit.email}</span>} />
            <Fact label="Phone" value={unit.phone} />
            <Fact label="Resident since" value={`${shortDate(unit.moveIn)} ${unit.moveIn.getFullYear()}`} />
            <Fact label="Tenure" value={`${d.tenureMonths} months`} />
            <Fact label="Lease" value={`${shortDate(unit.leaseStart)} → ${shortDate(unit.leaseEnd)} ${unit.leaseEnd.getFullYear()}`} />
            <Fact label="Renewal" value={lease ? <Pill tone={lease.status === 'Renewed' ? 'green' : lease.status === 'Notice to vacate' ? 'red' : 'yellow'}>{lease.status}</Pill> : 'Not yet due'} />
          </dl>
          {delinquency && (
            <div className="mt-3 rounded-xl bg-rose-500/10 p-3 text-xs text-rose-200 ring-1 ring-rose-400/30">
              {money(delinquency.balance)} past due · {delinquency.days} days · {delinquency.status}
            </div>
          )}
        </Card>

        <Card title="Payment History · 6 months" icon={Receipt} tone="blue" className="md:col-span-3 xl:col-span-7">
          <div className="h-[210px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ledger} margin={{ top: 8, right: 4, bottom: 0, left: 0 }}>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="label" tickLine={false} axisLine={false} />
                <YAxis tickLine={false} axisLine={false} tickFormatter={(v) => `$${(v / 1000).toFixed(1)}K`} width={52} />
                <Tooltip {...chartTooltipStyle} formatter={(v, n) => [money(v), n]} />
                <Bar dataKey="charged" name="Charged" fill="rgba(148,163,184,0.35)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="paid" name="Paid" fill="#34d399" radius={[4, 4, 0, 0]} />
                <Legend iconType="circle" iconSize={7} wrapperStyle={{ fontSize: 11, color: '#94a3b8' }} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card title="Maintenance Requests" icon={Wrench} tone="yellow" className="md:col-span-6 xl:col-span-7">
          {open.length + closed.length ? (
            <DataTable
              maxHeight="300px"
              rows={[...open, ...closed.slice(0, 8)]}
              columns={[
                { key: 'id', label: 'Ticket', render: (r) => <WorkOrderLink id={r.id}>{r.id}</WorkOrderLink> },
                { key: 'title', label: 'Issue', render: (r) => <div><div>{r.title}</div><div className="text-[11px] text-slate-500">{r.category}</div></div> },
                { key: 'priority', label: 'Priority', render: (r) => <Pill tone={prioTone[r.priority]}>{r.priority}</Pill> },
                { key: 'status', label: 'Status', render: (r) => <Pill tone={r.status === 'Closed' ? 'green' : 'slate'}>{r.status}</Pill> },
              ]}
            />
          ) : <p className="py-6 text-center text-sm text-slate-400">No maintenance requests on file.</p>}
        </Card>

        <Card title="Activity Timeline" icon={Clock} tone="slate" className="md:col-span-6 xl:col-span-5">
          <Timeline events={events} />
        </Card>

        <Card title="Communication Log" icon={Mail} tone="blue" className="md:col-span-6 xl:col-span-12">
          <ul className="grid gap-1.5 md:grid-cols-2">
            {comms.map((c, i) => {
              const Icon = chan[c.channel]
              return (
                <li key={i} className="flex items-center gap-2.5 rounded-lg bg-white/[0.03] px-3 py-2 text-sm">
                  <Icon className="h-4 w-4 shrink-0 text-sky-300" />
                  <span className="min-w-0 flex-1 truncate text-slate-200">{c.text}</span>
                  <span className="shrink-0 text-[11px] text-slate-500">{c.ago}d ago</span>
                </li>
              )
            })}
          </ul>
        </Card>
      </div>
    </div>
  )
}

function Kpi({ icon: Icon, label, value, sub, tone = 'slate' }) {
  const color = { slate: 'text-white', green: 'text-emerald-300', yellow: 'text-amber-300', red: 'text-rose-300' }[tone]
  return (
    <div className="glass rise rounded-2xl p-3.5">
      <div className="flex items-center gap-2 text-[11px] uppercase tracking-wider text-slate-400"><Icon className="h-3.5 w-3.5" /><span className="truncate">{label}</span></div>
      <p className={`mt-1.5 text-xl font-semibold sm:text-2xl ${color}`}>{value}</p>
      <p className="text-[11px] text-slate-500">{sub}</p>
    </div>
  )
}
function Fact({ label, value }) {
  return (
    <div className="rounded-lg bg-white/[0.04] px-3 py-2 ring-1 ring-white/5">
      <dt className="text-[10px] uppercase tracking-wider text-slate-400">{label}</dt>
      <dd className="mt-0.5 text-slate-100">{value}</dd>
    </div>
  )
}
