import { useMemo } from 'react'
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Legend } from 'recharts'
import { ArrowLeft, BedDouble, CalendarClock, CheckCircle2, Circle, Clock, DoorOpen, Receipt, Ruler, TrendingUp, User, Wrench, AlertTriangle } from 'lucide-react'
import { DATA } from '../data/portfolio'
import { buildUnitDetail } from '../data/unitDetail'
import { Card, ContactLink, DataTable, Dot, Pill, TONES, TenantLink, WorkOrderLink, chartTooltipStyle } from '../components/ui'
import { assigneeContactId } from '../data/contacts'
import { Timeline } from '../components/Timeline'
import { money, shortDate } from '../lib/format'

const BED_LABEL = ['Studio', '1 bed', '2 bed', '3 bed']
const prioTone = { Emergency: 'red', Urgent: 'yellow', Routine: 'blue' }

export function UnitDashboard({ unitId, version, onBack, onProperty }) {
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const d = useMemo(() => buildUnitDetail(DATA, unitId), [unitId, version])

  if (!d) {
    return (
      <div className="glass rounded-2xl p-8 text-center">
        <p className="text-slate-300">Unit “{unitId}” was not found.</p>
        <button onClick={onBack} className="mt-4 rounded-lg bg-white/10 px-4 py-2 text-sm text-white hover:bg-white/15">Back to portfolio</button>
      </div>
    )
  }

  const { unit, prop, delinquency, openOrders, closed, turns, lease, ledger, checklist, events, marketRent, lossToLease } = d
  const status = unit.vacant
    ? { label: `Vacant · ${unit.vacantDays} days`, tone: unit.vacantDays > 15 ? 'red' : 'yellow' }
    : delinquency
      ? { label: `Occupied · ${delinquency.days} days late`, tone: delinquency.days > 60 ? 'red' : 'yellow' }
      : { label: 'Occupied · current', tone: 'green' }
  const daysToEnd = unit.vacant ? null : Math.round((unit.leaseEnd - DATA.asOf) / 86400000)
  const doneCount = checklist.filter((c) => c.done).length

  return (
    <div className="flex flex-col gap-4 sm:gap-5">
      {/* header */}
      <header className="rise flex flex-col gap-3">
        <nav className="flex flex-wrap items-center gap-1.5 text-xs text-slate-400" aria-label="Breadcrumb">
          <button onClick={onBack} className="inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-sky-300 transition hover:bg-white/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60">
            <ArrowLeft className="h-3.5 w-3.5" /> Portfolio
          </button>
          <span>/</span>
          <button onClick={() => onProperty(prop.id)} className="rounded-md px-1.5 py-1 transition hover:bg-white/5 hover:text-white">{prop.name}</button>
          <span>/</span>
          <span className="text-slate-200">Unit {unit.number}</span>
        </nav>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-sky-400 to-violet-500 shadow-lg shadow-sky-500/20">
              <DoorOpen className="h-6 w-6 text-white" />
            </span>
            <div>
              <h1 className="text-xl font-semibold leading-tight tracking-tight text-white sm:text-2xl">Unit {unit.number}</h1>
              <p className="text-sm text-slate-400">
                {prop.name} · Floor {unit.floor} · {BED_LABEL[unit.beds]} / {unit.baths} bath · {unit.sqft.toLocaleString()} sq ft
              </p>
            </div>
          </div>
          <Pill tone={status.tone} className="px-3 py-1 text-xs">
            <Dot tone={status.tone} pulse={status.tone === 'red'} /> {status.label}
          </Pill>
        </div>
      </header>

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-6">
        <Kpi icon={Receipt} label={unit.vacant ? 'Ask rent' : 'In-place rent'} value={money(unit.vacant ? unit.askRent : unit.rent)} sub="per month" delay={40} />
        <Kpi icon={TrendingUp} label="Market rent" value={money(marketRent)} sub={lossToLease > 0 ? `${money(lossToLease)} loss-to-lease` : 'at market'} tone={lossToLease > 60 ? 'yellow' : 'green'} delay={70} />
        <Kpi icon={AlertTriangle} label="Balance due" value={delinquency ? money(delinquency.balance) : '$0'} sub={delinquency ? delinquency.status : 'paid up'} tone={delinquency ? 'red' : 'green'} delay={100} />
        <Kpi icon={CalendarClock} label={unit.vacant ? 'Days vacant' : 'Lease ends'} value={unit.vacant ? `${unit.vacantDays} days` : shortDate(unit.leaseEnd)} sub={unit.vacant ? unit.vacantStatus : `in ${daysToEnd} days`} tone={unit.vacant ? (unit.vacantDays > 15 ? 'red' : 'yellow') : daysToEnd <= 30 ? 'yellow' : 'slate'} delay={130} />
        <Kpi icon={Wrench} label="Open work orders" value={openOrders.length} sub={`${openOrders.filter((o) => o.age > 7).length} aged > 7 days`} tone={openOrders.some((o) => o.age > 7) ? 'yellow' : 'slate'} delay={160} />
        <Kpi icon={Clock} label="Avg turn time" value={d.avgTurn ? `${d.avgTurn.toFixed(1)} d` : '—'} sub={`${turns.length} turn${turns.length === 1 ? '' : 's'} in 12 mo`} delay={190} />
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-6 xl:grid-cols-12">
        {/* tenant / vacancy */}
        {unit.vacant ? (
          <Card title="Make-ready & Leasing" icon={Ruler} tone={status.tone} delay={220} className="md:col-span-3 xl:col-span-5">
            <p className="text-xs text-slate-400">{doneCount} of {checklist.length} steps complete · stage <span className="text-slate-200">{unit.vacantStatus}</span></p>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/5">
              <div className="h-full rounded-full bg-gradient-to-r from-sky-400 to-emerald-400 transition-all duration-700" style={{ width: `${(doneCount / checklist.length) * 100}%` }} />
            </div>
            <ul className="mt-3 space-y-1.5">
              {checklist.map((c) => (
                <li key={c.task} className="flex items-center gap-2.5 rounded-lg bg-white/[0.03] px-3 py-2 text-sm">
                  {c.done ? <CheckCircle2 className="h-4 w-4 text-emerald-400" /> : <Circle className={`h-4 w-4 ${c.blocked ? 'text-rose-400' : 'text-slate-500'}`} />}
                  <span className={c.done ? 'text-slate-400 line-through decoration-slate-600' : 'text-slate-100'}>{c.task}</span>
                  {c.blocked && <Pill tone="red" className="ml-auto">Blocked</Pill>}
                </li>
              ))}
            </ul>
            <p className="mt-3 text-xs text-slate-400">Rent lost to date <span className="font-semibold text-rose-300">{money((unit.askRent / 30) * unit.vacantDays)}</span></p>
          </Card>
        ) : (
          <Card title="Tenant & Lease" icon={User} tone="violet" delay={220} className="md:col-span-3 xl:col-span-5">
            <p className="text-lg font-semibold text-white"><TenantLink id={unit.id}>{unit.tenant}</TenantLink></p>
            <p className="text-xs text-slate-400">Resident since {shortDate(unit.moveIn)} {unit.moveIn.getFullYear()}</p>
            <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
              <Fact label="Lease start" value={`${shortDate(unit.leaseStart)} ${unit.leaseStart.getFullYear()}`} />
              <Fact label="Lease end" value={`${shortDate(unit.leaseEnd)} ${unit.leaseEnd.getFullYear()}`} />
              <Fact label="Term" value="12 months" />
              <Fact label="Monthly rent" value={money(unit.rent)} />
              <Fact label="Renewal" value={lease ? <Pill tone={lease.status === 'Renewed' ? 'green' : lease.status === 'Notice to vacate' ? 'red' : 'yellow'}>{lease.status}</Pill> : 'Not yet due'} />
              <Fact label="Renewal offer" value={lease ? `+${lease.increase}% → ${money(Math.round(unit.rent * (1 + lease.increase / 100)))}` : '—'} />
            </dl>
            {delinquency && (
              <div className="mt-3 rounded-xl bg-rose-500/10 p-3 text-xs text-rose-200 ring-1 ring-rose-400/30">
                {money(delinquency.balance)} past due · {delinquency.days} days · {delinquency.status}
              </div>
            )}
          </Card>
        )}

        {/* ledger */}
        <Card title="Rent Ledger · 6 months" icon={Receipt} tone="blue" delay={250} className="md:col-span-3 xl:col-span-7">
          <div className="h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ledger} margin={{ top: 8, right: 4, bottom: 0, left: 0 }}>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="label" tickLine={false} axisLine={false} />
                <YAxis tickLine={false} axisLine={false} tickFormatter={(v) => `$${(v / 1000).toFixed(1)}K`} width={52} />
                <Tooltip {...chartTooltipStyle} formatter={(v, n) => [money(v), n]} />
                <Bar dataKey="charged" name="Charged" fill="rgba(148,163,184,0.35)" radius={[4, 4, 0, 0]} animationDuration={700} />
                <Bar dataKey="paid" name="Paid" fill="#34d399" radius={[4, 4, 0, 0]} animationDuration={700} />
                <Legend iconType="circle" iconSize={7} wrapperStyle={{ fontSize: 11, color: '#94a3b8' }} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* work orders */}
        <Card title="Work Orders" icon={Wrench} tone="yellow" delay={280} className="md:col-span-6 xl:col-span-7">
          {openOrders.length ? (
            <DataTable
              maxHeight="260px"
              rows={openOrders}
              columns={[
                { key: 'id', label: 'Ticket', render: (r) => <WorkOrderLink id={r.id}>{r.id}</WorkOrderLink> },
                { key: 'title', label: 'Issue', render: (r) => <div><div>{r.title}</div><div className="text-[11px] text-slate-500">{r.category} · <ContactLink id={assigneeContactId(r.assignee)} className="text-[11px]">{String(r.assignee).replace(/^Vendor:\s*/, '')}</ContactLink></div></div> },
                { key: 'priority', label: 'Priority', render: (r) => <Pill tone={prioTone[r.priority]}>{r.priority}</Pill> },
                { key: 'age', label: 'Age', align: 'right', render: (r) => <span className={r.age > 7 ? 'font-semibold text-rose-300' : ''}>{r.age}d</span> },
                { key: 'status', label: 'Status' },
              ]}
            />
          ) : (
            <p className="py-6 text-center text-sm text-slate-400">No open work orders for this unit.</p>
          )}
          <p className="mb-1.5 mt-4 text-[11px] font-semibold uppercase tracking-wider text-slate-400">Recently closed</p>
          <ul className="space-y-1.5">
            {closed.map((c) => (
              <li key={c.id} className="flex items-center justify-between gap-2 rounded-lg bg-white/[0.03] px-3 py-1.5 text-xs">
                <span className="flex min-w-0 items-center gap-2 truncate text-slate-300"><WorkOrderLink id={c.id}>{c.id}</WorkOrderLink>{c.title}</span>
                <span className="shrink-0 text-slate-500">{c.closedAgo}d ago · {c.hours} h</span>
              </li>
            ))}
          </ul>
        </Card>

        {/* timeline */}
        <Card title="Activity Timeline" icon={Clock} tone="slate" delay={310} className="md:col-span-6 xl:col-span-5">
          <Timeline events={events} />
        </Card>
      </div>

      {turns.length > 0 && (
        <Card title="Turn History · last 12 months" icon={BedDouble} tone="violet" delay={340}>
          <DataTable
            maxHeight="220px"
            rows={turns.map((t, i) => ({ ...t, id: `t${i}` }))}
            columns={[
              { key: 'moveOut', label: 'Move-out', render: (r) => `${shortDate(r.moveOut)} ${r.moveOut.getFullYear()}` },
              { key: 'days', label: 'Days to re-lease', align: 'right', render: (r) => <span className={r.days > 10 ? 'text-amber-300' : 'text-emerald-300'}>{r.days}</span> },
            ]}
          />
        </Card>
      )}
    </div>
  )
}

function Kpi({ icon: Icon, label, value, sub, tone = 'slate', delay = 0 }) {
  return (
    <div className="glass rise rounded-2xl p-3.5" style={{ animationDelay: `${delay}ms` }}>
      <div className="flex items-center gap-2 text-[11px] uppercase tracking-wider text-slate-400">
        <Icon className="h-3.5 w-3.5" /> <span className="truncate">{label}</span>
      </div>
      <p className={`mt-1.5 text-xl font-semibold sm:text-2xl ${tone === 'slate' ? 'text-white' : TONES[tone].text}`}>{value}</p>
      <p className="text-[11px] text-slate-500">{sub}</p>
    </div>
  )
}

function Fact({ label, value }) {
  return (
    <div className="rounded-lg bg-white/[0.04] px-3 py-2 ring-1 ring-white/5">
      <dt className="text-[10px] uppercase tracking-wider text-slate-400">{label}</dt>
      <dd className="mt-0.5 text-slate-100">{value}</dd>
    </div>
  )
}
