import { useContext, useMemo, useState } from 'react'
import { ArrowLeft, ArrowUpDown, Contact as ContactIcon, Link2, Mail, Mailbox, MapPin, MessageSquare, Phone } from 'lucide-react'
import { getContact, TYPE_LABEL, TYPES } from '../data/contacts'
import { Card, Pill, Tabs } from '../components/ui'
import { Nav } from '../components/nav'
import { PAGES } from '../lib/sources'
import { shortDate } from '../lib/format'

const ICON = { text: MessageSquare, email: Mail, call: Phone, mail: Mailbox }
const TONE = { text: 'blue', email: 'violet', call: 'green', mail: 'yellow' }
const KIND_LABEL = { tenant: 'Tenant', lender: 'Lender', vendor: 'Vendor / trade', staff: 'Staff', contractor: 'Contractor', realtor: 'Realtor' }

function RouteButton({ route, children }) {
  const nav = useContext(Nav)
  return (
    <button
      type="button"
      onClick={() => nav.go(route)}
      className="inline-flex items-center gap-1.5 rounded-md px-1.5 py-0.5 text-left text-sm font-medium text-sky-300 underline decoration-sky-400/30 decoration-dotted underline-offset-4 transition hover:bg-sky-400/10 hover:text-sky-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60"
    >
      {children}
    </button>
  )
}

const refRoute = (ref) => (ref.type === 'page' ? { type: 'page', id: ref.id, params: ref.params || {} } : { type: ref.type, id: ref.id })
const refLabel = (ref) => (ref.type === 'wo' ? `Open ${ref.id}` : `Open ${PAGES[ref.id] || 'page'}`)

export function ContactPage({ contactId, version, onBack }) {
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const c = useMemo(() => getContact(contactId), [contactId, version])
  const [type, setType] = useState('all')
  const [newestFirst, setNewestFirst] = useState(true)

  if (!c) {
    return (
      <div className="glass rounded-2xl p-8 text-center">
        <p className="text-slate-300">Contact “{contactId}” was not found.</p>
        <button onClick={onBack} className="mt-4 rounded-lg bg-white/10 px-4 py-2 text-sm text-white hover:bg-white/15">Back</button>
      </div>
    )
  }

  const counts = Object.fromEntries(TYPES.map((t) => [t, c.comms.filter((x) => x.type === t).length]))
  const rows = (type === 'all' ? c.comms : c.comms.filter((x) => x.type === type)).slice().sort((a, b) => (newestFirst ? b.at - a.at : a.at - b.at))
  const initials = c.name.replace(/[^A-Za-z ]/g, '').split(' ').filter(Boolean).slice(0, 2).map((x) => x[0]).join('').toUpperCase()

  return (
    <div className="flex flex-col gap-4 sm:gap-5">
      <header className="rise flex flex-col gap-3">
        <nav className="flex flex-wrap items-center gap-1.5 text-xs text-slate-400" aria-label="Breadcrumb">
          <button onClick={onBack} className="inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-sky-300 transition hover:bg-white/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60">
            <ArrowLeft className="h-3.5 w-3.5" /> Back
          </button>
          <span>/</span><span>Contacts</span><span>/</span>
          <span className="text-slate-200">{c.name}</span>
        </nav>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-violet-400 to-fuchsia-500 text-lg font-semibold text-white shadow-lg shadow-violet-500/20">{initials || <ContactIcon className="h-6 w-6" />}</span>
            <div>
              <h1 className="text-xl font-semibold leading-tight tracking-tight text-white sm:text-2xl" data-testid="contact-name">{c.name}</h1>
              <p className="text-sm text-slate-400">{c.role}{c.company && c.company !== c.name ? ` · ${c.company}` : ''}</p>
            </div>
          </div>
          <Pill tone="violet" className="px-3 py-1 text-xs">{KIND_LABEL[c.kind] || 'Contact'}</Pill>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-6 xl:grid-cols-12">
        <Card title="Contact details" icon={ContactIcon} tone="violet" collapsible={false} className="md:col-span-3 xl:col-span-5">
          <dl className="grid grid-cols-2 gap-2 text-sm">
            <Fact label="Role" value={c.role} />
            <Fact label="Company" value={c.company || '—'} />
            {c.person && <Fact label="Primary contact" value={c.person} wide />}
            <Fact label="Phone" value={<a className="text-sky-300 hover:underline" href={`tel:${c.phone}`}>{c.phone}</a>} />
            <Fact label="Email" value={<a className="break-all text-sky-300 hover:underline" href={`mailto:${c.email}`}>{c.email}</a>} />
            <Fact
              label="Mailing address"
              wide
              value={
                <span className="inline-flex items-start gap-1.5">
                  <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-slate-400" />
                  <span>{c.address}{c.city ? <><br />{c.city}</> : null}</span>
                </span>
              }
            />
            {c.facts.map((f) => (
              <Fact key={f.label} label={f.label} wide value={f.route ? <RouteButton route={f.route}>{f.text}</RouteButton> : f.text} />
            ))}
          </dl>
          <p className="mt-3 text-[11px] text-slate-500">Demo contact record. Phone, email and address are placeholders.</p>
        </Card>

        <Card title="Related" icon={Link2} tone="blue" collapsible={false} className="md:col-span-3 xl:col-span-7">
          {c.related.length ? (
            <ul className="grid gap-1.5 sm:grid-cols-2">
              {c.related.map((r, i) => (
                <li key={i} className="rounded-lg bg-white/[0.03] px-2.5 py-1.5"><RouteButton route={r.route}>{r.label}</RouteButton></li>
              ))}
            </ul>
          ) : (
            <p className="py-4 text-center text-sm text-slate-400">Nothing linked to this contact yet.</p>
          )}
        </Card>

        <Card title={`Communication history · ${c.comms.length}`} icon={Mail} tone="slate" collapsible={false} className="md:col-span-6 xl:col-span-12"
          right={
            <button
              type="button"
              onClick={() => setNewestFirst((v) => !v)}
              className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-medium text-slate-300 transition hover:bg-white/10 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60"
            >
              <ArrowUpDown className="h-3.5 w-3.5" /> {newestFirst ? 'Newest first' : 'Oldest first'}
            </button>
          }
        >
          <Tabs
            value={type}
            onChange={setType}
            tabs={[{ key: 'all', label: 'All', count: c.comms.length }, ...TYPES.map((t) => ({ key: t, label: TYPE_LABEL[t], count: counts[t] }))]}
          />
          {rows.length ? (
            <ol className="space-y-2" data-testid="comm-list">
              {rows.map((m) => {
                const Icon = ICON[m.type]
                return (
                  <li key={m.id} className="flex items-start gap-3 rounded-xl bg-white/[0.03] px-3.5 py-3 ring-1 ring-white/5" data-type={m.type}>
                    <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-white/5 ring-1 ring-white/10"><Icon className="h-4 w-4 text-sky-300" /></span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                        <span className="text-sm font-medium text-slate-100">{m.subject}</span>
                        <Pill tone={TONE[m.type]}>{TYPE_LABEL[m.type]}</Pill>
                        <span className="text-[11px] text-slate-500">{m.direction === 'in' ? 'Received' : 'Sent'}</span>
                      </div>
                      <p className="mt-0.5 text-sm text-slate-300">{m.summary}</p>
                      {m.ref && <div className="mt-1"><RouteButton route={refRoute(m.ref)}>{refLabel(m.ref)}</RouteButton></div>}
                    </div>
                    <time dateTime={m.at.toISOString()} className="shrink-0 text-right text-[11px] text-slate-500">
                      {shortDate(m.at)} {m.at.getFullYear()}
                      {m.type !== 'mail' && <><br />{m.at.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}</>}
                    </time>
                  </li>
                )
              })}
            </ol>
          ) : (
            <p className="py-6 text-center text-sm text-slate-400">No {TYPE_LABEL[type]?.toLowerCase()} communications on file.</p>
          )}
        </Card>
      </div>
    </div>
  )
}

function Fact({ label, value, wide }) {
  return (
    <div className={`rounded-lg bg-white/[0.04] px-3 py-2 ring-1 ring-white/5 ${wide ? 'col-span-2' : ''}`}>
      <dt className="text-[10px] uppercase tracking-wider text-slate-400">{label}</dt>
      <dd className="mt-0.5 text-slate-100">{value}</dd>
    </div>
  )
}
