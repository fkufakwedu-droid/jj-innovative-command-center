# Portfolio Command Center (260 doors)

React + Tailwind v4 + Recharts + Lucide executive dashboard with mock data.

    npm install
    npm run dev      # local dev server
    npm run build    # dist/index.html: one self-contained file

Structure
- src/data/portfolio.js  seeded mock data (5 properties = 260 units). Replace with your PMS / accounting feed.
- src/data/metrics.js    all KPI math; takes (data, selectedPropertyIds, range)
- src/sections/*         the 10 metric cards
- src/components/*       header filters, alert ticker, drill-down modals, UI kit
